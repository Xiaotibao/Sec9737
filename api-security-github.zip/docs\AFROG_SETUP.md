# afrog 快速部署指南

afrog 是 API 动态漏洞扫描工具，用于对运行中的 API 进行漏洞检测。本指南帮助您在 **5 分钟内** 完成部署并成功扫描。

---

## 一、方式一：Docker 一键部署（推荐）

### 1.1 前置条件

- 已安装 Docker 和 Docker Compose
- 待扫描的 API 已启动（或使用 `host.docker.internal` 访问宿主机服务）

### 1.2 一键启动

```bash
# 在项目根目录执行
docker-compose -f docker-compose.afrog.yml up -d

# 等待镜像构建与启动（首次约 2–3 分钟）
# 访问管理后台：http://localhost:35555/admin
```

### 1.3 配置 afrog_url

在「扫描」页或 CLI 中填写 `afrog_url`，即**待扫描的 API 地址**：

| 场景 | afrog_url 示例 |
|------|----------------|
| 宿主机上的 API | `http://host.docker.internal:8080` |
| 同 compose 内服务 | `http://服务名:端口` |
| 外网 API | `https://api.example.com` |

**注意**：Docker Desktop（Win/Mac）默认支持 `host.docker.internal`。Linux 需在 `docker-compose.afrog.yml` 中取消注释：

```yaml
extra_hosts:
  - "host.docker.internal:host-gateway"
```

### 1.4 执行扫描

- **管理后台**：在「扫描」页填写目标路径、项目名、afrog_url，点击「执行扫描」
- **CLI**：`python -m api_security.cli scan . --afrog-url http://host.docker.internal:8080`

---

## 二、方式二：本地安装 afrog

### 2.1 下载二进制

从 [afrog Releases](https://github.com/zan8in/afrog/releases/latest) 下载对应平台：

- Windows: `afrog_*_windows_amd64.zip`
- Linux: `afrog_*_linux_amd64.zip`
- macOS: `afrog_*_macOS_arm64.zip` 或 `afrog_*_macOS_amd64.zip`

解压后将 `afrog` 放入 PATH，或放在项目目录。

### 2.2 验证安装

```bash
afrog -h
```

### 2.3 配置 afrog_url

在 `config/api_security.yaml` 或扫描参数中设置：

```yaml
scan:
  afrog_url: "http://localhost:8080"  # 待扫描的 API 地址
```

---

## 三、健康检查与连通性

扫描前会自动检测 `afrog_url` 是否可达：

- **可达**：正常执行 afrog 动态扫描
- **不可达**：跳过 afrog，并给出明确提示，建议检查：
  1. API 服务是否已启动
  2. 地址与端口是否正确
  3. 防火墙/网络是否放行

管理后台「扫描」页和 CLI 均支持 afrog 连通性检查。

---

## 四、常见问题

**Q：Docker 构建失败？**  
A：确保网络可访问 GitHub，或使用镜像加速。若下载 afrog 失败，可手动下载后通过 `COPY` 加入镜像。

**Q：host.docker.internal 无法解析？**  
A：Linux 下需在 docker-compose 中配置 `extra_hosts`，见 1.3 节。

**Q：afrog 扫描很慢？**  
A：afrog 会对目标进行多轮探测，耗时与目标规模有关，通常数分钟。可适当调整超时时间。

**Q：未配置 afrog_url 会怎样？**  
A：扫描将跳过 afrog，仅执行 OpenSCA 与 Semgrep，不影响其他检测。

---

*文档版本：v1.0*
