"""
OWASP API Top 10 2023 覆盖测试
每类至少 1 个正向/负向用例，确保检测逻辑可追溯
"""

import pytest
from pathlib import Path

from api_security.owasp import (
    OWASP_API_TOP10,
    get_owasp_category_from_rule_id,
    get_owasp_category_from_compliance,
    compliance_to_findings,
)
from api_security.parser import OpenAPIParser, ComplianceChecker
from api_security.parser.compliance_types import ComplianceResult

FIXTURES = Path(__file__).parent.parent / "fixtures"
CONFIG_OWASP = Path(__file__).parent.parent / "config" / "owasp_api_top10" / "rules.yaml"


# ========== 规则与映射测试 ==========

class TestOwaspMapping:
    """OWASP 类别映射"""

    def test_owasp_top10_list(self):
        """正向：OWASP API Top 10 列表完整"""
        assert len(OWASP_API_TOP10) == 10
        assert "API1:2023" in OWASP_API_TOP10
        assert "API10:2023" in OWASP_API_TOP10

    def test_rule_id_to_owasp_owasp_rules(self):
        """正向：owasp-apiN 规则 ID 映射到对应类别"""
        assert get_owasp_category_from_rule_id("owasp-api1-idor-path-param") == "API1:2023"
        assert get_owasp_category_from_rule_id("owasp-api2-weak-jwt-secret") == "API2:2023"
        assert get_owasp_category_from_rule_id("owasp-api3-object-assign-req-body") == "API3:2023"
        assert get_owasp_category_from_rule_id("owasp-api8-sql-injection") == "API8:2023"
        assert get_owasp_category_from_rule_id("owasp-api10-sensitive-in-log") == "API10:2023"

    def test_rule_id_to_owasp_legacy_rules(self):
        """正向：原有规则映射"""
        assert get_owasp_category_from_rule_id("api-sql-injection") == "API8:2023"
        assert get_owasp_category_from_rule_id("api-missing-auth") == "API5:2023"
        assert get_owasp_category_from_rule_id("api-sensitive-log") == "API10:2023"
        assert get_owasp_category_from_rule_id("api-hardcoded-secret") == "API2:2023"

    def test_rule_id_to_owasp_unknown(self):
        """负向：未知规则返回 None"""
        assert get_owasp_category_from_rule_id("unknown-rule") is None
        assert get_owasp_category_from_rule_id(None) is None

    def test_compliance_type_to_owasp(self):
        """正向：合规类型映射"""
        assert get_owasp_category_from_compliance("missing_security") == "API5:2023"
        assert get_owasp_category_from_compliance("sensitive_fields_in_response") == "API3:2023"
        assert get_owasp_category_from_compliance("missing_auth_errors") == "API2:2023"
        assert get_owasp_category_from_compliance("deprecated_operations") == "API9:2023"

    def test_compliance_type_unknown(self):
        """负向：未知合规类型返回 None"""
        assert get_owasp_category_from_compliance("unknown") is None


class TestComplianceToFindings:
    """合规结果转 Finding"""

    def test_missing_security_to_finding(self):
        """正向：缺失 security 转为 Finding，含 API5 类别"""
        cr = ComplianceResult(missing_security=["GET /users"], passed=False)
        findings = compliance_to_findings(cr)
        assert len(findings) >= 1
        sec = next(f for f in findings if f["rule_id"] == "compliance-missing-security")
        assert sec["owasp_category"] == "API5:2023"
        assert "GET /users" in sec["description"]

    def test_sensitive_fields_to_finding(self):
        """正向：敏感字段转为 Finding，含 API3 类别"""
        cr = ComplianceResult(
            sensitive_fields_in_response=[{"operation": "GET /users", "field_path": "password"}],
            passed=False,
        )
        findings = compliance_to_findings(cr)
        assert len(findings) >= 1
        sens = next(f for f in findings if f["rule_id"] == "compliance-sensitive-field")
        assert sens["owasp_category"] == "API3:2023"
        assert "password" in sens["description"]

    def test_missing_auth_errors_to_finding(self):
        """正向：缺失 401/403 转为 Finding，含 API2 类别"""
        cr = ComplianceResult(missing_auth_errors=["POST /users"], passed=False)
        findings = compliance_to_findings(cr)
        assert len(findings) >= 1
        auth = next(f for f in findings if f["rule_id"] == "compliance-missing-auth-errors")
        assert auth["owasp_category"] == "API2:2023"

    def test_deprecated_to_finding(self):
        """正向：废弃接口转为 Finding，含 API9 类别"""
        cr = ComplianceResult(deprecated_operations=["POST /legacy/users"], passed=True)
        findings = compliance_to_findings(cr)
        assert len(findings) >= 1
        dep = next(f for f in findings if f["rule_id"] == "compliance-deprecated")
        assert dep["owasp_category"] == "API9:2023"

    def test_empty_compliance(self):
        """负向：空合规结果无 Finding"""
        cr = ComplianceResult(passed=True)
        findings = compliance_to_findings(cr)
        assert len(findings) == 0


# ========== OpenAPI 合规与 OWASP 对应测试 ==========

class TestComplianceOwaspCoverage:
    """合规核查覆盖 API2, API3, API5, API9"""

    def test_v3_with_issues_detects_api3_sensitive(self):
        """正向：含敏感字段的 OpenAPI 触发 API3 检测"""
        path = FIXTURES / "openapi_v3_with_issues.json"
        assert path.exists()
        result = OpenAPIParser().parse(path)
        assert result.success
        compliance = ComplianceChecker().check(result)
        assert len(compliance.sensitive_fields_in_response) > 0
        findings = compliance_to_findings(compliance)
        api3 = [f for f in findings if f.get("owasp_category") == "API3:2023"]
        assert len(api3) > 0

    def test_v3_with_issues_detects_api2_auth_errors(self):
        """正向：缺失 401/403 触发 API2 检测"""
        path = FIXTURES / "openapi_v3_with_issues.json"
        result = OpenAPIParser().parse(path)
        compliance = ComplianceChecker().check(result)
        assert len(compliance.missing_auth_errors) > 0
        findings = compliance_to_findings(compliance)
        api2 = [f for f in findings if f.get("owasp_category") == "API2:2023"]
        assert len(api2) > 0

    def test_v3_with_issues_detects_api9_deprecated(self):
        """正向：deprecated 接口触发 API9 检测"""
        path = FIXTURES / "openapi_v3_with_issues.json"
        result = OpenAPIParser().parse(path)
        compliance = ComplianceChecker().check(result)
        assert len(compliance.deprecated_operations) > 0
        findings = compliance_to_findings(compliance)
        api9 = [f for f in findings if f.get("owasp_category") == "API9:2023"]
        assert len(api9) > 0

    def test_v2_petstore_may_have_missing_security(self):
        """正向/负向：根据实际文档，可能检测到 API5"""
        path = FIXTURES / "openapi_v2_petstore.yaml"
        if not path.exists():
            pytest.skip("fixture 不存在")
        result = OpenAPIParser().parse(path)
        compliance = ComplianceChecker().check(result)
        findings = compliance_to_findings(compliance)
        # 至少验证合规检查可执行
        assert isinstance(compliance, ComplianceResult)


# ========== 规则文件存在性测试 ==========

class TestOwaspRulesFile:
    """OWASP 规则文件与内容"""

    def test_owasp_rules_file_exists(self):
        """正向：OWASP 规则文件存在"""
        assert CONFIG_OWASP.exists(), "config/owasp_api_top10/rules.yaml 应存在"

    def test_owasp_rules_cover_all_10(self):
        """正向：规则文件包含全部 10 类 OWASP 的规则"""
        if not CONFIG_OWASP.exists():
            pytest.skip("规则文件不存在")
        content = CONFIG_OWASP.read_text(encoding="utf-8")
        for i in range(1, 11):
            assert f"API{i}:2023" in content or f"owasp-api{i}" in content, (
                f"应包含 API{i}:2023 相关规则"
            )
