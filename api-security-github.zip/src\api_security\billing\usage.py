"""
API 调用次数统计与校验
按企业/月统计，用于套餐限额校验
"""

import json
from typing import Optional
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
USAGE_FILE = DATA_DIR / "usage.json"


def _load_usage() -> dict:
    """{ "enterprise_id": { "2024-03": 12345, ... } }"""
    if not USAGE_FILE.exists():
        return {}
    try:
        return json.loads(USAGE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_usage(data: dict):
    DATA_DIR.mkdir(exist_ok=True)
    USAGE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _current_month_key() -> str:
    return datetime.now().strftime("%Y-%m")


class UsageTracker:
    """API 调用次数追踪"""

    def __init__(self, enterprise_id: str = "default"):
        self.enterprise_id = enterprise_id or "default"

    def record_call(self, count: int = 1) -> int:
        """
        记录 API 调用
        Returns: 当月累计调用次数
        """
        data = _load_usage()
        key = _current_month_key()
        if self.enterprise_id not in data:
            data[self.enterprise_id] = {}
        data[self.enterprise_id][key] = data[self.enterprise_id].get(key, 0) + count
        _save_usage(data)
        return data[self.enterprise_id][key]

    def get_monthly_usage(self) -> int:
        """获取当月已用调用次数"""
        data = _load_usage()
        key = _current_month_key()
        return data.get(self.enterprise_id, {}).get(key, 0)

    def check_within_limit(self, plan_id: str) -> tuple[bool, int, Optional[int]]:
        """
        校验是否在限额内
        Returns:
            (within_limit, current_usage, limit)
            limit 为 None 表示不限
        """
        from .plans import get_api_limit
        limit = get_api_limit(plan_id)
        current = self.get_monthly_usage()
        if limit is None:
            return True, current, None
        return current < limit, current, limit
