# 增量扫描说明

## 概述

增量扫描仅对 **git 变更的文件** 执行 Semgrep/合规检查，在仅变更少量文件时可显著缩短 CI 时间。

## 使用方式

### CLI

```bash
# 增量模式（--incremental 与 --changed-only 等效）
python -m api_security.cli scan . --incremental --output scan-result.json

# 指定基准引用
python -m api_security.cli scan . --incremental --base-ref origin/main

# 与历史结果合并
python -m api_security.cli scan . --incremental --previous-result last-scan.json --output scan-result.json
```

### API

```python
from api_security.core.scanner import run_api_scan

result = run_api_scan(
    target=".",
    incremental=True,
    base_ref="origin/main",
    previous_result_path="scan_results/latest.json",
)
```

## 变更检测

- **基于 git diff**：`git diff --name-only base_ref...HEAD`
- **可扫描扩展名**：`.py`, `.js`, `.ts`, `.java`, `.go`, `.rb`, `.php`, `.yaml`, `.yml`, `.json`
- **未跟踪文件**：默认包含 `git ls-files --others` 的新文件

### 基准引用

| 优先级 | 来源 | 示例 |
|--------|------|------|
| 1 | 参数 `--base-ref` | `origin/main` |
| 2 | `GITHUB_BASE_REF` | GitHub PR 目标分支 |
| 3 | `CI_MERGE_REQUEST_TARGET_BRANCH_NAME` | GitLab MR 目标分支 |
| 4 | `GIT_PREVIOUS_COMMIT` | Jenkins 上次提交 |
| 5 | 默认 | `origin/main` 或 `origin/master` 或 `HEAD~1` |

## 增量策略

| 组件 | 全量 | 增量 |
|------|------|------|
| Semgrep | 全项目 | 仅变更文件 |
| OpenSCA | 全项目 | 跳过（依赖可缓存） |
| OpenAPI 合规 | 执行 | OpenAPI 未变更时跳过 |
| afrog | 按配置 | 按配置 |

## 结果合并

当提供 `--previous-result` 时：

1. 加载上次扫描的 findings
2. 保留「未变更文件」的历史发现
3. 用本次增量发现覆盖「变更文件」的历史发现
4. 按 `location + rule_id` 去重

**CI 推荐流程**：

```bash
# 首次或定期全量
python -m api_security.cli scan . --output scan-result.json

# PR 增量（与上次合并）
python -m api_security.cli scan . --incremental --previous-result scan-result.json --output scan-result.json
```

## CI 模板中的增量扫描

### GitLab CI

模板已内置：**MR 场景自动使用增量扫描**（`CI_MERGE_REQUEST_TARGET_BRANCH_NAME` 作为基准）：

```yaml
# .gitlab-ci-api-security-basic.yml.example 中
if [ -n "$CI_MERGE_REQUEST_TARGET_BRANCH_NAME" ]; then
  python -m api_security.cli scan . --incremental --base-ref "origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME" --output scan-result.json
else
  python -m api_security.cli scan . --output scan-result.json
fi
```

### Jenkins

模板已内置：**有 `GIT_PREVIOUS_COMMIT` 时自动使用增量扫描**（Git 插件提供）：

```groovy
if [ -n "$GIT_PREVIOUS_COMMIT" ]; then
  python -m api_security.cli scan . --incremental --base-ref "$GIT_PREVIOUS_COMMIT" --output scan-result.json
else
  python -m api_security.cli scan . --output scan-result.json
fi
```

### VS Code 插件

在设置中启用 `apiSecurity.incremental`，或于 `config/api_security.yaml` 中配置 `incremental: true`。

## 验收标准

在仅变更少量文件时，扫描时间应明显缩短（Semgrep 仅扫变更文件，OpenSCA 可跳过）。

## 非 Git 仓库

若非 git 仓库，增量模式将退化为全量扫描（`get_changed_files` 返回空，`include_paths=None`，Semgrep 扫全项目）。
