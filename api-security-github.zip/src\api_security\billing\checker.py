"""
权限精准校验
按套餐限制 API 调用次数、功能开放、团队规模

社区版：所有校验通过，无限制
商业版：
- API 调用：基础版 10 万/月，进阶 50 万，旗舰 100 万，无限不限
- 功能：OpenAPI 合规仅旗舰/无限，GitHub Actions 仅无限
- 团队：无限版限 10 人内，超员需扩容包
"""

from typing import Optional

from ..edition import is_community
from .plans import (
    get_plan,
    has_feature,
    get_api_limit,
    get_max_team_size,
    PLAN_BASIC,
    PLAN_ADVANCED,
    PLAN_FLAGSHIP,
    PLAN_UNLIMITED,
    FEATURE_OPENAPI_COMPLIANCE,
    FEATURE_GITHUB_ACTIONS,
)
from .usage import UsageTracker


class PermissionChecker:
    """
    权限校验器
    对接插件与团队管理后台，实现套餐权限精准校验
    """

    def __init__(self, enterprise_id: str = "default"):
        self.enterprise_id = enterprise_id
        self._usage = UsageTracker(enterprise_id)

    def get_plan_id(self) -> str:
        """获取当前企业套餐，社区版视为 unlimited"""
        if is_community():
            return PLAN_UNLIMITED
        from .license_store import get_enterprise_plan
        return get_enterprise_plan(self.enterprise_id) or PLAN_BASIC

    def get_expansion_count(self) -> int:
        """获取已购扩容人数，社区版无限制"""
        if is_community():
            return 999
        from .license_store import get_expansion_count
        return get_expansion_count(self.enterprise_id)

    def check_api_call(self, plan_id: str) -> tuple[bool, str]:
        """
        校验 API 调用是否在限额内
        Returns:
            (allowed, message)
        """
        if is_community():
            return True, ""
        within, current, limit = self._usage.check_within_limit(plan_id)
        if within:
            return True, ""
        return False, f"本月 API 调用已达上限 {limit} 次，当前已用 {current} 次，请升级套餐"

    def check_feature(self, plan_id: str, feature: str) -> tuple[bool, str]:
        """
        校验套餐是否开放某功能
        Returns:
            (allowed, message)
        """
        if is_community():
            return True, ""
        if has_feature(plan_id, feature):
            return True, ""
        feature_msg = {
            FEATURE_OPENAPI_COMPLIANCE: "OpenAPI 合规核查仅旗舰版/无限版开放",
            FEATURE_GITHUB_ACTIONS: "GitHub Actions 集成仅无限版开放",
        }
        return False, feature_msg.get(feature, f"当前套餐未开放该功能")

    def check_team_size(
        self,
        plan_id: str,
        current_count: int,
        expansion_count: int = 0,
    ) -> tuple[bool, str]:
        """
        校验团队规模
        无限套餐限 10 人内，超员需扩容包；社区版无限制
        Args:
            plan_id: 套餐
            current_count: 当前成员数
            expansion_count: 已购扩容人数
        Returns:
            (allowed, message)
        """
        if is_community():
            return True, ""
        max_size = get_max_team_size(plan_id)
        if max_size is None:
            return True, ""
        allowed = max_size + expansion_count
        if current_count <= allowed:
            return True, ""
        return False, f"团队人数超限，无限版限 {max_size} 人，已扩容 {expansion_count} 人，当前 {current_count} 人，请购买扩容包"

    def check_single_limited_plan(self, current_plan_id: str, new_plan_id: str) -> tuple[bool, str]:
        """
        校验同一企业仅可购买 1 个基础/进阶/旗舰套餐
        """
        from .plans import get_plan
        new_plan = get_plan(new_plan_id)
        if not new_plan or not new_plan.is_limited_plan:
            return True, ""
        if current_plan_id and current_plan_id != new_plan_id:
            curr = get_plan(current_plan_id)
            if curr and curr.is_limited_plan:
                return False, "同一企业仅可购买一个基础/进阶/旗舰套餐，请先取消或升级现有套餐"
        return True, ""

    def record_api_call(self, count: int = 1) -> int:
        """记录 API 调用，返回当月累计；社区版仍记录但不限制"""
        return self._usage.record_call(count)
