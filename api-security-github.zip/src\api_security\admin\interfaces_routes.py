"""
远期迭代接口 - API 占位路由
仅返回接口状态与说明，不执行核心逻辑
"""

from flask import Blueprint, jsonify

from ..interfaces import (
    GitLabCIAdapter,
    BatchScanAdapter,
    CustomRulesAdapter,
    TeamPermissionAdapter,
)

interfaces_bp = Blueprint("interfaces", __name__, url_prefix="/api/interfaces")


@interfaces_bp.route("/gitlab-ci/status", methods=["GET"])
def gitlab_ci_status():
    """GitLab CI 接口状态 - 预留"""
    adapter = GitLabCIAdapter()
    return jsonify({
        "available": False,
        "message": "GitLab CI 集成待迭代实现",
        "is_gitlab_env": adapter.is_gitlab_ci(),
        "context": adapter.get_scan_context() if adapter.is_gitlab_ci() else {},
    })


@interfaces_bp.route("/batch-scan/status", methods=["GET"])
def batch_scan_status():
    """API 批量扫描接口状态 - 预留"""
    return jsonify({
        "available": False,
        "message": "API 批量扫描待迭代实现",
        "supported_params": ["urls", "timeout", "concurrency"],
    })


@interfaces_bp.route("/custom-rules/status", methods=["GET"])
def custom_rules_status():
    """自定义规则接口状态 - 预留"""
    adapter = CustomRulesAdapter()
    return jsonify({
        "available": False,
        "message": "自定义规则待迭代实现",
        "rules_path": str(adapter.get_rules_path()),
    })


@interfaces_bp.route("/team-permission/status", methods=["GET"])
def team_permission_status():
    """团队权限接口状态 - 预留"""
    return jsonify({
        "available": False,
        "message": "复杂权限管理待迭代实现",
        "features": ["role_assignment", "approval_flow"],
    })
