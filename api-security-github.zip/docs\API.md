# API 安全企业版 - 接口文档

## 概述

- **检测能力**：覆盖 OWASP API Top10 常见漏洞类型
- **合规核查**：基于 OpenAPI/Swagger 的 API 设计合规轻量核查
- **免责声明**：工具检测结果仅供参考，建议结合实际业务做安全评估

---

## 1. 健康检查

```
GET /api/health
```

**响应**：`{"status": "ok", "timestamp": "..."}`

---

## 2. 扫描任务

```
POST /api/scan
Content-Type: application/json
```

**请求体**：
```json
{
  "target": ".",
  "openapi": null,
  "afrog_url": null,
  "member_id": 1,
  "project": "项目名"
}
```

**响应**：
```json
{
  "success": true,
  "result_path": "...",
  "findings_count": 0,
  "openapi_parsed": true,
  "alerts": {
    "critical_popups": [],
    "high_notifications": [],
    "tool_disclaimer": "工具检测结果仅供参考，建议结合实际业务做安全评估"
  }
}
```

**权限**：需在套餐 API 限额内，超限返回 403。

---

## 3. 套餐与计费

### 3.1 套餐列表

```
GET /api/billing/plans
```

**响应**：
```json
{
  "plans": [
    {
      "id": "basic",
      "name": "基础版",
      "price_yearly": 299,
      "api_calls_per_month": 100000,
      "max_team_size": null,
      "expansion_price": 0,
      "features": ["team_admin"],
      "boundary": "基础版：同一企业仅限 1 个套餐"
    }
  ],
  "plan_single_limit": "同一企业仅限购买 1 个套餐（基础版/进阶版/旗舰版不可叠加）",
  "plan_unlimited_boundary": "无限版套餐含 10 人内，超员按 200 元/人/年扩容"
}
```

### 3.2 当前许可证

```
GET /api/billing/license
Header: X-Enterprise-Id: <企业ID>
```

### 3.3 购买/升级

```
POST /api/billing/license
Body: { "plan_id": "unlimited", "expansion_count": 0 }
```

---

## 4. 团队管理

### 4.1 成员列表

```
GET /api/admin/members
```

### 4.2 新增成员

```
POST /api/admin/members
Body: { "name": "张三", "email": "zhang@example.com" }
```

**权限**：受团队规模限制，无限版限 10 人内，超员需扩容。

### 4.3 统计

```
GET /api/admin/stats
```

返回各成员扫描次数与各等级漏洞数量。

### 4.4 漏洞筛选

```
GET /api/admin/findings?api_name=&severity=&tool=
```

返回 `findings` 列表，每条含 `id`（格式 `scan_file::index`）、`tool`、`severity`、`title`、`description`、`location`、`rule_id`、`owasp_category` 等。

### 4.5 漏洞详情（含修复建议）

```
GET /api/admin/findings/<id>
```

`id` 格式：`scan_file::index`（如 `scan_20240316_120000.json::0`）。

**响应**：
```json
{
  "id": "scan_xxx.json::0",
  "title": "可能的 SQL 注入风险",
  "severity": "high",
  "description": "...",
  "location": "src/api.py",
  "cve_id": null,
  "rule_id": "api-sql-injection",
  "owasp_category": "API8:2023",
  "tool": "semgrep",
  "remediation": "使用参数化查询或预编译语句...",
  "references": [{"name": "OWASP", "url": "https://..."}],
  "affected_endpoint": "src/api.py",
  "project": "",
  "timestamp": "",
  "ai_remediation": "AI 或静态修复建议",
  "ai_patch": {"before": "...", "after": "...", "language": "python"},
  "ai_patch_formatted": "补丁草稿文本，可复制应用",
  "ai_source": "llm|static"
}
```

**AI 修复建议**：配置 `OPENAI_API_KEY` 后，`ai_remediation` 为 LLM 生成；未配置时降级为静态建议。`ai_patch` 对 SQL 注入、硬编码密钥、缺失认证等类型提供补丁草稿。详见 `docs/AI_REPAIR_CONFIG.md`。

### 4.6 Critical 汇总

```
GET /api/admin/critical
```

返回团队所有 Critical 漏洞及 `alerts`（含弹窗/通知列表）。每条含 `id`，可调用 4.5 获取详情。

### 4.7 批量导出

```
POST /api/admin/export
Body: { "format": "excel"|"pdf", "api_name": "", "severity": "", "tool": "", "include_trend": true }
```

---

## 5. 功能引导

### 5.1 风控文案

```
GET /api/guide/disclaimers
```

返回 `detection_scope`、`compliance_scope`、`tool_disclaimer`、`plan_boundaries` 等。

### 5.2 升级提示

```
GET /api/guide/upgrade-prompt?severity=critical&vuln_name=
```

### 5.3 预售活动

```
GET /api/guide/presale?scan_count=&member_count=&finding_count=&has_critical=
```

高意向用户返回 `show: true` 及预售文案。

### 5.4 教程入口

```
GET /api/guide/tutorial?role=admin|developer|quickstart
```

---

## 6. 高危漏洞提醒

### 6.1 计算弹窗/通知

```
POST /api/alert/process
Body: { "findings": [...], "project": "" }
```

### 6.2 记录弹窗（24h 频率限制）

```
POST /api/alert/record-popup
Body: { "project": "", "fingerprint": "" }
```

---

## 7. 数据清理

```
GET  /api/admin/storage/cleanup-config
POST /api/admin/storage/cleanup-config
POST /api/admin/storage/cleanup
```

---

## 套餐边界说明

| 套餐 | 边界 |
|------|------|
| 基础版 | 同一企业仅限 1 个套餐 |
| 进阶版 | 同一企业仅限 1 个套餐 |
| 旗舰版 | 同一企业仅限 1 个套餐 |
| 无限版 | 含 10 人内，超员按 200 元/人/年扩容；同一企业仅限 1 个套餐 |
