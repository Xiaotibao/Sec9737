# API 安全企业版 - 集成指南

## 快速集成

### 1. 安装

```bash
pip install -r requirements.txt
# 或开发模式
pip install -e .
```

### 2. 直接调用检测函数

```python
from api_security.plugin import scan, parse_openapi, identify_openapi

# 完整扫描
result = scan(target="./your_project", openapi="./openapi.yaml")
print(result["detection"].findings)
print(result["compliance"])

# 仅解析 OpenAPI
success, spec, compliance = parse_openapi("./openapi.yaml")

# 自动识别文档
spec = identify_openapi("./project_dir")
```

### 3. 命令行

```bash
# 完整扫描
python -m api_security.cli scan . --openapi openapi.yaml --output result.json

# 仅解析
python -m api_security.cli parse openapi.yaml

# 自动识别
python -m api_security.cli identify .
```

### 4. 管理后台（团队管理 MVP）

```bash
python -m api_security.admin.run --port 5000
# 访问 http://localhost:5000/admin/ 打开管理界面
# 功能：成员管理、扫描统计、Critical 汇总、Excel/PDF 导出
# API 文档见 docs/API.md
```

### 5. GitHub Actions

将 `.github/workflows/api-security-scan.yml` 放入仓库即可启用 CI。

## 降级机制

- 解析失败时默认 **跳过** OpenAPI 合规检测，不影响漏洞扫描
- 使用 `--no-skip-on-fail` 可改为 **提示** 用户上传规范文档
- 支持 `identify_openapi()` 自动识别项目中的文档

## 配置模板

- `config/api_security.yaml` - 主配置
- `config/semgrep_rules.yaml` - 自定义 Semgrep 规则

## Cursor 调试

1. 在项目根目录打开
2. 断点可设在 `src/api_security/` 任意模块
3. 运行配置示例：`python -m api_security.cli scan .`
