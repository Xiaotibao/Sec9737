@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ========================================
echo   API 安全管理后台 - 一键启动
echo ========================================
echo.
echo 端口: 35555
echo 启动后请访问: http://127.0.0.1:35555/admin
echo.
python run_admin.py --port 35555
pause
