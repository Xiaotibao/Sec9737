"""
极简管理后台 - Flask 应用
提供扫描任务提交、结果查询、团队管理、统计、导出等 API
"""

import json
import os
from pathlib import Path
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory, redirect
from flask_cors import CORS

# 项目根目录（含 admin_static、src 的上级）
PROJECT_ROOT = Path(__file__).resolve().parents[3]
from .models import RESULTS_DIR

# 前端静态目录（admin_static 与 src 同级）
STATIC_DIR = PROJECT_ROOT / "admin_static"
STATIC_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "dev-secret-change-in-production")
CORS(app, supports_credentials=True)

# 多租户初始化：确保 default 租户存在，迁移旧数据
try:
    from ..tenant import ensure_default_tenant, migrate_to_tenant_storage
    ensure_default_tenant()
    migrate_to_tenant_storage()
except Exception:
    pass

# 注册蓝图
from .team_routes import admin_bp
from .alert_routes import alert_bp
from .filter_routes import filter_bp
from .trend_routes import trend_bp
from .storage_routes import storage_bp
from .interfaces_routes import interfaces_bp
from .billing_routes import billing_bp
from .guide_routes import guide_bp
from .audit_routes import audit_bp
from .webhook_routes import webhook_bp
from .api_change_routes import api_change_bp
from .native_rules_routes import native_rules_bp
from .super_routes import super_bp
from .sso_routes import sso_bp
app.register_blueprint(billing_bp)
app.register_blueprint(sso_bp)
app.register_blueprint(guide_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(audit_bp)
app.register_blueprint(webhook_bp)
app.register_blueprint(api_change_bp)
app.register_blueprint(native_rules_bp)
app.register_blueprint(alert_bp)
app.register_blueprint(filter_bp)
app.register_blueprint(trend_bp)
app.register_blueprint(storage_bp)
app.register_blueprint(interfaces_bp)
app.register_blueprint(super_bp)


@app.route("/")
def index():
    """根路径重定向到管理后台"""
    return redirect("/admin", code=302)


@app.route("/api/health", methods=["GET"])
def health():
    """健康检查"""
    return jsonify({"status": "ok", "timestamp": datetime.now().isoformat()})


@app.route("/api/edition", methods=["GET"])
def edition_info():
    """版本信息（社区版/商业版），供前端决定是否展示计费相关 UI"""
    from ..edition import is_community, edition_name
    return jsonify({"edition": edition_name(), "is_community": is_community()})


@app.route("/api/tenants", methods=["GET"])
def list_tenants_public():
    """列出租户（仅启用，供前端选择器使用）"""
    from ..tenant import list_tenants
    tenants = list_tenants(include_disabled=False)
    return jsonify({"tenants": [{"id": t.id, "name": t.name} for t in tenants]})


@app.route("/api/debug")
def debug_paths():
    """调试：检查路径是否正确"""
    idx = (STATIC_DIR / "index.html").exists()
    return jsonify({
        "PROJECT_ROOT": str(PROJECT_ROOT),
        "STATIC_DIR": str(STATIC_DIR),
        "index_exists": idx,
    })


def _run_scan_and_save(target_path, openapi, afrog_url, project, skip_compliance, member_id, checker, tenant_id="default", progress_callback=None):
    """执行扫描并保存结果，返回 (result_dict, scan_file)"""
    from ..core.scanner import run_api_scan
    result = run_api_scan(
        target=target_path,
        openapi=openapi,
        afrog_url=afrog_url,
        project=project,
        skip_compliance_check=skip_compliance,
        progress_callback=progress_callback,
    )
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    scan_file = f"scan_{ts}.json"
    out_path = RESULTS_DIR / scan_file
    out_data = {
        "timestamp": ts,
        "target": str(target_path),
        "detection": {
            "findings_count": len(result["detection"].findings),
            "findings": [
                {
                    "tool": f.tool,
                    "severity": f.severity,
                    "title": f.title,
                    "description": f.description,
                    "location": getattr(f, "location", None),
                    "cve_id": getattr(f, "cve_id", None),
                    "rule_id": getattr(f, "rule_id", None),
                    "owasp_category": getattr(f, "owasp_category", None),
                }
                for f in result["detection"].findings
            ],
            "tools_run": result["detection"].tools_run,
        },
        "openapi_parsed": result["openapi_parsed"],
        "compliance_skipped": result["compliance_skipped"],
    }
    if result["compliance"]:
        out_data["compliance"] = {
            "passed": result["compliance"].passed,
            "missing_security": result["compliance"].missing_security,
            "missing_auth_errors": result["compliance"].missing_auth_errors,
        }
    out_path.write_text(json.dumps(out_data, ensure_ascii=False, indent=2), encoding="utf-8")
    if member_id and project:
        from ..tenant import get_tenant_member, set_tenant_scan_metadata
        m = get_tenant_member(tenant_id, int(member_id))
        set_tenant_scan_metadata(tenant_id, scan_file, int(member_id), project, m.name if m else "")
    checker.record_api_call(1)
    return result, scan_file


def _trigger_scan_webhooks(result, scan_file: str, target: str, project: str = ""):
    """扫描完成后触发 Webhook（异步，不阻塞）"""
    try:
        from .webhook_trigger import trigger_scan_webhooks
        trigger_scan_webhooks(result, scan_file, target, project)
    except Exception:
        pass


def _log_scan_audit(target: str, scan_file: str, findings_count: int, success: bool, request_obj=None, operator: str = "system"):
    from .audit_log import log_audit_from_request, OP_SCAN
    resource = f"scan:{target} -> {scan_file}"
    detail = f"findings={findings_count}"
    log_audit_from_request(
        OP_SCAN, resource, "success" if success else "failed", operator, detail, request_obj
    )


@app.route("/api/scan", methods=["POST"])
def start_scan():
    """
    提交扫描任务
    Body: { "target": ".", "openapi": null, "afrog_url": null, "member_id": 1, "project": "项目名", "progress": true }
    progress=true 时异步执行，立即返回 task_id，可通过 GET /api/scan/status/<task_id> 轮询进度
    """
    from ..billing import PermissionChecker
    import threading
    from .scan_progress import create_task, update_progress, set_done, cleanup_old_tasks

    tenant_id = request.headers.get("X-Enterprise-Id") or (request.get_json() or {}).get("enterprise_id") or "default"
    checker = PermissionChecker(tenant_id)
    plan_id = checker.get_plan_id()
    ok, msg = checker.check_api_call(plan_id)
    if not ok:
        return jsonify({"success": False, "error": msg}), 403

    data = request.get_json() or {}
    target = data.get("target", ".")
    openapi = data.get("openapi")
    afrog_url = data.get("afrog_url")
    member_id = data.get("member_id")
    project = data.get("project", "")
    use_progress = data.get("progress", False)

    from ..billing.plans import FEATURE_OPENAPI_COMPLIANCE
    ok_f, _ = checker.check_feature(plan_id, FEATURE_OPENAPI_COMPLIANCE)
    skip_compliance = not ok_f and bool(openapi)
    target_path = Path(PROJECT_ROOT) / target if not Path(target).is_absolute() else Path(target)

    _audit_ip = (
        request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
        or request.headers.get("X-Real-IP", "")
        or (request.remote_addr or "")
    )
    _audit_operator = "system"
    if member_id:
        from ..tenant import get_tenant_member
        m = get_tenant_member(tenant_id, int(member_id))
        _audit_operator = (m.name or m.email) if m else "system"

    if use_progress:
        task_id = create_task()
        cleanup_old_tasks()

        def _cb(stage, progress, message):
            update_progress(task_id, stage, message, progress)

        def _run():
            try:
                result, scan_file = _run_scan_and_save(
                    target_path, openapi, afrog_url, project, skip_compliance, member_id, checker, tenant_id=tenant_id, progress_callback=_cb
                )
                set_done(task_id, result={
                    "success": True,
                    "result_path": str(RESULTS_DIR / scan_file),
                    "findings_count": len(result["detection"].findings),
                    "openapi_parsed": result["openapi_parsed"],
                    "alerts": result.get("alerts", {}),
                })
                _trigger_scan_webhooks(result, scan_file, target, project)
                from .audit_log import log_audit_from_request, OP_SCAN
                log_audit_from_request(OP_SCAN, f"scan:{target} -> {scan_file}", "success", _audit_operator, f"findings={len(result['detection'].findings)}", ip=_audit_ip)
            except Exception as e:
                set_done(task_id, error=str(e))
                from .audit_log import log_audit_from_request, OP_SCAN
                log_audit_from_request(OP_SCAN, f"scan:{target}", "failed", _audit_operator, str(e), ip=_audit_ip)

        threading.Thread(target=_run, daemon=True).start()
        return jsonify({"success": True, "task_id": task_id})
    else:
        try:
            result, scan_file = _run_scan_and_save(
                target_path, openapi, afrog_url, project, skip_compliance, member_id, checker, tenant_id=tenant_id
            )
            _trigger_scan_webhooks(result, scan_file, target, project)
            _log_scan_audit(target, scan_file, len(result["detection"].findings), True, request, _audit_operator)
            return jsonify({
                "success": True,
                "result_path": str(RESULTS_DIR / scan_file),
                "findings_count": len(result["detection"].findings),
                "openapi_parsed": result["openapi_parsed"],
                "alerts": result.get("alerts", {}),
            })
        except Exception as e:
            from .audit_log import log_audit_from_request, OP_SCAN
            log_audit_from_request(OP_SCAN, f"scan:{target}", "failed", _audit_operator, str(e), request)
            return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/scan/status/<task_id>", methods=["GET"])
def scan_status(task_id):
    """获取扫描进度"""
    from .scan_progress import get_progress
    p = get_progress(task_id)
    if not p:
        return jsonify({"error": "任务不存在"}), 404
    return jsonify(p)


@app.route("/api/results", methods=["GET"])
def list_results():
    """列出历史扫描结果（按租户隔离）"""
    from ..tenant import get_tenant_id_from_request, get_tenant_scan_metadata
    tenant_id = get_tenant_id_from_request(request)
    meta = get_tenant_scan_metadata(tenant_id)
    allowed = set(meta.keys())
    items = []
    for p in sorted(RESULTS_DIR.glob("scan_*.json"), reverse=True)[:50]:
        if tenant_id != "default" and p.name not in allowed:
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            items.append({
                "file": p.name,
                "timestamp": data.get("timestamp"),
                "target": data.get("target"),
                "findings_count": data.get("detection", {}).get("findings_count", 0),
            })
        except Exception:
            pass
    return jsonify({"results": items[:20]})


@app.route("/api/results/<name>", methods=["GET"])
def get_result(name):
    """获取单次扫描详情（按租户隔离）"""
    from ..tenant import get_tenant_id_from_request, get_tenant_scan_metadata
    if ".." in name or not name.startswith("scan_"):
        return jsonify({"error": "Not found"}), 404
    path = RESULTS_DIR / name
    if not path.exists():
        return jsonify({"error": "Not found"}), 404
    tenant_id = get_tenant_id_from_request(request)
    meta = get_tenant_scan_metadata(tenant_id)
    if tenant_id != "default" and name not in meta:
        return jsonify({"error": "Not found"}), 404
    data = json.loads(path.read_text(encoding="utf-8"))
    return jsonify(data)


@app.route("/admin/<path:filename>")
def admin_static(filename):
    """管理后台静态资源"""
    path = STATIC_DIR / filename
    if not path.exists() or path.is_dir():
        return "Not Found", 404
    return send_from_directory(str(STATIC_DIR), filename)


@app.route("/admin/")
@app.route("/admin")
def admin_index():
    """管理后台首页 - 直接读取文件避免路径问题"""
    html_path = STATIC_DIR / "index.html"
    if not html_path.exists():
        return f"index.html not found at {html_path}", 404
    return html_path.read_text(encoding="utf-8"), 200, {"Content-Type": "text/html; charset=utf-8"}


def run(host: str = "0.0.0.0", port: int = 5000, debug: bool = False):
    """启动后台服务"""
    app.run(host=host, port=port, debug=debug)
