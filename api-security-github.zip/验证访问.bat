@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===== 步骤1: 验证浏览器能否访问 =====
echo 使用 Python 内置服务器，无额外依赖
echo 若能看到管理后台页面（数据可能为空），说明环境正常
echo.
python 独立服务器.py
pause
