"""
租户模型 - 企业/租户 CRUD
"""

import json
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
TENANTS_FILE = DATA_DIR / "tenants.json"


@dataclass
class Tenant:
    id: str
    name: str
    enabled: bool = True
    sso_issuer: Optional[str] = None
    sso_client_id: Optional[str] = None
    sso_client_secret: Optional[str] = None  # 加密存储
    sso_type: str = "oidc"  # oidc | saml

    def to_dict(self) -> dict:
        d = asdict(self)
        if d.get("sso_client_secret"):
            d["sso_client_secret"] = "***"
        return d


def _load() -> dict:
    if not TENANTS_FILE.exists():
        return {}
    try:
        return json.loads(TENANTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: dict):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    TENANTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def ensure_default_tenant() -> None:
    """确保 default 租户存在"""
    data = _load()
    if "default" not in data:
        data["default"] = {
            "id": "default",
            "name": "默认企业",
            "enabled": True,
            "sso_issuer": None,
            "sso_client_id": None,
            "sso_client_secret": None,
            "sso_type": "oidc",
        }
        _save(data)


def get_tenant(tenant_id: str) -> Optional[Tenant]:
    """获取租户"""
    data = _load()
    t = data.get(tenant_id)
    if not t or not isinstance(t, dict):
        return None
    return Tenant(
        id=t.get("id", tenant_id),
        name=t.get("name", tenant_id),
        enabled=t.get("enabled", True),
        sso_issuer=t.get("sso_issuer"),
        sso_client_id=t.get("sso_client_id"),
        sso_client_secret=t.get("sso_client_secret"),
        sso_type=t.get("sso_type", "oidc"),
    )


def list_tenants(include_disabled: bool = False) -> list[Tenant]:
    """列出租户"""
    ensure_default_tenant()
    data = _load()
    result = []
    for tid, t in data.items():
        if not isinstance(t, dict):
            continue
        tenant = Tenant(
            id=t.get("id", tid),
            name=t.get("name", tid),
            enabled=t.get("enabled", True),
            sso_issuer=t.get("sso_issuer"),
            sso_client_id=t.get("sso_client_id"),
            sso_client_secret=t.get("sso_client_secret"),
            sso_type=t.get("sso_type", "oidc"),
        )
        if include_disabled or tenant.enabled:
            result.append(tenant)
    return result


def create_tenant(tenant_id: str, name: str, enabled: bool = True) -> Optional[Tenant]:
    """创建租户"""
    data = _load()
    if tenant_id in data:
        return None
    data[tenant_id] = {
        "id": tenant_id,
        "name": name,
        "enabled": enabled,
        "sso_issuer": None,
        "sso_client_id": None,
        "sso_client_secret": None,
        "sso_type": "oidc",
    }
    _save(data)
    return get_tenant(tenant_id)


def update_tenant(
    tenant_id: str,
    name: Optional[str] = None,
    enabled: Optional[bool] = None,
    sso_issuer: Optional[str] = None,
    sso_client_id: Optional[str] = None,
    sso_client_secret: Optional[str] = None,
    sso_type: Optional[str] = None,
) -> Optional[Tenant]:
    """更新租户"""
    data = _load()
    if tenant_id not in data or not isinstance(data[tenant_id], dict):
        return None
    t = data[tenant_id]
    if name is not None:
        t["name"] = name
    if enabled is not None:
        t["enabled"] = enabled
    if sso_issuer is not None:
        t["sso_issuer"] = sso_issuer
    if sso_client_id is not None:
        t["sso_client_id"] = sso_client_id
    if sso_client_secret is not None:
        t["sso_client_secret"] = sso_client_secret
    if sso_type is not None:
        t["sso_type"] = sso_type
    _save(data)
    return get_tenant(tenant_id)


def get_tenant_data_dir(tenant_id: str) -> Path:
    """租户数据目录"""
    return DATA_DIR / "tenants" / tenant_id
