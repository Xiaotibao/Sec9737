"""
修复建议模板与参考链接库
按 rule_id、title 关键词、owasp_category 匹配
"""

from typing import Optional

# 修复建议模板：rule_id 或 title 关键词 -> (remediation, references)
REMEDIATION_TEMPLATES = {
    # SQL 注入
    "api-sql-injection": (
        "使用参数化查询或预编译语句，避免将用户输入直接拼接到 SQL 中。"
        "示例：cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        ["https://owasp.org/www-community/attacks/SQL_Injection", "https://cwe.mitre.org/data/definitions/89.html"],
    ),
    "owasp-api8-sql-injection": (
        "使用参数化查询或预编译语句，避免将用户输入直接拼接到 SQL 中。"
        "示例：cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        ["https://owasp.org/www-community/attacks/SQL_Injection", "https://cwe.mitre.org/data/definitions/89.html"],
    ),
    # 命令注入
    "owasp-api8-command-injection": (
        "避免将用户输入传入 os.system、subprocess 等。若必须执行命令，使用白名单校验输入，"
        "或使用 subprocess 的列表参数形式而非 shell=True。",
        ["https://owasp.org/www-community/attacks/Command_Injection", "https://cwe.mitre.org/data/definitions/78.html"],
    ),
    # NoSQL 注入
    "owasp-api8-nosql-injection": (
        "避免使用 $where、$regex 等操作符拼接用户输入。对用户输入进行类型校验和白名单过滤。",
        ["https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/05-Testing_for_NoSQL_Injection"],
    ),
    # 硬编码密钥
    "api-hardcoded-secret": (
        "将密钥、密码等敏感信息移至环境变量或密钥管理服务（如 Vault、AWS Secrets Manager），"
        "切勿将凭证提交到代码仓库。",
        ["https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_password", "https://cwe.mitre.org/data/definitions/798.html"],
    ),
    "owasp-api2-hardcoded-credentials": (
        "将密钥、密码等敏感信息移至环境变量或密钥管理服务，切勿将凭证提交到代码仓库。",
        ["https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_password"],
    ),
    # 缺失认证
    "api-missing-auth": (
        "为 API 路由添加认证中间件或装饰器，确保未认证请求返回 401。"
        "示例：@require_auth 或 app.use(authMiddleware)。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/", "https://owasp.org/API-Security/editions/2023/en/0xa5-broken-function-level-authorization/"],
    ),
    "owasp-api5-missing-auth-decorator": (
        "为 API 路由添加认证/授权装饰器，确保未认证请求返回 401，未授权返回 403。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa5-broken-function-level-authorization/"],
    ),
    # 敏感字段暴露
    "compliance-sensitive-field": (
        "从响应 schema 中移除敏感字段（如 password、api_key），或使用单独的 DTO 仅返回必要字段。"
        "对必须返回的敏感信息进行脱敏。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/"],
    ),
    "owasp-api3-object-assign-req-body": (
        "使用白名单明确允许更新的字段，避免 Object.assign(req.body) 或展开运算符导致批量分配。"
        "示例：const { name, email } = req.body; User.update({ name, email });",
        ["https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/"],
    ),
    "owasp-api6-patch-body-direct": (
        "对 PATCH/PUT 请求体进行白名单校验，仅允许更新指定字段，拒绝 role、isAdmin 等敏感属性。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/"],
    ),
    # 自研规则
    "native-idor-req-params": (
        "使用 req.params/query 中的 ID 前，校验该资源归属于当前用户或当前用户有权限访问。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/"],
    ),
    "native-hardcoded-secret": (
        "将密钥、密码等敏感信息移至环境变量或密钥管理服务，切勿将凭证提交到代码仓库。",
        ["https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_password"],
    ),
    "native-skip-auth": (
        "移除跳过认证的配置，确保生产环境所有接口均需认证。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/"],
    ),
    "native-sql-fstring": (
        "使用参数化查询或预编译语句，避免 f-string 拼接 SQL。",
        ["https://owasp.org/www-community/attacks/SQL_Injection"],
    ),
    # IDOR
    "owasp-api1-idor-path-param": (
        "在返回资源前校验当前用户是否有权访问该对象。"
        "示例：if (resource.owner_id !== currentUser.id) return 403;",
        ["https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/", "https://cwe.mitre.org/data/definitions/639.html"],
    ),
    "owasp-api1-idor-req-params": (
        "使用 req.params/query 中的 ID 前，校验该资源归属于当前用户或当前用户有权限访问。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/"],
    ),
    # 安全配置
    "owasp-api7-cors-wildcard": (
        "将 CORS 的 Access-Control-Allow-Origin 设置为具体域名，避免使用 *。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa8-security-misconfiguration/"],
    ),
    "owasp-api7-debug-enabled": (
        "生产环境禁用 debug 模式，避免泄露堆栈和内部信息。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa8-security-misconfiguration/"],
    ),
    # 日志
    "api-sensitive-log": (
        "避免将用户输入、密码等敏感信息写入日志。对日志中的 PII 进行脱敏。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa10-unsafe-consumption-of-apis/"],
    ),
    "owasp-api10-sensitive-in-log": (
        "避免将用户输入、密码等敏感信息写入日志。对日志中的 PII 进行脱敏。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa10-unsafe-consumption-of-apis/"],
    ),
    "owasp-api10-password-in-log": (
        "日志中不应包含密码、Token 等敏感信息。使用占位符或完全省略。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa10-unsafe-consumption-of-apis/"],
    ),
    # 缺失 401/403 定义
    "compliance-missing-auth-errors": (
        "在 OpenAPI 的 responses 中为接口添加 401、403 错误定义，便于文档与客户端处理。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa2-broken-authentication/"],
    ),
    "compliance-missing-security": (
        "在 OpenAPI 的 security 中为接口定义认证方式（如 Bearer、ApiKey），公开接口显式使用 security: []。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa5-broken-function-level-authorization/"],
    ),
    # 废弃接口
    "compliance-deprecated": (
        "制定废弃接口的迁移计划，在文档中标注替代接口与下线时间，逐步引导调用方迁移。",
        ["https://owasp.org/API-Security/editions/2023/en/0xa9-improper-inventory-management/"],
    ),
}

# 按 title 关键词匹配（当 rule_id 无匹配时）
TITLE_KEYWORDS = [
    ("sql", REMEDIATION_TEMPLATES["api-sql-injection"]),
    ("injection", REMEDIATION_TEMPLATES["api-sql-injection"]),
    ("硬编码", REMEDIATION_TEMPLATES["api-hardcoded-secret"]),
    ("secret", REMEDIATION_TEMPLATES["api-hardcoded-secret"]),
    ("password", REMEDIATION_TEMPLATES["api-hardcoded-secret"]),
    ("认证", REMEDIATION_TEMPLATES["api-missing-auth"]),
    ("auth", REMEDIATION_TEMPLATES["api-missing-auth"]),
    ("CVE", ("检查依赖版本，升级至无漏洞版本。参考：https://nvd.nist.gov/", ["https://nvd.nist.gov/", "https://owasp.org/API-Security/editions/2023/en/0xa10-unsafe-consumption-of-apis/"])),
]


def get_remediation(rule_id: Optional[str], title: Optional[str]) -> str:
    """根据 rule_id 或 title 获取修复建议"""
    if rule_id and rule_id in REMEDIATION_TEMPLATES:
        return REMEDIATION_TEMPLATES[rule_id][0]
    title_lower = (title or "").lower()
    for kw, (remed, _) in TITLE_KEYWORDS:
        if kw in title_lower:
            return remed
    return "请结合具体业务场景进行安全加固，建议参考 OWASP API Security Top 10：https://owasp.org/API-Security/editions/2023/en/"


def get_references(rule_id: Optional[str], title: Optional[str], cve_id: Optional[str], owasp_category: Optional[str]) -> list[dict]:
    """
    获取参考链接列表
    返回 [{"name": "OWASP", "url": "..."}, ...]
    """
    refs = []
    if rule_id and rule_id in REMEDIATION_TEMPLATES:
        for url in REMEDIATION_TEMPLATES[rule_id][1]:
            name = "OWASP" if "owasp" in url.lower() else ("CWE" if "cwe" in url.lower() else "参考")
            refs.append({"name": name, "url": url})
    else:
        for kw, (_, urls) in TITLE_KEYWORDS:
            if kw in (title or "").lower():
                for url in urls:
                    refs.append({"name": "参考", "url": url})
                break
    if cve_id:
        refs.append({"name": "NVD", "url": f"https://nvd.nist.gov/vuln/detail/{cve_id}"})
    if owasp_category and not any("owasp" in r["url"].lower() for r in refs):
        refs.append({"name": "OWASP API Top 10", "url": "https://owasp.org/API-Security/editions/2023/en/"})
    if not refs:
        refs.append({"name": "OWASP API Top 10", "url": "https://owasp.org/API-Security/editions/2023/en/"})
    return refs


def enrich_finding_detail(finding: dict) -> dict:
    """
    为单条 finding 补充 remediation、references、affected_endpoint
    返回完整的 FindingDetail 结构
    """
    rule_id = finding.get("rule_id")
    title = finding.get("title", "")
    cve_id = finding.get("cve_id")
    owasp_category = finding.get("owasp_category")
    location = finding.get("location", "")
    remediation = get_remediation(rule_id, title)
    references = get_references(rule_id, title, cve_id, owasp_category)
    affected_endpoint = location if "http" in str(location) or "/" in str(location) else (finding.get("affected_endpoint") or location)
    return {
        "id": finding.get("id"),
        "title": finding.get("title", ""),
        "severity": finding.get("severity", ""),
        "description": finding.get("description", ""),
        "location": location,
        "cve_id": cve_id,
        "rule_id": rule_id,
        "owasp_category": owasp_category,
        "tool": finding.get("tool", ""),
        "remediation": remediation,
        "references": references,
        "affected_endpoint": affected_endpoint,
        "project": finding.get("project", ""),
        "timestamp": finding.get("timestamp", ""),
    }
