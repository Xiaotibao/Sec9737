"""
API 安全企业版 - 主包
基于 OpenSCA + Semgrep + afrog 技术栈，覆盖常见 API 安全风险
"""

__version__ = "1.0.0"
