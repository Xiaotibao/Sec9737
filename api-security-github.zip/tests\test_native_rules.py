"""
自研规则库测试
"""

import tempfile
from pathlib import Path

import pytest

from api_security.native_rules import NativeRuleEngine, load_rules
from api_security.native_rules.loader import set_rule_enabled, get_rule_enabled_overrides


class TestRuleLoader:
    def test_load_rules(self):
        rules = load_rules()
        assert len(rules) >= 20
        ids = [r.id for r in rules]
        assert "native-idor-req-params" in ids
        assert "native-hardcoded-secret" in ids

    def test_set_rule_enabled(self):
        set_rule_enabled("native-test-rule", False)
        overrides = get_rule_enabled_overrides()
        assert overrides.get("native-test-rule") is False
        set_rule_enabled("native-test-rule", True)
        overrides = get_rule_enabled_overrides()
        assert overrides.get("native-test-rule") is True


class TestRuleEngine:
    def test_scan_finds_hardcoded_secret(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "test.py"
            p.write_text('password = "secret123"', encoding="utf-8")
            engine = NativeRuleEngine()
            findings = engine.scan_path(p)
            assert len(findings) >= 1
            assert any("硬编码" in f.title or "password" in f.title.lower() for f in findings)

    def test_scan_finds_idor(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "test.js"
            p.write_text("const id = req.params.user_id;", encoding="utf-8")
            engine = NativeRuleEngine()
            findings = engine.scan_path(p)
            assert len(findings) >= 1
            assert any("IDOR" in f.title for f in findings)

    def test_scan_empty_dir(self):
        with tempfile.TemporaryDirectory() as d:
            engine = NativeRuleEngine()
            findings = engine.scan_path(d)
            assert len(findings) == 0
