#!/usr/bin/env python3
"""
本地报告生成脚本
将 scan-result.json 转为可读的 Markdown 报告
"""

import json
import sys
from pathlib import Path

# 添加 src 到路径以导入 risk_control
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
try:
    from api_security.risk_control import TOOL_DISCLAIMER
except ImportError:
    TOOL_DISCLAIMER = "工具检测结果仅供参考，建议结合实际业务做安全评估"
import os
import sys
from datetime import datetime


def generate_report(json_path: str = "scan-result.json", out_path: str = "api-security-report.md") -> int:
    """生成 Markdown 报告"""
    if not os.path.exists(json_path):
        print(f"Scan result not found: {json_path}", file=sys.stderr)
        return 1

    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    detection = data.get("detection", {})
    findings = detection.get("findings", [])
    tools_run = detection.get("tools_run", [])

    lines = [
        "# API Security Scan Report",
        "",
        f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        f"> {TOOL_DISCLAIMER}",
        "",
        "## Summary",
        "",
        f"- **Findings**: {len(findings)}",
        f"- **Tools Run**: {', '.join(tools_run) or 'None'}",
        f"- **OpenAPI Parsed**: {data.get('openapi_parsed', False)}",
        f"- **Compliance Skipped**: {data.get('compliance_skipped', False)}",
        "",
        "## Findings",
        "",
    ]

    if findings:
        for i, f in enumerate(findings, 1):
            lines.extend([
                f"### {i}. [{f.get('severity', 'N/A').upper()}] {f.get('title', 'N/A')}",
                "",
                f"- **Tool**: {f.get('tool', 'N/A')}",
                f"- **Description**: {f.get('description', '')}",
                f"- **Location**: {f.get('location', 'N/A')}",
                "",
            ])
    else:
        lines.append("No vulnerabilities found.\n")

    compliance = data.get("compliance", {})
    if compliance:
        lines.extend([
            "## Compliance",
            "",
            f"- **Passed**: {compliance.get('passed', False)}",
            f"- **Missing Security**: {compliance.get('missing_security', [])}",
            f"- **Missing Auth Errors**: {compliance.get('missing_auth_errors', [])}",
            "",
        ])

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Report saved to {out_path}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) >= 3:
        json_path, out_path = sys.argv[1], sys.argv[2]
    elif len(sys.argv) == 2:
        json_path, out_path = sys.argv[1], "api-security-report.md"
    else:
        json_path = os.environ.get("SCAN_RESULT_JSON", "scan-result.json")
        out_path = os.environ.get("REPORT_OUTPUT", "api-security-report.md")
    sys.exit(generate_report(json_path, out_path))
