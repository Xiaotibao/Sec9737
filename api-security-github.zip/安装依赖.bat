@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在安装依赖...
set PYTHONIOENCODING=utf-8
pip install -r requirements-admin.txt -q
if %errorlevel% neq 0 (
  echo 若出现编码错误，请尝试: pip install flask flask-cors waitress openpyxl reportlab
  pause
  exit /b 1
)
echo 依赖安装完成
pause
