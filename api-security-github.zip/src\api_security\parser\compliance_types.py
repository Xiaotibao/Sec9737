"""
合规核查类型定义
"""

from dataclasses import dataclass, field


@dataclass
class ComplianceResult:
    """合规核查结果"""
    missing_security: list[str] = field(default_factory=list)
    sensitive_fields_in_response: list[dict] = field(default_factory=list)
    missing_auth_errors: list[str] = field(default_factory=list)
    deprecated_operations: list[str] = field(default_factory=list)  # API9:2023
    passed: bool = True
