# API 安全企业版 - 完整交付包

## 交付清单

| 类型 | 路径 | 说明 |
|------|------|------|
| **插件代码** | `src/api_security/` | 核心检测、解析、告警、计费、引导模块 |
| **管理后台** | `admin_static/`、`src/api_security/admin/` | 极简团队管理后台前端与 API |
| **配置模板** | `config/`、`.github/workflows/` | api_security 配置、GitHub Actions 模板 |
| **接口文档** | `docs/API.md` | 完整 REST API 说明 |
| **使用教程** | `docs/USER_GUIDE.md` | 快速开始、集成、常见问题 |
| **启动脚本** | `run_admin.py` | 一键启动管理后台 |

---

## 快速部署

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 启动管理后台
python run_admin.py --port 5000

# 3. 访问
# http://localhost:5000/admin
```

---

## 功能模块一览

### 高优先级
- **API 漏洞检测**：OpenSCA + Semgrep + afrog，覆盖 OWASP API Top10
- **OpenAPI 解析与合规**：2.0/3.0 全版本，轻量设计合规核查
- **降级机制**：解析失败时跳过合规，不影响扫描流程

### 中优先级
- **GitHub Actions CI/CD**：基础版/进阶版模板，钉钉/企业微信告警
- **极简团队管理后台**：成员、统计、Critical 汇总、批量导出
- **高危漏洞弹窗**：24h 频率限制、本月不再提醒
- **套餐权限管控**：API 限额、功能开放、团队规模校验

### 配套模块
- **企业版引导**：升级入口、价值提示、高意向识别、预售活动
- **风险风控**：统一表述、免责声明、套餐边界标注、CI/CD 环境提示

---

## 测试验证

```bash
# 单元测试 + 集成测试
$env:PYTHONPATH="src"
python -m pytest tests/ -v
```

---

## 版本信息

- 检测能力：覆盖 OWASP API Top10 常见漏洞类型
- 合规核查：基于 OpenAPI/Swagger 的 API 设计合规轻量核查
- 免责声明：工具检测结果仅供参考，建议结合实际业务做安全评估
