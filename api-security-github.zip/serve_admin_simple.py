#!/usr/bin/env python3
"""
极简管理后台启动 - 备用启动方式
直接运行: python serve_admin_simple.py
"""
import sys
from pathlib import Path

# 确保能导入 api_security
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

if __name__ == "__main__":
    from api_security.admin.app import app, STATIC_DIR
    port = 5001
    idx = (STATIC_DIR / "index.html").exists()
    print("=" * 50)
    print("API 安全管理后台")
    print(f"浏览器打开: http://127.0.0.1:{port}/admin")
    print(f"静态目录: {STATIC_DIR}")
    print(f"index.html: {'存在' if idx else '不存在'}")
    print("=" * 50)
    app.run(host="127.0.0.1", port=port, debug=False)
