"""
API 变更影响分析测试
"""

import pytest

from api_security.api_change import openapi_diff, analyze_change_impact, generate_change_report


OLD_SPEC = {
    "openapi": "3.0.0",
    "paths": {
        "/api/users": {
            "get": {
                "security": [{"bearer": []}],
                "responses": {"200": {"description": "OK"}, "401": {"description": "Unauthorized"}},
            },
        },
        "/api/public": {
            "get": {"responses": {"200": {"description": "OK"}}},
        },
    },
}

NEW_SPEC_REMOVE_AUTH = {
    "openapi": "3.0.0",
    "paths": {
        "/api/users": {
            "get": {
                "responses": {"200": {"description": "OK"}},
            },
        },
        "/api/public": {
            "get": {"responses": {"200": {"description": "OK"}}},
        },
    },
}

NEW_SPEC_ADD_SENSITIVE = {
    "openapi": "3.0.0",
    "paths": {
        "/api/users": {
            "get": {
                "security": [{"bearer": []}],
                "responses": {
                    "200": {
                        "description": "OK",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "properties": {
                                        "id": {"type": "integer"},
                                        "password": {"type": "string"},
                                    }
                                }
                            }
                        },
                    },
                    "401": {"description": "Unauthorized"},
                },
            },
        },
    },
}


class TestOpenApiDiff:
    def test_paths_added_removed(self):
        old = {"paths": {"/a": {"get": {}}, "/b": {"get": {}}}}
        new = {"paths": {"/a": {"get": {}}, "/c": {"get": {}}}}
        r = openapi_diff(old, new)
        assert "/c" in r["paths_added"]
        assert "/b" in r["paths_removed"]
        assert "GET /c" in r["operations_added"]
        assert "GET /b" in r["operations_removed"]

    def test_operations_modified(self):
        r = openapi_diff(OLD_SPEC, NEW_SPEC_REMOVE_AUTH)
        assert "GET /api/users" in r["operations_modified"] or any(
            m["op_id"] == "GET /api/users" for m in r["operations_modified"]
        )


class TestImpactAnalysis:
    def test_auth_removed_critical(self):
        r = openapi_diff(OLD_SPEC, NEW_SPEC_REMOVE_AUTH)
        findings = analyze_change_impact(r)
        critical = [f for f in findings if f["severity"] == "critical"]
        assert len(critical) >= 1
        assert any("认证" in f["title"] for f in critical)

    def test_sensitive_field_added_high(self):
        old = {
            "paths": {
                "/api/users": {
                    "get": {
                        "responses": {
                            "200": {
                                "content": {
                                    "application/json": {"schema": {"properties": {"id": {"type": "integer"}}}}
                                }
                            }
                        }
                    }
                }
            }
        }
        r = openapi_diff(old, NEW_SPEC_ADD_SENSITIVE)
        findings = analyze_change_impact(r)
        high = [f for f in findings if f["severity"] == "high"]
        assert any("敏感" in f.get("title", "") for f in high)


class TestReport:
    def test_generate_report(self):
        report = generate_change_report(OLD_SPEC, NEW_SPEC_REMOVE_AUTH)
        assert "diff" in report
        assert "findings" in report
        assert "summary" in report
        assert "has_critical" in report
        assert report["has_critical"] is True
