# CI/CD 集成文档

支持 GitHub Actions、GitLab CI、Jenkins 等平台，将 API 安全扫描接入流水线。

## 一、环境变量与密钥

### 必填

| 变量 | 说明 | 配置位置 |
|------|------|----------|
| `UNLIMITED_PACKAGE_TOKEN` | 无限套餐凭证（3999元/年） | 联系获取后配置为 Secret |

### 可选（告警）

| 变量 | 说明 | 配置位置 |
|------|------|----------|
| `DINGTALK_WEBHOOK` | 钉钉群机器人 Webhook | 群设置 → 智能群助手 → 添加机器人 |
| `WECOM_WEBHOOK` | 企业微信群机器人 Webhook | 群设置 → 群机器人 → 添加 |
| `FEISHU_WEBHOOK` | 飞书群机器人 Webhook | 通过管理后台 Webhook 配置 |

> 告警也可通过管理后台「Webhook」页配置，支持飞书、Slack 等。

---

## 二、GitHub Actions

### 模板

| 模板 | 功能 |
|------|------|
| `.github/workflows/api-security-basic.yml` | 扫描 + 本地报告 |
| `.github/workflows/api-security-advanced.yml` | 扫描 + 钉钉/企业微信告警 |

### 配置步骤

1. 复制模板到 `.github/workflows/`
2. 仓库 Settings → Secrets and variables → Actions 添加：
   - `UNLIMITED_PACKAGE_TOKEN`（必填）
   - `DINGTALK_WEBHOOK` 或 `WECOM_WEBHOOK`（可选）
3. 推送代码或手动触发 `workflow_dispatch`

### 阻断流水线

默认扫描失败不阻断。如需发现漏洞时失败，在模板中搜索「如需阻断流水线」，按注释取消对应 job。

---

## 三、GitLab CI

### 模板

| 文件 | 功能 |
|------|------|
| `.gitlab-ci-api-security-basic.yml.example` | 扫描 + 本地报告 |
| `.gitlab-ci-api-security-advanced.yml.example` | 扫描 + 钉钉/企业微信告警 |

### 配置步骤

1. 复制模板为 `.gitlab-ci.yml`，或通过 `include` 引入：

   ```yaml
   include:
     - local: '.gitlab-ci-api-security-basic.yml.example'
   ```

2. Settings → CI/CD → Variables 添加（Masked 推荐）：
   - `UNLIMITED_PACKAGE_TOKEN`（必填）
   - `DINGTALK_WEBHOOK` 或 `WECOM_WEBHOOK`（可选）

3. 推送代码触发流水线

### 增量扫描

GitLab 模板在 **MR 场景** 下自动使用增量扫描（`CI_MERGE_REQUEST_TARGET_BRANCH_NAME` 作为基准），仅扫描变更文件以缩短时间。

### 环境变量映射

告警脚本使用 GitHub 风格变量，GitLab CI 会自动映射：

| GitLab CI | 等效 GitHub |
|-----------|-------------|
| `CI_PROJECT_PATH` | `GITHUB_REPOSITORY` |
| `CI_COMMIT_REF_NAME` | `GITHUB_REF` |
| `CI_PIPELINE_ID` | `GITHUB_RUN_ID` |
| `CI_SERVER_URL` | `GITHUB_SERVER_URL` |

---

## 四、Jenkins

### 模板

| 文件 | 功能 |
|------|------|
| `Jenkinsfile.api-security.example` | 扫描 + 报告 + 可选告警 |

### 配置步骤

1. 复制 `Jenkinsfile.api-security.example` 为 `Jenkinsfile`
2. 在 Pipeline 配置中指定 Jenkinsfile 路径
3. 配置凭据或环境变量：
   - **凭据**：Manage Jenkins → Credentials，添加 Secret text，ID 为 `UNLIMITED_PACKAGE_TOKEN`
   - **环境变量**：Pipeline 或全局环境变量中设置：
     - `UNLIMITED_PACKAGE_TOKEN`（必填）
     - `DINGTALK_WEBHOOK`、`WECOM_WEBHOOK`（可选）

4. 构建触发：轮询 SCM、Webhook 或定时

### 增量扫描

Jenkins 模板在 **有 `GIT_PREVIOUS_COMMIT`** 时自动使用增量扫描（Git 插件提供），仅扫描变更文件以缩短时间。

### 环境变量

Jenkins 提供 `JOB_NAME`、`GIT_BRANCH`、`BUILD_NUMBER`、`JENKINS_URL`、`GIT_PREVIOUS_COMMIT`，告警脚本会适配使用。

---

## 五、增量扫描（缩短 CI 时间）

当仅变更少量文件时，使用 `--incremental` 可显著缩短扫描时间：

```bash
# 仅扫描 git 变更文件
python -m api_security.cli scan . --incremental --output scan-result.json

# 指定基准分支（默认 origin/main 或 origin/master）
python -m api_security.cli scan . --incremental --base-ref origin/develop

# 与上次结果合并展示（需先保存上次输出）
python -m api_security.cli scan . --incremental --previous-result scan-result.json --output scan-result.json
```

**增量策略**：

- Semgrep：仅对变更文件执行静态分析
- OpenSCA：增量模式下跳过（依赖可缓存，建议定期全量）
- OpenAPI 合规：若 OpenAPI 文档未变更则跳过

**CI 环境变量**：自动识别 `GITHUB_BASE_REF`、`CI_MERGE_REQUEST_TARGET_BRANCH_NAME`、`GIT_PREVIOUS_COMMIT` 作为基准引用。

详见 [增量扫描说明](INCREMENTAL_SCAN.md)。

---

## 六、通用说明

### 扫描命令

```bash
export PYTHONPATH=src
python -m api_security.cli scan . --output scan-result.json
```

### 全量 vs 增量

| 模式 | 命令 | 适用场景 |
|------|------|----------|
| 全量 | `scan . --output out.json` | 首次扫描、定期全量 |
| 增量 | `scan . --incremental --output out.json` | PR/MR 仅变更少量文件时 |

### 报告生成

```bash
python scripts/generate_report.py
```

### 前置依赖

- Python 3.10+
- `pip install -r requirements.txt`
- `pip install semgrep`（静态分析）
- 可选：OpenSCA、afrog（依赖/动态扫描）

### 建议

- 先在测试环境验证，再部署至生产
- 扫描失败默认不阻断流水线，避免误拦
- 告警可通过管理后台 Webhook 统一配置，支持飞书、Slack 等
