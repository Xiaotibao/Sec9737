"""
功能引导 API
升级入口、价值提示、高意向识别、教程入口
"""

from flask import Blueprint, request, jsonify

from ..guide import (
    get_upgrade_prompt,
    get_critical_upgrade_cta,
    is_high_intent_user,
    get_presale_prompt,
    get_tutorial_links,
)
from ..guide.upgrade_prompt import get_upgrade_url
from ..risk_control import get_all_disclaimers

guide_bp = Blueprint("guide", __name__, url_prefix="/api/guide")


@guide_bp.route("/disclaimers", methods=["GET"])
def disclaimers():
    """获取风控文案（供插件/后台统一展示）"""
    return jsonify(get_all_disclaimers())


@guide_bp.route("/upgrade-prompt", methods=["GET"])
def upgrade_prompt():
    """
    获取升级价值提示文案
    Query: severity=critical|high, vuln_name=
    """
    severity = request.args.get("severity", "critical")
    vuln_name = request.args.get("vuln_name", "")
    msg = get_upgrade_prompt(severity, vuln_name)
    return jsonify({
        "message": msg,
        "cta": get_critical_upgrade_cta(),
        "upgrade_url": get_upgrade_url(request.host_url.rstrip("/")),
    })


@guide_bp.route("/presale", methods=["GET"])
def presale():
    """
    高意向用户预售活动提示
    Query: scan_count=, member_count=, finding_count=, has_critical=
    """
    scan_count = int(request.args.get("scan_count", 0))
    member_count = int(request.args.get("member_count", 0))
    finding_count = int(request.args.get("finding_count", 0))
    has_critical = request.args.get("has_critical", "").lower() in ("1", "true", "yes")

    high_intent = is_high_intent_user(
        scan_count=scan_count,
        member_count=member_count,
        finding_count=finding_count,
        has_critical=has_critical,
    )
    presale_data = get_presale_prompt()
    presale_data["show"] = presale_data["show"] and high_intent
    presale_data["upgrade_url"] = get_upgrade_url(request.host_url.rstrip("/"))
    return jsonify(presale_data)


@guide_bp.route("/tutorial", methods=["GET"])
def tutorial():
    """
    企业版使用教程入口
    Query: role=admin|developer|quickstart
    """
    role = request.args.get("role", "")
    links = get_tutorial_links(role)
    return jsonify({"tutorials": links})


@guide_bp.route("/enterprise-features", methods=["GET"])
def enterprise_features():
    """企业版专属功能引导（批量管理、CI/CD 等）"""
    return jsonify({
        "features": [
            {"id": "batch", "name": "批量管理", "desc": "统一管理多项目漏洞，批量导出报告", "url": "/admin/#findings"},
            {"id": "cicd", "name": "CI/CD 集成", "desc": "GitHub Actions 一键接入", "url": "/admin/#billing"},
            {"id": "team", "name": "团队协作", "desc": "成员管理、权限分配", "url": "/admin/#members"},
        ],
        "upgrade_url": get_upgrade_url(request.host_url.rstrip("/")),
    })
