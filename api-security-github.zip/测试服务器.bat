@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===== 最小测试服务器 (端口 9000) =====
echo.
echo 启动后请在浏览器打开: http://127.0.0.1:9000/
echo 若看到 "OK" 说明环境正常
echo.
python minimal_test_server.py
pause
