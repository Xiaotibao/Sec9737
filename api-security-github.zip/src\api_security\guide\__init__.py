"""
市场落地配套 - 功能引导模块
实现流量自循环：升级入口、价值提示、高意向识别、教程入口
"""

from .upgrade_prompt import get_upgrade_prompt, get_critical_upgrade_cta
from .high_intent import is_high_intent_user, get_presale_prompt
from .tutorial import get_tutorial_links

__all__ = [
    "get_upgrade_prompt",
    "get_critical_upgrade_cta",
    "is_high_intent_user",
    "get_presale_prompt",
    "get_tutorial_links",
]
