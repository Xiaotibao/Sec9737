"""
OWASP API Top 10 2023 映射
- 规则 ID 到 OWASP 类别
- OpenAPI 合规结果到 Finding（含 owasp_category）
"""

from typing import Optional
from dataclasses import dataclass

# OWASP API Security Top 10 2023 完整列表
OWASP_API_TOP10 = [
    "API1:2023",  # 失效的对象级授权 (BOLA/IDOR)
    "API2:2023",  # 失效的身份认证
    "API3:2023",  # 失效的对象属性级授权
    "API4:2023",  # 无限制的资源消耗
    "API5:2023",  # 失效的功能级授权
    "API6:2023",  # 批量分配
    "API7:2023",  # 安全配置错误
    "API8:2023",  # 注入
    "API9:2023",  # 资产管理不当
    "API10:2023",  # 日志与监控不足
]

# 规则 ID 前缀/关键词 到 OWASP 类别
RULE_TO_OWASP = {
    "owasp-api1": "API1:2023",
    "owasp-api2": "API2:2023",
    "owasp-api3": "API3:2023",
    "owasp-api4": "API4:2023",
    "owasp-api5": "API5:2023",
    "owasp-api6": "API6:2023",
    "owasp-api7": "API7:2023",
    "owasp-api8": "API8:2023",
    "owasp-api9": "API9:2023",
    "owasp-api10": "API10:2023",
    # 原有规则映射
    "api-sql-injection": "API8:2023",
    "api-missing-auth": "API5:2023",
    "api-sensitive-log": "API10:2023",
    "api-hardcoded-secret": "API2:2023",
}


def get_owasp_category_from_rule_id(rule_id: Optional[str]) -> Optional[str]:
    """
    从 Semgrep 规则 ID 或 metadata 解析 OWASP 类别
    按前缀长度降序匹配，避免 owasp-api1 误匹配 owasp-api10
    """
    if not rule_id:
        return None
    # 长前缀优先，避免 api1 匹配 api10
    for prefix, category in sorted(RULE_TO_OWASP.items(), key=lambda x: -len(x[0])):
        if rule_id.startswith(prefix):
            return category
    return None


def get_owasp_category_from_metadata(metadata: dict) -> Optional[str]:
    """从 Semgrep 结果的 metadata 获取 owasp_api"""
    if isinstance(metadata, dict):
        return metadata.get("owasp_api")
    return None


def get_owasp_category_from_compliance(
    compliance_type: str,
) -> Optional[str]:
    """
    合规检查类型到 OWASP 类别
    - missing_security -> API2, API5
    - sensitive_fields_in_response -> API3
    - missing_auth_errors -> API2, API5
    - deprecated_operations -> API9
    """
    mapping = {
        "missing_security": "API5:2023",  # 功能级授权
        "sensitive_fields_in_response": "API3:2023",
        "missing_auth_errors": "API2:2023",  # 身份认证相关
        "deprecated_operations": "API9:2023",
    }
    return mapping.get(compliance_type)


@dataclass
class ComplianceFinding:
    """合规检查单条发现（可转为 Finding）"""
    compliance_type: str
    operation: str
    detail: str
    owasp_category: Optional[str] = None


def compliance_to_findings(compliance_result) -> list[dict]:
    """
    将 ComplianceResult 转为 Finding 格式的 dict 列表
    用于统一展示与 OWASP 覆盖追溯
    """
    from ..parser.compliance_types import ComplianceResult

    if not isinstance(compliance_result, ComplianceResult):
        return []

    findings: list[dict] = []

    for op_id in compliance_result.missing_security:
        cat = get_owasp_category_from_compliance("missing_security")
        findings.append({
            "tool": "openapi_compliance",
            "severity": "medium",
            "title": "缺失 security 定义",
            "description": f"接口 {op_id} 未定义 security，可能允许未授权访问",
            "location": op_id,
            "rule_id": "compliance-missing-security",
            "owasp_category": cat,
        })

    for item in compliance_result.sensitive_fields_in_response:
        cat = get_owasp_category_from_compliance("sensitive_fields_in_response")
        op = item.get("operation", "")
        field = item.get("field_path", "")
        findings.append({
            "tool": "openapi_compliance",
            "severity": "high",
            "title": "响应含敏感字段",
            "description": f"接口 {op} 响应 schema 包含敏感字段 {field}",
            "location": f"{op} -> {field}",
            "rule_id": "compliance-sensitive-field",
            "owasp_category": cat,
        })

    for op_id in compliance_result.missing_auth_errors:
        cat = get_owasp_category_from_compliance("missing_auth_errors")
        findings.append({
            "tool": "openapi_compliance",
            "severity": "medium",
            "title": "缺失 401/403 定义",
            "description": f"接口 {op_id} 未定义 401/403 错误响应",
            "location": op_id,
            "rule_id": "compliance-missing-auth-errors",
            "owasp_category": cat,
        })

    # deprecated_operations 需 ComplianceResult 扩展
    if hasattr(compliance_result, "deprecated_operations"):
        for op_id in getattr(compliance_result, "deprecated_operations", []) or []:
            cat = get_owasp_category_from_compliance("deprecated_operations")
            findings.append({
                "tool": "openapi_compliance",
                "severity": "info",
                "title": "废弃接口",
                "description": f"接口 {op_id} 已标记为 deprecated，建议迁移或下线",
                "location": op_id,
                "rule_id": "compliance-deprecated",
                "owasp_category": cat,
            })

    return findings
