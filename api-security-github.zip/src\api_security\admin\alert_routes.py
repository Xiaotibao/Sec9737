"""
高危漏洞提醒 API
弹窗控制、频率限制、记录弹窗
"""

from flask import Blueprint, request, jsonify

from ..alert import process_findings_for_alerts, record_popup

alert_bp = Blueprint("alert", __name__, url_prefix="/api/alert")


@alert_bp.route("/process", methods=["POST"])
def process_alerts():
    """
    根据扫描结果计算需弹窗/通知的漏洞
    Body: { "findings": [...], "project": "项目名" }
    """
    data = request.get_json() or {}
    findings = data.get("findings", [])
    project = data.get("project", "")
    result = process_findings_for_alerts(findings, project)
    return jsonify(result)


@alert_bp.route("/record-popup", methods=["POST"])
def record_popup_route():
    """
    记录弹窗已展示，用于 24 小时频率限制
    Body: { "project": "项目名", "fingerprint": "漏洞指纹" }
    """
    data = request.get_json() or {}
    project = data.get("project", "")
    fingerprint = data.get("fingerprint", "")
    if not fingerprint:
        return jsonify({"success": False, "error": "fingerprint required"}), 400
    record_popup(project, fingerprint)
    return jsonify({"success": True})
