"""
OpenAPI/Swagger 轻量设计合规核查
核查维度:
  1. 接口是否缺失 security 定义
  2. 响应是否包含敏感字段
  3. 是否缺失 401/403 错误定义
"""

from typing import Any

from .openapi_parser import ParseResult
from .compliance_types import ComplianceResult


# 常见敏感字段名（可配置扩展）
SENSITIVE_FIELD_NAMES = frozenset({
    "password", "passwd", "pwd", "secret", "token", "api_key", "apikey",
    "access_token", "refresh_token", "credential", "private_key", "privatekey",
    "ssn", "social_security", "credit_card", "creditcard", "cvv", "cvc",
    "bank_account", "bankaccount", "phone", "mobile", "email", "address",
    "id_card", "idcard", "identity", "salary", "income",
})


class ComplianceChecker:
    """
    合规核查器
    对解析后的 OpenAPI spec 进行轻量设计合规检查
    """

    def __init__(self, sensitive_fields: frozenset[str] | None = None):
        """
        Args:
            sensitive_fields: 自定义敏感字段集合，默认使用内置列表
        """
        self.sensitive_fields = sensitive_fields or SENSITIVE_FIELD_NAMES

    def check(self, parse_result: ParseResult) -> ComplianceResult:
        """
        执行合规核查

        Args:
            parse_result: OpenAPIParser 的解析结果

        Returns:
            ComplianceResult: 核查结果
        """
        if not parse_result.success or not parse_result.spec:
            return ComplianceResult(passed=False)

        spec = parse_result.spec
        version = parse_result.version or "3.0"

        missing_security: list[str] = []
        sensitive_in_response: list[dict] = []
        missing_auth_errors: list[str] = []
        deprecated_operations: list[str] = []

        if version == "2.0":
            paths = spec.get("paths", {})
            global_security = spec.get("security", [])
        else:
            paths = spec.get("paths", {})
            global_security = spec.get("security", [])

        for path, path_item in paths.items():
            if not isinstance(path_item, dict):
                continue
            operations = self._get_operations(path_item, version)
            for method, op in operations.items():
                op_id = f"{method.upper()} {path}"

                # 1. 检查 security 定义
                if not self._has_security(op, path_item, global_security, version):
                    missing_security.append(op_id)

                # 2. 检查响应中的敏感字段
                for finding in self._check_sensitive_in_responses(op, op_id):
                    sensitive_in_response.append(finding)

                # 3. 检查 401/403 错误定义
                if not self._has_auth_error_definitions(op, version):
                    missing_auth_errors.append(op_id)

                # 4. 检查废弃接口 (API9:2023)
                if op.get("deprecated") is True:
                    deprecated_operations.append(op_id)

        passed = not (missing_security or sensitive_in_response or missing_auth_errors)
        return ComplianceResult(
            missing_security=missing_security,
            sensitive_fields_in_response=sensitive_in_response,
            missing_auth_errors=missing_auth_errors,
            deprecated_operations=deprecated_operations,
            passed=passed,
        )

    def _get_operations(self, path_item: dict, version: str) -> dict[str, Any]:
        """提取 path 下的所有 HTTP 方法操作"""
        methods = ("get", "post", "put", "patch", "delete", "head", "options")
        return {m: path_item[m] for m in methods if m in path_item and isinstance(path_item[m], dict)}

    def _has_security(
        self,
        op: dict,
        path_item: dict,
        global_security: list,
        version: str,
    ) -> bool:
        """检查操作是否有 security 定义
        显式 security: [] 表示无需认证，视为已定义
        """
        op_sec = op.get("security")
        path_sec = path_item.get("security") if isinstance(path_item, dict) else None

        if op_sec is not None:
            return True  # 已定义（含 [] 表示公开接口）
        if path_sec is not None:
            return True
        return len(global_security) > 0

    def _check_sensitive_in_responses(self, op: dict, op_id: str) -> list[dict]:
        """检查响应 schema 中是否包含敏感字段
        支持 OpenAPI 2.0 (schema 直接) 与 3.x (content.*.schema)
        """
        findings: list[dict] = []
        responses = op.get("responses", {})
        if not isinstance(responses, dict):
            return findings

        for code, resp in responses.items():
            if not isinstance(resp, dict):
                continue
            schemas = self._get_response_schemas(resp)
            for schema in schemas:
                if not schema:
                    continue
                for field_path in self._extract_sensitive_from_schema(schema, ""):
                    findings.append({
                        "operation": op_id,
                        "response_code": code,
                        "field_path": field_path,
                    })
        return findings

    def _get_response_schemas(self, resp: dict) -> list:
        """从响应对象提取所有 schema（兼容 2.0 与 3.x）"""
        # OpenAPI 2.0: responses.200.schema
        schema = resp.get("schema")
        if schema:
            return [schema]
        # OpenAPI 3.x: responses.200.content.application/json.schema
        content = resp.get("content", {})
        if isinstance(content, dict):
            return [c.get("schema") for c in content.values() if isinstance(c, dict) and c.get("schema")]
        return []

    def _extract_sensitive_from_schema(self, schema: dict, prefix: str) -> list[str]:
        """递归提取 schema 中的敏感字段路径
        支持 items 用于 array 元素
        """
        found: list[str] = []
        if not isinstance(schema, dict):
            return found
        props = schema.get("properties", {})
        if not isinstance(props, dict):
            return found

        for name, sub in props.items():
            path = f"{prefix}.{name}" if prefix else name
            name_lower = name.lower()
            if any(s in name_lower for s in self.sensitive_fields):
                found.append(path)

            if isinstance(sub, dict):
                ref = sub.get("$ref")
                if ref:
                    continue  # 简化处理，不解析 $ref
                for p in self._extract_sensitive_from_schema(sub, path):
                    found.append(p)

        # 处理 array items
        items = schema.get("items")
        if isinstance(items, dict):
            for p in self._extract_sensitive_from_schema(items, f"{prefix}[]" if prefix else "[]"):
                found.append(p)
        return found

    def _has_auth_error_definitions(self, op: dict, version: str) -> bool:
        """检查是否定义了 401/403 错误"""
        responses = op.get("responses", {})
        if not isinstance(responses, dict):
            return False
        has_401 = "401" in responses or "401" in [str(k) for k in responses.keys()]
        has_403 = "403" in responses or "403" in [str(k) for k in responses.keys()]
        return has_401 or has_403
