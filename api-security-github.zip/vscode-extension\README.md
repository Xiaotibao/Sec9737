# API Security - VS Code 扩展

基于 **OpenSCA + Semgrep + afrog** 的 API 安全扫描扩展，覆盖 OWASP API Top 10 常见漏洞类型。

## 功能

- **执行扫描**：对工作区执行 API 安全扫描
- **解析 OpenAPI**：解析 OpenAPI/Swagger 文档并做合规核查
- **查看结果**：在 Webview 中查看扫描结果
- **问题面板**：将漏洞展示到 VS Code 问题面板，支持编辑器内嵌诊断

## 安装

### 方式一：从 VSIX 安装

1. 在项目根目录执行 `npm run package` 生成 `.vsix` 文件
2. 在 VS Code 中：扩展 → 从 VSIX 安装 → 选择生成的 `.vsix`

### 方式二：开发模式

1. 在 `vscode-extension` 目录执行 `npm install && npm run compile`
2. 按 F5 启动扩展开发主机进行调试

## 前置条件

- **Python 3.10+**
- **api_security** 已安装：
  - 若工作区为本项目（含 `src/api_security`），扩展会自动使用
  - 否则需执行 `pip install -e .` 安装

## 配置

在 VS Code 设置中可配置：

| 配置项 | 说明 | 默认 |
|--------|------|------|
| `apiSecurity.pythonPath` | Python 解释器路径 | `python` |
| `apiSecurity.target` | 扫描目标路径（相对工作区根目录） | `.` |
| `apiSecurity.openapiPath` | OpenAPI 文档路径 | `null`（自动识别） |
| `apiSecurity.afrogUrl` | afrog 动态扫描的 API URL | `null` |

也可在工作区根目录创建 `api_security.yaml` 或 `config/api_security.yaml`：

```yaml
scan:
  target: "."
  openapi: null
  afrog_url: null
```

## 命令

- `API Security: 执行扫描` - 对当前工作区执行扫描
- `API Security: 解析 OpenAPI` - 选择并解析 OpenAPI 文件
- `API Security: 查看扫描结果` - 在侧边栏查看最近扫描结果
- `API Security: 清除诊断` - 清除问题面板中的 API Security 诊断

## 发布

```bash
npm install -g @vscode/vsce
vsce package
vsce publish  # 需配置 publisher 与 token
```

## 免责声明

工具检测结果仅供参考，建议结合实际业务做安全评估。
