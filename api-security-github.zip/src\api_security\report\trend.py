"""
API 风险趋势分析
统计近 7 天/30 天漏洞数量变化，生成简易折线趋势图
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESULTS_DIR = PROJECT_ROOT / "scan_results"


def _parse_timestamp(ts: str) -> Optional[datetime]:
    """解析 scan_YYYYMMDD_HHMMSS 或 YYYYMMDD_HHMMSS"""
    if not ts:
        return None
    try:
        s = ts.replace("scan_", "").replace(".json", "")
        if "_" in s:
            return datetime.strptime(s[:15], "%Y%m%d_%H%M%S")
        return datetime.strptime(s[:8], "%Y%m%d")
    except Exception:
        return None


def get_trend_data(days: int = 7, tenant_id: str = "default") -> dict:
    """
    获取近 N 天每日漏洞数量（按租户隔离）
    days: 7 或 30
    tenant_id: 租户 ID，default 时包含所有未关联扫描

    Returns:
        {
            "labels": ["03-10", "03-11", ...],
            "counts": [5, 3, ...],
            "total": 12,
        }
    """
    days = min(max(days, 1), 90)
    end = datetime.now().date()
    start = end - timedelta(days=days - 1)

    daily = {start + timedelta(days=i): 0 for i in range(days)}
    daily = dict(sorted(daily.items()))

    if not RESULTS_DIR.exists():
        return {"labels": list(daily.keys()), "counts": [0] * len(daily), "total": 0}

    allowed = None
    if tenant_id != "default":
        from ..tenant import get_tenant_scan_metadata
        allowed = set(get_tenant_scan_metadata(tenant_id).keys())

    for f in RESULTS_DIR.glob("scan_*.json"):
        if allowed is not None and f.name not in allowed:
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            ts = data.get("timestamp", "")
            dt = _parse_timestamp(ts)
            if dt:
                d = dt.date()
                if start <= d <= end:
                    cnt = len(data.get("detection", {}).get("findings", []))
                    daily[d] = daily.get(d, 0) + cnt
        except Exception:
            pass

    labels = [d.strftime("%m-%d") for d in daily.keys()]
    counts = list(daily.values())
    return {"labels": labels, "counts": counts, "total": sum(counts)}


def generate_trend_chart_svg(days: int = 7, width: int = 400, height: int = 200, tenant_id: str = "default") -> str:
    """
    生成简易折线趋势图 SVG
    可直接嵌入报告或 HTML 展示
    """
    data = get_trend_data(days, tenant_id)
    labels = data["labels"]
    counts = data["counts"]
    total = data["total"]

    if not counts:
        return '<svg width="{}" height="{}"><text x="50%" y="50%" text-anchor="middle" fill="#999">暂无数据</text></svg>'.format(
            width, height
        )

    max_val = max(counts) or 1
    pad = 40
    chart_w = width - pad * 2
    chart_h = height - pad * 2

    points = []
    for i, v in enumerate(counts):
        x = pad + (chart_w / (len(counts) - 1) * i) if len(counts) > 1 else pad + chart_w / 2
        y = pad + chart_h - (v / max_val * chart_h)
        points.append(f"{x:.1f},{y:.1f}")

    path_d = "M " + " L ".join(points)
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        f'<rect width="100%" height="100%" fill="#fafafa"/>',
        f'<path d="{path_d}" fill="none" stroke="#0066cc" stroke-width="2"/>',
        f'<text x="{width//2}" y="{height-8}" text-anchor="middle" font-size="12" fill="#666">近{days}天 · 共{total}条</text>',
        "</svg>",
    ]
    return "\n".join(lines)
