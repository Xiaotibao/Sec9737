"""
版本标识 - 社区版与商业版功能边界

社区版（Community）：功能精简，无计费、无团队限制，开源可贡献
商业版（Enterprise）：完整功能，套餐计费、团队规模管控、SSO、多租户

通过环境变量 API_SECURITY_EDITION 控制：
- community / ce / 未设置 → 社区版
- enterprise / ee → 商业版
"""

import os

_EDITION = os.environ.get("API_SECURITY_EDITION", "community").lower().strip()
if _EDITION in ("enterprise", "ee"):
    IS_COMMUNITY = False
    EDITION_NAME = "enterprise"
else:
    IS_COMMUNITY = True
    EDITION_NAME = "community"


def is_community() -> bool:
    """是否为社区版"""
    return IS_COMMUNITY


def is_enterprise() -> bool:
    """是否为商业版"""
    return not IS_COMMUNITY


def edition_name() -> str:
    """当前版本名称"""
    return EDITION_NAME
