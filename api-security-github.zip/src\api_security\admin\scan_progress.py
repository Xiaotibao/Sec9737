"""
扫描进度存储（内存）
支持异步扫描时轮询进度
"""

import uuid
import threading
from typing import Optional
from dataclasses import dataclass, field

# 扫描阶段定义（与升级计划一致）
SCAN_STAGES = [
    ("openapi_parsing", "OpenAPI 解析"),
    ("compliance", "合规核查"),
    ("semgrep", "Semgrep 静态分析"),
    ("opensca", "OpenSCA 依赖扫描"),
    ("afrog", "afrog 动态扫描"),
    ("done", "完成"),
]

# 每阶段预估进度占比
STAGE_PROGRESS = {
    "openapi_parsing": (0, 15),
    "compliance": (15, 25),
    "semgrep": (25, 45),
    "opensca": (45, 65),
    "afrog": (65, 90),
    "done": (100, 100),
}


@dataclass
class ScanProgress:
    """单次扫描进度"""
    task_id: str
    stage: str = "openapi_parsing"
    progress: int = 0
    message: str = ""
    done: bool = False
    error: Optional[str] = None
    result: Optional[dict] = None


_lock = threading.Lock()
_progress: dict[str, ScanProgress] = {}


def create_task() -> str:
    """创建扫描任务，返回 task_id"""
    task_id = str(uuid.uuid4())[:8]
    with _lock:
        _progress[task_id] = ScanProgress(task_id=task_id, message="准备中...")
    return task_id


def update_progress(task_id: str, stage: str, message: str = "", progress: Optional[int] = None):
    """更新进度"""
    p_min, p_max = STAGE_PROGRESS.get(stage, (0, 100))
    prog = progress if progress is not None else p_min
    with _lock:
        if task_id in _progress:
            _progress[task_id].stage = stage
            _progress[task_id].message = message or _progress[task_id].message
            _progress[task_id].progress = min(100, max(0, prog))


def set_done(task_id: str, result: Optional[dict] = None, error: Optional[str] = None):
    """标记完成"""
    with _lock:
        if task_id in _progress:
            _progress[task_id].done = True
            _progress[task_id].stage = "done"
            _progress[task_id].progress = 100
            _progress[task_id].message = "扫描完成" if not error else f"失败: {error}"
            _progress[task_id].result = result
            _progress[task_id].error = error


def get_progress(task_id: str) -> Optional[dict]:
    """获取进度，返回可序列化的 dict"""
    with _lock:
        p = _progress.get(task_id)
    if not p:
        return None
    return {
        "task_id": p.task_id,
        "stage": p.stage,
        "progress": p.progress,
        "message": p.message,
        "done": p.done,
        "error": p.error,
        "result": p.result,
    }


def cleanup_old_tasks(keep_recent: int = 50):
    """清理旧任务，保留最近 N 个"""
    with _lock:
        done_ids = [tid for tid, p in _progress.items() if p.done]
        if len(done_ids) > keep_recent:
            for tid in sorted(done_ids, key=lambda x: 0)[: len(done_ids) - keep_recent]:
                _progress.pop(tid, None)
