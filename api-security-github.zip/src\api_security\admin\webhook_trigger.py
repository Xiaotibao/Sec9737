"""
Webhook 触发 - 在扫描完成、Critical 发现时调用
"""

from .webhook_sender import trigger_webhooks, EVENT_SCAN_COMPLETE, EVENT_CRITICAL_FOUND


def trigger_scan_webhooks(result: dict, scan_file: str, target: str, project: str = ""):
    """
    扫描完成后触发 Webhook
    - scan_complete: 始终触发
    - critical_found: 若有 Critical 漏洞则触发
    """
    detection = result.get("detection") or {}
    findings = detection.findings if hasattr(detection, "findings") else detection.get("findings", [])
    findings_count = len(findings)
    passed = findings_count == 0

    msg_lines = [
        f"扫描目标: {target}",
        f"发现数量: {findings_count} 条",
        f"状态: {'通过' if passed else '发现风险'}",
        f"项目: {project or '-'}",
    ]
    scan_ctx = {
        "target": target,
        "findings_count": findings_count,
        "project": project,
        "scan_file": scan_file,
        "passed": passed,
        "message": "\n".join(msg_lines),
    }
    trigger_webhooks(EVENT_SCAN_COMPLETE, scan_ctx)

    alerts = result.get("alerts") or {}
    critical_popups = alerts.get("critical_popups") or []
    if critical_popups:
        crit_msg = f"发现 {len(critical_popups)} 个 Critical 漏洞\n"
        for c in critical_popups[:5]:
            crit_msg += f"- {c.get('vuln_name', c.get('finding', {}).get('title', ''))}\n"
        crit_ctx = {
            "message": crit_msg,
            "critical_findings": critical_popups,
            "project": project,
            "findings_count": findings_count,
        }
        trigger_webhooks(EVENT_CRITICAL_FOUND, crit_ctx)
