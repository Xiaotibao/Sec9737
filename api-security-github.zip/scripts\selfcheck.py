#!/usr/bin/env python3
"""
全面自检脚本 - 验证核心模块、API、配置
用法: python scripts/selfcheck.py
"""
import sys
import os
from pathlib import Path

# 确保 src 在路径中
root = Path(__file__).resolve().parents[1]
src = root / "src"
if str(src) not in sys.path:
    sys.path.insert(0, str(src))
os.chdir(root)

def ok(msg: str):
    print(f"  [OK] {msg}")

def fail(msg: str):
    print(f"  [FAIL] {msg}")

def main():
    print("=" * 50)
    print("API Security 全面自检")
    print("=" * 50)
    errors = 0

    # 1. 模块导入
    print("\n1. 模块导入")
    try:
        from api_security import cli, plugin
        from api_security.admin.app import app
        from api_security.billing import PermissionChecker
        from api_security.edition import is_community
        from api_security.tenant import ensure_default_tenant, list_tenants
        ok("核心模块导入成功")
    except Exception as e:
        fail(f"模块导入失败: {e}")
        return 1

    # 2. 版本与配置
    print("\n2. 版本与配置")
    try:
        ensure_default_tenant()
        tenants = list_tenants()
        ok(f"租户初始化 OK，当前 {len(tenants)} 个租户")
        ok(f"版本: {'社区版' if is_community() else '商业版'}")
    except Exception as e:
        fail(f"配置检查失败: {e}")
        errors += 1

    # 3. API 健康检查
    print("\n3. API 健康检查")
    try:
        with app.test_client() as c:
            r = c.get("/api/health")
            if r.status_code == 200:
                ok("健康检查通过")
            else:
                fail(f"健康检查返回 {r.status_code}")
                errors += 1
            r2 = c.get("/api/edition")
            if r2.status_code == 200:
                ok("版本接口正常")
            else:
                fail(f"版本接口返回 {r2.status_code}")
                errors += 1
    except Exception as e:
        fail(f"API 检查失败: {e}")
        errors += 1

    # 4. 权限校验（社区版应无限制）
    print("\n4. 权限校验")
    try:
        pc = PermissionChecker("default")
        allowed, _ = pc.check_api_call("basic")
        if is_community() and allowed:
            ok("社区版 API 调用无限制")
        elif not is_community():
            ok("商业版权限校验正常")
        else:
            fail("社区版应允许 API 调用")
            errors += 1
    except Exception as e:
        fail(f"权限校验失败: {e}")
        errors += 1

    # 5. 静态资源
    print("\n5. 静态资源")
    static = root / "admin_static" / "index.html"
    if static.exists():
        ok("管理后台 index.html 存在")
    else:
        fail("index.html 不存在")
        errors += 1

    # 6. 安全提示
    print("\n6. 安全提示")
    sk = os.environ.get("FLASK_SECRET_KEY", "")
    if not sk or sk == "dev-secret-change-in-production":
        print("  [WARN] 生产环境请设置 FLASK_SECRET_KEY")
    else:
        ok("FLASK_SECRET_KEY 已配置")

    print("\n" + "=" * 50)
    if errors == 0:
        print("自检通过")
        return 0
    else:
        print(f"发现 {errors} 个问题")
        return 1

if __name__ == "__main__":
    sys.exit(main())
