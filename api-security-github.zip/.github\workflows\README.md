# API 安全扫描 - GitHub Actions 模板

**社区版**：无需 `UNLIMITED_PACKAGE_TOKEN`，直接使用即可。  
**商业版**：需配置 `UNLIMITED_PACKAGE_TOKEN`（3999元无限套餐）。

## 模板说明

| 模板 | 功能 | 适用场景 |
|------|------|----------|
| **基础版** `api-security-basic.yml` | API 漏洞扫描 + 本地报告生成 | 仅需扫描与报告 |
| **进阶版** `api-security-advanced.yml` | API 漏洞扫描 + 钉钉/企业微信告警 | 需即时告警通知 |

## 一键使用

1. 复制对应模板到仓库 `.github/workflows/` 目录
2. 在 GitHub 仓库 Settings → Secrets 中配置：
   - `UNLIMITED_PACKAGE_TOKEN`（必填，联系获取）
   - `DINGTALK_WEBHOOK`（进阶版可选，钉钉机器人 Webhook）
   - `WECOM_WEBHOOK`（进阶版可选，企业微信机器人 Webhook）
3. 推送代码或手动触发 `workflow_dispatch`

## 默认行为

- **扫描失败不阻断流水线**：发现漏洞时流水线仍通过
- 如需阻断：在模板中搜索 `如需阻断流水线`，按注释取消对应代码

## 钉钉 / 企业微信配置

- **钉钉**：群设置 → 智能群助手 → 添加机器人 → 自定义 → 复制 Webhook
- **企业微信**：群设置 → 群机器人 → 添加 → 复制 Webhook

## GitLab CI / Jenkins

- **GitLab CI**：复制 `.gitlab-ci-api-security-basic.yml.example` 或 `-advanced` 为 `.gitlab-ci.yml`
- **Jenkins**：复制 `Jenkinsfile.api-security.example` 为 `Jenkinsfile`
- 详见 `docs/CI_CD_INTEGRATION.md`
