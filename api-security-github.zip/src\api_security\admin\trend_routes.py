"""
API 风险趋势分析 API
"""

from flask import Blueprint, request, jsonify

from ..report import get_trend_data, generate_trend_chart_svg
from ..tenant import get_tenant_id_from_request

trend_bp = Blueprint("trend", __name__, url_prefix="/api/admin")


@trend_bp.route("/trend", methods=["GET"])
def trend_data():
    """
    获取近 7 天/30 天漏洞数量趋势
    Query: days=7|30
    """
    tenant_id = get_tenant_id_from_request(request)
    days = int(request.args.get("days", 7))
    if days not in (7, 30):
        days = 7
    data = get_trend_data(days, tenant_id)
    return jsonify(data)


@trend_bp.route("/trend/chart", methods=["GET"])
def trend_chart():
    """
    获取趋势图 SVG
    Query: days=7|30, width=400, height=200
    """
    tenant_id = get_tenant_id_from_request(request)
    days = int(request.args.get("days", 7))
    width = int(request.args.get("width", 400))
    height = int(request.args.get("height", 200))
    if days not in (7, 30):
        days = 7
    svg = generate_trend_chart_svg(days=days, width=width, height=height, tenant_id=tenant_id)
    return svg, 200, {"Content-Type": "image/svg+xml"}
