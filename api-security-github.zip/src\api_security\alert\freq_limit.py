"""
弹窗频率限制
同一项目 24 小时内针对同一类 Critical 漏洞最多弹窗 1 次
"""

import json
from pathlib import Path
from datetime import datetime, timedelta

# 存储路径
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
POPUP_HISTORY_FILE = DATA_DIR / "popup_history.json"

# 24 小时
WINDOW_HOURS = 24


def _load_history() -> dict:
    """{ "project|vuln_fp": "last_popup_iso" }"""
    if not POPUP_HISTORY_FILE.exists():
        return {}
    try:
        return json.loads(POPUP_HISTORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_history(data: dict):
    DATA_DIR.mkdir(exist_ok=True)
    POPUP_HISTORY_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _make_key(project: str, vuln_fingerprint: str) -> str:
    return f"{project or 'default'}|{vuln_fingerprint}"


def check_24h_limit(project: str, vuln_fingerprint: str) -> bool:
    """
    检查是否在 24 小时内已弹窗过
    Returns:
        True 表示可弹窗（未超限），False 表示应跳过
    """
    history = _load_history()
    key = _make_key(project, vuln_fingerprint)
    last_ts = history.get(key)
    if not last_ts:
        return True
    try:
        last = datetime.fromisoformat(last_ts)
        if datetime.now() - last < timedelta(hours=WINDOW_HOURS):
            return False
    except Exception:
        pass
    return True


def record_popup(project: str, vuln_fingerprint: str):
    """记录本次弹窗，用于 24 小时频率限制"""
    history = _load_history()
    key = _make_key(project, vuln_fingerprint)
    history[key] = datetime.now().isoformat()
    _save_history(history)
