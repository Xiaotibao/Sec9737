"""
漏洞详情与修复建议测试
"""

import pytest

from api_security.remediation import get_remediation, get_references, enrich_finding_detail


class TestRemediationTemplates:
    """修复建议模板"""

    def test_sql_injection_remediation(self):
        """SQL 注入 - 有专用模板"""
        r = get_remediation("api-sql-injection", None)
        assert "参数化" in r or "预编译" in r

    def test_hardcoded_secret_remediation(self):
        """硬编码密钥 - 有专用模板"""
        r = get_remediation("api-hardcoded-secret", None)
        assert "环境变量" in r or "密钥" in r

    def test_missing_auth_remediation(self):
        """缺失认证 - 有专用模板"""
        r = get_remediation("api-missing-auth", None)
        assert "认证" in r

    def test_compliance_sensitive_remediation(self):
        """合规-敏感字段 - 有专用模板"""
        r = get_remediation("compliance-sensitive-field", None)
        assert "敏感" in r or "schema" in r

    def test_unknown_rule_fallback(self):
        """未知规则 - 返回通用建议"""
        r = get_remediation("unknown-rule", "Some finding")
        assert "OWASP" in r


class TestReferences:
    """参考链接"""

    def test_sql_injection_refs(self):
        """SQL 注入 - 有 OWASP/CWE 链接"""
        refs = get_references("api-sql-injection", None, None, None)
        assert len(refs) >= 1
        assert any("owasp" in r["url"].lower() or "cwe" in r["url"].lower() for r in refs)

    def test_cve_refs(self):
        """CVE - 包含 NVD 链接"""
        refs = get_references(None, None, "CVE-2024-1234", None)
        assert any("nvd" in r["url"].lower() for r in refs)

    def test_unknown_fallback_refs(self):
        """未知 - 至少返回 OWASP 通用链接"""
        refs = get_references(None, None, None, None)
        assert len(refs) >= 1


class TestEnrichFindingDetail:
    """详情增强"""

    def test_enrich_has_remediation_and_refs(self):
        """enrich 后包含 remediation、references"""
        f = {"rule_id": "api-sql-injection", "title": "SQL injection", "tool": "semgrep"}
        d = enrich_finding_detail(f)
        assert "remediation" in d
        assert "references" in d
        assert d["remediation"]
        assert len(d["references"]) >= 1

    def test_enrich_preserves_fields(self):
        """enrich 保留原有字段"""
        f = {"title": "Test", "severity": "high", "description": "Desc", "location": "a.py"}
        d = enrich_finding_detail(f)
        assert d["title"] == "Test"
        assert d["severity"] == "high"
        assert d["description"] == "Desc"
        assert d["location"] == "a.py"
