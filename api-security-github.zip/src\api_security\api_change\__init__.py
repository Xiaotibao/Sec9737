"""
API 变更影响分析
对比新旧 OpenAPI，识别变更并标记高风险
"""

from .diff import openapi_diff
from .impact import analyze_change_impact
from .report import generate_change_report

__all__ = ["openapi_diff", "analyze_change_impact", "generate_change_report"]
