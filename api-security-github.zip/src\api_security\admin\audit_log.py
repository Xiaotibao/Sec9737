"""
审计日志 - 记录关键操作，支持合规与问题追溯
存储：JSON 文件，按日期轮转
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Optional
from dataclasses import dataclass, asdict

from .models import DATA_DIR

AUDIT_DIR = DATA_DIR / "audit"
AUDIT_MAX_DAYS = 90  # 保留最近 90 天
AUDIT_MAX_SIZE_MB = 10  # 单文件超过此大小则轮转

# 操作类型
OP_SCAN = "scan"
OP_EXPORT = "export"
OP_CONFIG = "config"
OP_MEMBER_ADD = "member_add"
OP_MEMBER_UPDATE = "member_update"
OP_MEMBER_DELETE = "member_delete"
OP_PLAN_PURCHASE = "plan_purchase"
OP_PLAN_SET = "plan_set"
OP_CLEANUP = "cleanup"


@dataclass
class AuditLog:
    """审计日志条目"""
    time: str  # ISO 格式
    operator: str  # 操作者（成员名/邮箱或 system）
    operation_type: str  # 操作类型
    resource: str  # 资源描述，如 "scan:fixtures", "member:1", "export:excel"
    result: str  # success | failed
    ip: Optional[str] = None
    detail: Optional[str] = None  # 额外详情

    def to_dict(self):
        return asdict(self)


def _ensure_audit_dir():
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)


def _today_file() -> Path:
    _ensure_audit_dir()
    return AUDIT_DIR / f"audit_{datetime.now().strftime('%Y%m%d')}.json"


def _load_logs(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_logs(path: Path, logs: list[dict]):
    _ensure_audit_dir()
    path.write_text(json.dumps(logs, ensure_ascii=False, indent=2), encoding="utf-8")


def write_audit(
    operation_type: str,
    resource: str,
    result: str = "success",
    operator: str = "system",
    ip: Optional[str] = None,
    detail: Optional[str] = None,
):
    """写入审计日志"""
    entry = AuditLog(
        time=datetime.now().isoformat(),
        operator=operator or "system",
        operation_type=operation_type,
        resource=resource,
        result=result,
        ip=ip,
        detail=detail,
    )
    path = _today_file()
    logs = _load_logs(path)
    logs.append(entry.to_dict())
    # 简单轮转：单文件超过 5000 条或 10MB 时归档
    if len(logs) > 5000:
        archive = path.with_suffix(".archive.json")
        _save_logs(archive, logs[:2500])
        logs = logs[2500:]
    if path.exists() and path.stat().st_size > AUDIT_MAX_SIZE_MB * 1024 * 1024:
        archive = path.with_name(path.stem + "_full.json")
        _save_logs(archive, logs[:-1000])
        logs = logs[-1000:]
    _save_logs(path, logs)


def query_audit_logs(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    operation_type: Optional[str] = None,
    limit: int = 500,
) -> list[dict]:
    """
    查询审计日志
    start_date, end_date: YYYYMMDD 格式
    """
    _ensure_audit_dir()
    all_logs: list[dict] = []
    files = sorted(AUDIT_DIR.glob("audit_*.json"), reverse=True)
    for f in files:
        if f.name.endswith(".archive.json"):
            continue
        try:
            date_str = f.stem.replace("audit_", "")
            if start_date and date_str < start_date:
                continue
            if end_date and date_str > end_date:
                continue
            logs = _load_logs(f)
            for log in logs:
                if operation_type and log.get("operation_type") != operation_type:
                    continue
                all_logs.append(log)
            if len(all_logs) >= limit:
                break
        except Exception:
            pass
    all_logs.sort(key=lambda x: x.get("time", ""), reverse=True)
    return all_logs[:limit]


def log_audit_from_request(
    operation_type: str,
    resource: str,
    result: str = "success",
    operator: str = "system",
    detail: Optional[str] = None,
    request=None,
    ip: Optional[str] = None,
):
    """从 Flask request 写入审计（供各路由调用），ip 可单独传入（如后台线程）"""
    if ip is None and request:
        ip = (
            request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
            or request.headers.get("X-Real-IP", "")
            or (getattr(request, "remote_addr", None) or "")
        )
    write_audit(
        operation_type=operation_type,
        resource=resource,
        result=result,
        operator=operator,
        ip=ip,
        detail=detail,
    )


def cleanup_old_audit():
    """清理过期审计日志"""
    _ensure_audit_dir()
    cutoff = datetime.now()
    removed = 0
    for f in AUDIT_DIR.glob("audit_*.json"):
        try:
            date_str = f.stem.replace("audit_", "").replace("_full", "")
            if len(date_str) == 8:
                dt = datetime.strptime(date_str, "%Y%m%d")
                if (cutoff - dt).days > AUDIT_MAX_DAYS:
                    f.unlink()
                    removed += 1
        except Exception:
            pass
    return removed
