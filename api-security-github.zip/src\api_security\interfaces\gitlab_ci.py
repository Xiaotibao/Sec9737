"""
GitLab CI 集成对接接口 - 预留
兼容 GitLab 流水线配置规范，支持后续接入 .gitlab-ci.yml
"""

import os
from typing import Any

# GitLab CI 与 GitHub Actions 环境变量映射
GITLAB_CI_VARS = {
    "CI_PROJECT_PATH": "GITHUB_REPOSITORY",
    "CI_COMMIT_REF_NAME": "GITHUB_REF",
    "CI_PIPELINE_ID": "GITHUB_RUN_ID",
    "CI_SERVER_URL": "GITHUB_SERVER_URL",
    "CI_PROJECT_DIR": "GITHUB_WORKSPACE",
    "CI_JOB_TOKEN": "GITHUB_TOKEN",
}


class GitLabCIAdapter:
    """
    GitLab CI 适配器 - 预留接口
    将 GitLab CI 环境变量适配为通用扫描上下文，便于复用现有检测逻辑
    """

    def adapt_env(self) -> dict[str, str]:
        """
        将 GitLab CI 变量适配为通用格式
        Returns:
            适配后的环境变量字典，可直接注入扫描上下文
        """
        result = {}
        for gl_var, gh_var in GITLAB_CI_VARS.items():
            val = os.environ.get(gl_var)
            if val:
                result[gh_var] = val
        return result

    def is_gitlab_ci(self) -> bool:
        """判断当前是否在 GitLab CI 环境中运行"""
        return bool(os.environ.get("GITLAB_CI") or os.environ.get("CI"))

    def get_scan_context(self) -> dict[str, Any]:
        """
        获取 GitLab CI 扫描上下文（预留）
        后续可扩展：项目路径、分支、流水线 ID 等
        """
        ctx = self.adapt_env()
        ctx["_source"] = "gitlab_ci"
        return ctx

    # 预留：trigger_pipeline_scan() -> 触发 GitLab 流水线扫描
    # 预留：parse_gitlab_ci_yml(path) -> 解析 .gitlab-ci.yml 配置
