"""
高意向用户识别逻辑
对小团队/企业开发者推送企业版预售活动
"""

from typing import Optional

# 预售活动：预付100元抵扣500元+早鸟优惠
PRESALE_MSG = "企业版预售：预付100元抵扣500元，享早鸟优惠，限时开放"
PRESALE_CTA = "立即预约"

# 高意向判定阈值
MIN_SCAN_COUNT = 3  # 扫描次数 >= 3 视为有使用习惯
MAX_MEMBER_COUNT = 20  # 成员数 <= 20 视为小团队
MIN_FINDING_COUNT = 1  # 有漏洞发现视为有整改需求


def is_high_intent_user(
    scan_count: int = 0,
    member_count: int = 0,
    finding_count: int = 0,
    has_critical: bool = False,
) -> bool:
    """
    高意向用户识别
    小团队/企业开发者：有扫描习惯、有漏洞、团队规模适中
    """
    if scan_count >= MIN_SCAN_COUNT and member_count <= MAX_MEMBER_COUNT:
        return True
    if finding_count >= MIN_FINDING_COUNT and has_critical:
        return True
    if scan_count >= 5:  # 高频使用
        return True
    return False


def get_presale_prompt() -> dict:
    """
    获取预售活动提示内容
    Returns:
        { "message", "cta", "show" }
    """
    return {
        "message": PRESALE_MSG,
        "cta": PRESALE_CTA,
        "show": True,
    }
