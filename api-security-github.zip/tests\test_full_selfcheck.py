"""
软件全功能自检与测试
覆盖所有 API、插件、CLI、权限、引导、导出等
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pytest


class TestAppRoutes:
    """主应用与健康检查"""

    def test_health(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/health")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert d.get("status") == "ok"


class TestScanAPI:
    """扫描 API"""

    def test_scan_post_success(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/scan", json={"target": "fixtures", "project": "selfcheck"})
        assert r.status_code == 200
        d = json.loads(r.data)
        assert d.get("success") is True
        assert "findings_count" in d
        assert "alerts" in d

    def test_results_list(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/results")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "results" in d

    def test_scan_progress_async(self):
        """扫描进度可视化：异步扫描 + 进度轮询"""
        from api_security.admin.app import app
        import time
        with app.test_client() as c:
            r = c.post("/api/scan", json={"target": "fixtures", "project": "selfcheck", "progress": True})
        assert r.status_code == 200
        d = json.loads(r.data)
        assert d.get("success") is True
        task_id = d.get("task_id")
        assert task_id, "应返回 task_id"

        with app.test_client() as c:
            r = c.get(f"/api/scan/status/{task_id}")
        assert r.status_code == 200
        p = json.loads(r.data)
        assert "stage" in p
        assert "progress" in p
        assert "message" in p
        assert "done" in p

        # 等待完成（最多 30 秒）
        for _ in range(60):
            with app.test_client() as c:
                r = c.get(f"/api/scan/status/{task_id}")
            p = json.loads(r.data)
            if p.get("done"):
                assert p.get("result", {}).get("success") is True
                assert "findings_count" in p.get("result", {})
                break
            time.sleep(0.5)
        else:
            pytest.fail("扫描未在 30 秒内完成")

    def test_scan_status_404(self):
        """不存在的 task_id 返回 404"""
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/scan/status/nonexistent-task-id")
        assert r.status_code == 404


class TestBillingAPI:
    """套餐与计费"""

    def test_plans(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/billing/plans")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert len(d["plans"]) >= 4
        for p in d["plans"]:
            assert "boundary" in p
        assert "plan_single_limit" in d

    def test_license_get(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/billing/license")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "plan_id" in d
        assert "usage_this_month" in d

    def test_quote(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/billing/quote", json={"plan_id": "unlimited", "expansion_count": 2})
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "total" in d

    def test_set_license(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/billing/license", json={"plan_id": "basic", "expansion_count": 0})
        assert r.status_code == 200
        assert json.loads(r.data).get("success") is True


class TestAdminAPI:
    """团队管理"""

    def test_members_get(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/members")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "members" in d

    def test_members_post(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/admin/members", json={"name": "自检用户", "email": "selfcheck@test.com"})
        assert r.status_code == 200
        d = json.loads(r.data)
        assert d.get("success") is True

    def test_stats(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/stats")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "stats" in d

    def test_findings(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/findings")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "findings" in d
        assert "total" in d

    def test_critical(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/critical")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "critical" in d
        assert "alerts" in d
        assert "tool_disclaimer" in d.get("alerts", {})

    def test_export_excel(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/admin/export", json={"format": "excel"})
        assert r.status_code == 200
        assert b"PK" in r.data or len(r.data) > 0

    def test_export_pdf(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/admin/export", json={"format": "pdf"})
        assert r.status_code == 200
        assert r.data[:4] == b"%PDF" or len(r.data) > 0


class TestGuideAPI:
    """功能引导"""

    def test_disclaimers(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/disclaimers")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "tool_disclaimer" in d
        assert "detection_scope" in d

    def test_upgrade_prompt(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/upgrade-prompt?severity=critical&vuln_name=SQL")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "message" in d
        assert "cta" in d

    def test_presale(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/presale?scan_count=5&member_count=5&finding_count=1&has_critical=true")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "show" in d
        assert "message" in d

    def test_tutorial(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/tutorial")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "tutorials" in d
        assert len(d["tutorials"]) >= 1

    def test_enterprise_features(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/enterprise-features")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "features" in d


class TestAlertAPI:
    """高危漏洞提醒"""

    def test_process(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/alert/process", json={"findings": [], "project": ""})
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "critical_popups" in d
        assert "high_notifications" in d
        assert "tool_disclaimer" in d

    def test_record_popup(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/alert/record-popup", json={"project": "t", "fingerprint": "fp1"})
        assert r.status_code == 200
        assert json.loads(r.data).get("success") is True


class TestTrendAPI:
    """趋势分析"""

    def test_trend(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/trend?days=7")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "labels" in d or "counts" in d or "total" in d or isinstance(d, dict)

    def test_trend_chart(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/trend/chart?days=7")
        assert r.status_code == 200


class TestStorageAPI:
    """数据清理"""

    def test_cleanup_config_get(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/storage/cleanup-config")
        assert r.status_code == 200

    def test_cleanup_config_post(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/admin/storage/cleanup-config", json={"enabled": False})
        assert r.status_code == 200

    def test_cleanup_run(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.post("/api/admin/storage/cleanup")
        assert r.status_code == 200


class TestAuditAPI:
    """审计日志"""

    def test_audit_logs_list(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/audit-logs")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "logs" in d
        assert "total" in d

    def test_audit_logs_export(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/audit-logs/export")
        assert r.status_code == 200
        assert b"[" in r.data or b"{" in r.data


class TestWebhookAPI:
    """Webhook 配置"""

    def test_webhooks_list(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/webhooks")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "webhooks" in d

    def test_webhooks_templates(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/webhooks/templates")
        assert r.status_code == 200
        d = json.loads(r.data)
        assert "platforms" in d
        assert "examples" in d
        assert "feishu" in d.get("examples", {})
        assert "slack" in d.get("examples", {})


class TestInterfacesAPI:
    """接口状态"""

    def test_gitlab_ci_status(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/interfaces/gitlab-ci/status")
        assert r.status_code == 200

    def test_batch_scan_status(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/interfaces/batch-scan/status")
        assert r.status_code == 200

    def test_custom_rules_status(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/interfaces/custom-rules/status")
        assert r.status_code == 200

    def test_team_permission_status(self):
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/interfaces/team-permission/status")
        assert r.status_code == 200


class TestPlugin:
    """插件入口"""

    def test_scan(self):
        from api_security.plugin import scan
        r = scan(ROOT / "fixtures", project="plugin_test")
        assert "detection" in r
        assert "alerts" in r
        assert "openapi_parsed" in r

    def test_risk_control_exports(self):
        from api_security.plugin import PUBLIC_CAPABILITY_DESC, TOOL_DISCLAIMER
        assert "OWASP" in PUBLIC_CAPABILITY_DESC
        assert "仅供参考" in TOOL_DISCLAIMER

    def test_guide_exports(self):
        from api_security.plugin import get_upgrade_prompt, is_high_intent_user, get_tutorial_links
        assert "团队版" in get_upgrade_prompt("critical", "SQL")
        assert is_high_intent_user(5, 10, 1, True) is True
        assert len(get_tutorial_links()) >= 1


class TestCLI:
    """命令行"""

    def test_scan_output_has_disclaimer(self):
        from api_security.cli import cmd_scan
        import argparse
        out = ROOT / "scan_selfcheck_cli.json"
        args = argparse.Namespace(
            target="fixtures", openapi=None, afrog_url=None,
            no_skip_on_fail=False, no_auto_openapi=False,
            output=str(out), verbose=False,
        )
        cmd_scan(args)
        assert out.exists()
        d = json.loads(out.read_text(encoding="utf-8"))
        assert "tool_disclaimer" in d
        out.unlink(missing_ok=True)


class TestReportGeneration:
    """报告生成"""

    def test_generate_report(self):
        out = ROOT / "scan_report_test.json"
        out.write_text(json.dumps({
            "detection": {
                "findings": [],
                "tools_run": ["semgrep"],
            },
            "openapi_parsed": True,
            "compliance_skipped": False,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        import subprocess
        ret = subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "generate_report.py"),
             str(out), str(ROOT / "api-security-report-test.md")],
            cwd=str(ROOT), capture_output=True, text=True,
        )
        assert ret.returncode == 0, ret.stderr or ret.stdout
        md = ROOT / "api-security-report-test.md"
        assert md.exists()
        assert "仅供参考" in md.read_text(encoding="utf-8")
        md.unlink(missing_ok=True)
        out.unlink(missing_ok=True)


class TestAdminStatic:
    """管理后台静态"""

    def test_admin_index_exists(self):
        assert (ROOT / "admin_static" / "index.html").exists()

    def test_admin_index_has_disclaimer(self):
        html = (ROOT / "admin_static" / "index.html").read_text(encoding="utf-8")
        assert "工具检测结果仅供参考" in html
        assert "OWASP" in html or "OpenAPI" in html

    def test_admin_index_has_onboarding(self):
        """首次使用引导：存在引导相关 DOM"""
        html = (ROOT / "admin_static" / "index.html").read_text(encoding="utf-8")
        assert "onboardingOverlay" in html or "onboarding" in html
        assert "ONBOARDING" in html

    def test_admin_index_has_scan_progress(self):
        """扫描进度可视化：存在进度条与轮询逻辑"""
        html = (ROOT / "admin_static" / "index.html").read_text(encoding="utf-8")
        assert "scanProgressBox" in html
        assert "scan/status" in html
        assert "progress" in html
