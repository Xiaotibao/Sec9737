#!/usr/bin/env python3
"""
管理后台启动脚本 - 自动设置 PYTHONPATH，解决 ModuleNotFoundError
直接运行: python run_admin.py
"""
import sys
import os
import logging
from pathlib import Path

# 切换到脚本所在目录，确保路径正确
os.chdir(Path(__file__).resolve().parent)

# 将 src 加入路径
root = Path(__file__).resolve().parent
src = root / "src"
if str(src) not in sys.path:
    sys.path.insert(0, str(src))

# 抑制 Flask/Werkzeug 警告（PowerShell 会将其当作错误）
logging.getLogger("werkzeug").setLevel(logging.ERROR)
logging.getLogger("werkzeug.serving").setLevel(logging.ERROR)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1", help="监听地址")
    ap.add_argument("--port", type=int, default=35555, help="端口号")
    ap.add_argument("--all", action="store_true", dest="all_interfaces", help="监听所有网卡(0.0.0.0)")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()
    host = "0.0.0.0" if args.all_interfaces else args.host
    url = f"http://127.0.0.1:{args.port}/admin" if host == "0.0.0.0" else f"http://{host}:{args.port}/admin"

    from api_security.admin.app import app, STATIC_DIR
    idx = (STATIC_DIR / "index.html").exists()

    print("=" * 50)
    print("API 安全管理后台")
    print(f"请在浏览器打开: {url}")
    print(f"静态目录: {STATIC_DIR}")
    print(f"index.html: {'存在' if idx else '不存在'}")
    print("按 Ctrl+C 停止")
    print("=" * 50)

    # 延迟 2 秒后自动打开浏览器
    def _open_browser():
        import time
        time.sleep(2)
        import webbrowser
        webbrowser.open(url)
    import threading
    threading.Thread(target=_open_browser, daemon=True).start()

    # 优先使用 waitress（无警告），否则用 Flask 内置
    try:
        from waitress import serve
        print("使用 Waitress 服务器（无警告）")
        serve(app, host=host, port=args.port, threads=4)
    except ImportError:
        import flask
        flask.cli.show_server_banner = lambda *x: None
        app.run(host=host, port=args.port, debug=args.debug, use_reloader=False)
