# API Security

API security detection solution based on **OpenSCA + Semgrep + afrog**, covering OWASP API Top 10 vulnerabilities, with OpenAPI compliance checks, team management, AI repair suggestions, API change analysis, custom rules, multi-tenancy, and SSO.

**Community Edition (default)**: No billing, no team limits, open source.  
**Enterprise Edition**: Plan billing, multi-tenancy, SSO. Set `API_SECURITY_EDITION=enterprise` to enable.

### Repository Contents

This repository contains the open-source ready package:

| Path | Description |
|------|-------------|
| `src/api_security/` | Core detection, admin API, billing, tenant, AI repair, native rules |
| `admin_static/` | Admin dashboard frontend |
| `config/` | Config templates (`api_security.example.yaml`), native rules, OWASP rules |
| `docs/` | API, Webhook, AI repair, CI/CD, community edition docs |
| `examples/` | Sample OpenAPI project |
| `scripts/` | Self-check, report, alerts, GitLab CI interface |
| `.github/workflows/` | GitHub Actions templates |
| `vscode-extension/` | VS Code extension source |
| `tests/` | Unit and integration tests |
| `fixtures/` | Test fixtures (OpenAPI samples) |

**First-time setup**: Copy `config/api_security.example.yaml` to `config/api_security.yaml` and adjust as needed.

---

## Table of Contents

- [Feature Overview](#feature-overview)
- [Requirements](#requirements)
- [Quick Start](#quick-start)
- [CLI Usage](#cli-usage)
- [Admin Dashboard](#admin-dashboard)
- [REST API](#rest-api)
- [Configuration](#configuration)
- [CI/CD Integration](#cicd-integration)
- [VS Code Extension](#vs-code-extension)
- [FAQ](#faq)
- [License & Contributing](#license--contributing)
- [Appendix: 中文版](#appendix-中文版)

---

## Feature Overview

### Core Detection

| Feature | Description |
|---------|-------------|
| **Vulnerability Detection** | OpenSCA (dependency CVE) + Semgrep (code rules) + afrog (dynamic scan) + custom rules |
| **OWASP API Top 10** | All 10 vulnerability types covered. See [docs/OWASP_API_TOP10_COVERAGE.md](docs/OWASP_API_TOP10_COVERAGE.md) |
| **OpenAPI Parsing** | Compatible with 2.0/3.0, auto-detect OpenAPI/Swagger files |
| **Compliance Checks** | Missing security, sensitive field exposure, missing 401/403 definitions |
| **Incremental Scan** | Scan only git-changed files for faster CI |

### Admin Dashboard

| Feature | Description |
|---------|-------------|
| **Statistics** | Member scan counts, vulnerability counts by severity |
| **Finding Filter** | Filter by API, severity, tool; view details with AI repair suggestions |
| **Trend Analysis** | 7/30-day vulnerability trend charts |
| **Member Management** | Add/edit/delete members (Enterprise: plan limits) |
| **Critical Summary** | High-severity findings, popup alerts |
| **Scan** | Trigger scans from UI with progress bar |
| **Export** | Excel/PDF reports with filters |
| **Data Cleanup** | Retention policy by day/month |
| **Audit Logs** | Operation logs, export |
| **Webhook** | Feishu/Slack/DingTalk/WeCom/custom; push on scan complete or Critical. See [docs/WEBHOOK_SETUP.md](docs/WEBHOOK_SETUP.md) |
| **API Changes** | Upload old/new OpenAPI for diff, flag high-risk changes |
| **Custom Rules** | 24 rules, enable/disable |
| **Plan Purchase** | Enterprise: plan list, purchase, upgrade (hidden in Community) |
| **Tenant Management** | Enterprise: super admin create/disable tenants, SSO config |

### Other

| Feature | Description |
|---------|-------------|
| **AI Repair Suggestions** | Repair suggestions and patch drafts in finding details; LLM or static templates |
| **VS Code Extension** | Workspace scan, Problems panel, Webview results |
| **GitHub Actions** | Basic/advanced templates, incremental scan, DingTalk/WeCom alerts |
| **GitLab CI / Jenkins** | Templates and docs, MR incremental scan |

---

## Requirements

- **Python 3.10+**
- **Dependencies**: `pip install -r requirements.txt` (admin: `pip install -r requirements-admin.txt`)

**Optional (full detection)**:

- **OpenSCA-cli** — Dependency vulnerability scan (skipped if not installed)
- **afrog** — Dynamic scan, requires `afrog_url`. See [docs/AFROG_SETUP.md](docs/AFROG_SETUP.md)

---

## Quick Start

### 1. Install

```bash
pip install -r requirements.txt
# Admin dashboard
pip install -r requirements-admin.txt
```

### 2. CLI Scan

```bash
# Windows PowerShell
$env:PYTHONPATH="src"

# Scan current directory
python -m api_security.cli scan . --output scan-result.json

# Specify OpenAPI
python -m api_security.cli scan . --openapi openapi.yaml --output scan-result.json

# Incremental scan (changed files only)
python -m api_security.cli scan . --incremental --base-ref origin/main --output scan-result.json
```

### 3. Start Admin Dashboard

```bash
python run_admin.py --port 35555
```

Open **http://127.0.0.1:35555/admin** in browser.

**Windows**: Double-click `一键启动.bat` to start and open the dashboard.

### Convenience Tools (Windows)

| File | Description |
|------|-------------|
| `一键启动.bat` | Start admin dashboard (port 35555), then visit http://127.0.0.1:35555/admin |
| `验证访问.bat` | Run `独立服务器.py` to verify browser access (data may be empty) |
| `测试服务器.bat` | Run `minimal_test_server.py`, minimal test server (port 9000), http://127.0.0.1:9000/ shows "OK" if env is OK |
| `打开管理后台.html` | Local HTML with startup instructions and dashboard link |
| `安装依赖.bat` | Install Python dependencies |
| `run_admin.bat` / `run_admin.ps1` | Alternative admin startup scripts |

### Scripts (scripts/)

| Script | Description |
|--------|-------------|
| `selfcheck.py` | Quick self-check, verify env and key paths |
| `generate_report.py` | Generate scan report |
| `check_license.py` | Check license (Enterprise) |
| `alert_dingtalk.py` | DingTalk alert |
| `alert_wechat.py` | WeCom alert |
| `gitlab_ci_interface.py` | GitLab CI interface |

---

## CLI Usage

### Subcommands

| Command | Description |
|---------|-------------|
| `scan <target>` | Full API security scan |
| `parse <file>` | Parse and validate OpenAPI only |
| `identify <path>` | Auto-detect OpenAPI files |
| `afrog-check <url>` | Check if afrog target is reachable |

### scan Options

| Option | Description |
|--------|-------------|
| `--openapi`, `-o` | OpenAPI/Swagger file path |
| `--afrog-url` | afrog dynamic scan API URL |
| `--output`, `-O` | Output JSON path |
| `--no-skip-on-fail` | Prompt on parse failure instead of skip |
| `--no-auto-openapi` | Disable OpenAPI auto-detect |
| `--incremental` | Incremental mode, scan git changes only |
| `--base-ref` | Incremental base ref, e.g. `origin/main` |
| `--previous-result` | Previous result path for merge display |

### parse Options

| Option | Description |
|--------|-------------|
| `--strict` | Strict validation |
| `--output`, `-O` | Output JSON path |
| `--fallback-prompt` | Show prompt on failure |

---

## Admin Dashboard

Visit `http://127.0.0.1:35555/admin` (port configurable).

### Tabs

| Tab | Feature |
|-----|---------|
| Plan Purchase | Current plan, API usage, purchase/upgrade (Community: hidden) |
| Statistics | Member scan counts, vulnerability counts |
| Finding Filter | Multi-filter, details, AI repair, export |
| Trend Analysis | 7/30-day trend charts |
| Member Management | Add/edit/delete members |
| Critical | High-severity summary, popup alerts |
| Scan | Configure target, project, afrog_url, run scan |
| Data Cleanup | Day/month retention, run cleanup |
| Audit Logs | Operation logs, export JSON |
| Webhook | Configure URL, events, platform, test send |
| API Changes | Upload OpenAPI diff, history reports |
| Custom Rules | Enable/disable rules |
| Tenant Management | Super admin create/disable tenants (Community: hidden) |
| Tutorial | Built-in guide |

### Tenant & Headers

For multi-tenancy, requests must include `X-Enterprise-Id` or `X-Tenant-Id`. Frontend adds via header tenant selector.

---

## REST API

Full API docs: [docs/API.md](docs/API.md). Below is a summary.

### General

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/edition` | Edition (community/enterprise) |
| GET | `/api/tenants` | List tenants |

### Scan

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/scan` | Submit scan. Body: `{target, openapi, afrog_url, project, progress, enterprise_id}` |
| GET | `/api/scan/status/<task_id>` | Scan progress |
| GET | `/api/results` | Scan result list |
| GET | `/api/results/<name>` | Single scan detail |

### Team Admin (/api/admin)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/admin/members` | Member list |
| POST | `/api/admin/members` | Add member |
| PUT | `/api/admin/members/<id>` | Update member |
| DELETE | `/api/admin/members/<id>` | Delete member |
| GET | `/api/admin/stats` | Statistics |
| GET | `/api/admin/critical` | Critical summary |
| GET | `/api/admin/findings` | Finding list (filter: api_name, severity, tool) |
| GET | `/api/admin/findings/<id>` | Finding detail (with AI repair) |
| POST | `/api/admin/export` | Export Excel/PDF |
| GET | `/api/admin/trend` | Trend data |
| GET | `/api/admin/trend/chart` | Trend chart SVG |
| GET | `/api/admin/afrog/check?url=` | afrog target reachability |

### Billing (/api/billing)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/billing/plans` | Plan list |
| GET | `/api/billing/license` | Current license |
| POST | `/api/billing/license` | Set license |
| POST | `/api/billing/quote` | Get quote |
| POST | `/api/billing/check` | Permission check |
| POST | `/api/billing/purchase` | Purchase |

### Other

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/admin/audit-logs` | Audit logs |
| GET | `/api/admin/audit-logs/export` | Export audit |
| GET | `/api/admin/webhooks` | Webhook list |
| POST | `/api/admin/webhooks` | Add Webhook |
| PUT | `/api/admin/webhooks/<id>` | Update Webhook |
| DELETE | `/api/admin/webhooks/<id>` | Delete Webhook |
| POST | `/api/admin/webhooks/<id>/test` | Test Webhook |
| GET | `/api/admin/storage/cleanup-config` | Cleanup config |
| POST | `/api/admin/storage/cleanup-config` | Save cleanup config |
| POST | `/api/admin/storage/cleanup` | Run cleanup |
| POST | `/api/admin/api-changes/compare` | OpenAPI compare |
| GET | `/api/admin/api-changes/reports` | Change report list |
| GET | `/api/admin/native-rules` | Custom rule list |
| POST | `/api/admin/native-rules/<id>/enable` | Enable/disable rule |

### Super Admin (/api/super, requires X-User-Email + SUPER_ADMIN_EMAILS)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/super/tenants` | List tenants |
| POST | `/api/super/tenants` | Create tenant |
| PUT | `/api/super/tenants/<id>` | Update tenant |
| GET | `/api/super/tenants/<id>` | Tenant detail |

### SSO

| Method | Path | Description |
|--------|------|-------------|
| GET | `/sso/login?tenant=` | Initiate SSO login |
| GET | `/sso/callback` | OIDC callback |
| GET | `/sso/logout` | Logout |
| GET | `/sso/status` | Login status |

---

## Configuration

### Environment Variables

| Variable | Description |
|----------|-------------|
| `API_SECURITY_EDITION` | `community` (default) or `enterprise` |
| `FLASK_SECRET_KEY` | Required for production, Session |
| `UNLIMITED_PACKAGE_TOKEN` | Enterprise GitHub Actions |
| `SUPER_ADMIN_EMAILS` | Super admin emails, comma-separated |
| `DINGTALK_WEBHOOK` | DingTalk bot Webhook |
| `WECOM_WEBHOOK` | WeCom bot Webhook |
| `OPENAI_API_KEY` | AI repair (optional) |
| `X-Enterprise-Id` | API header, tenant ID |

### Optional Config File

Copy `config/api_security.example.yaml` to `config/api_security.yaml` and customize:

```yaml
scan:
  target: "."
  openapi: null
  afrog_url: null

ai_repair:
  enabled: true
  llm_endpoint: "https://api.openai.com/v1/chat/completions"
  model: "gpt-4o-mini"
```

See [docs/AI_REPAIR_CONFIG.md](docs/AI_REPAIR_CONFIG.md).

### Custom Rules

Rules in `config/native_rules/rules.yaml`. See [docs/NATIVE_RULES.md](docs/NATIVE_RULES.md).

---

## CI/CD Integration

### GitHub Actions

- **Basic**: `.github/workflows/api-security-basic.yml` — Scan + local report
- **Advanced**: `api-security-advanced.yml` — Scan + DingTalk/WeCom alerts

Community: no `UNLIMITED_PACKAGE_TOKEN` needed. See [.github/workflows/README.md](.github/workflows/README.md).

### GitLab CI / Jenkins

- `.gitlab-ci-api-security-basic.yml.example`
- `Jenkinsfile.api-security.example`

See [docs/CI_CD_INTEGRATION.md](docs/CI_CD_INTEGRATION.md).

### Incremental Scan

MR/PR uses incremental scan by default. CLI: `--incremental --base-ref origin/main`.

---

## VS Code Extension

1. Enter `vscode-extension` directory
2. `npm install && npm run package` to build `.vsix`
3. VS Code: Extensions → Install from VSIX

Features: Workspace scan, Problems panel, Webview results, incremental scan. See [vscode-extension/README.md](vscode-extension/README.md).

---

## FAQ

**Q: OpenSCA not found?**  
A: Install OpenSCA-cli separately, or scan will skip it.

**Q: afrog not running?**  
A: Set `afrog_url` to afrog service, or run `docker-compose -f docker-compose.afrog.yml up -d`. See [docs/AFROG_SETUP.md](docs/AFROG_SETUP.md).

**Q: Community vs Enterprise?**  
A: Community: no billing, no team limits, no multi-tenancy/SSO. See [docs/COMMUNITY_EDITION.md](docs/COMMUNITY_EDITION.md).

**Q: API quota exceeded?**  
A: Enterprise: upgrade plan or wait for next month reset; Community: no limit.

**Q: How to enable AI repair?**  
A: Copy `config/api_security.example.yaml` to `config/api_security.yaml`, then set `OPENAI_API_KEY` or configure `ai_repair`. See [docs/AI_REPAIR_CONFIG.md](docs/AI_REPAIR_CONFIG.md).

---

## Project Structure

```
├── src/
│   ├── api_security/       # Core package
│   │   ├── core/           # Detection (OpenSCA, Semgrep, afrog)
│   │   ├── parser/         # OpenAPI parsing & compliance
│   │   ├── admin/          # Admin API
│   │   ├── billing/        # Plans, license
│   │   ├── tenant/         # Multi-tenancy
│   │   ├── ai_repair/      # AI repair
│   │   ├── api_change/     # API change analysis
│   │   ├── native_rules/   # Custom rules
│   │   ├── cli.py          # CLI entry
│   │   └── plugin.py       # Cursor/IDE integration
│   ├── data/               # Runtime data (created on first run)
│   └── scan_results/       # Scan outputs (created on first run)
├── admin_static/           # Admin frontend
├── config/
│   ├── api_security.example.yaml   # Config template (copy to api_security.yaml)
│   ├── native_rules/       # Custom rules
│   └── owasp_api_top10/    # OWASP rules
├── docs/                   # Documentation
├── examples/               # Sample projects
├── fixtures/               # Test fixtures
├── scripts/                # Self-check, report, alerts
├── tests/                  # Unit & integration tests
├── vscode-extension/       # VS Code extension source
├── .github/workflows/      # GitHub Actions templates
├── run_admin.py            # Start admin
├── 一键启动.bat            # Windows one-click start
├── docker-compose.afrog.yml # afrog Docker setup
└── requirements.txt
```

---

## Testing & Self-Check

```bash
$env:PYTHONPATH="src"  # Windows PowerShell
python -m pytest tests/ -v
```

**Quick self-check**: `python scripts/selfcheck.py`

---

## Disclaimer

**Detection results are for reference only. Conduct security assessment based on your business context.**

---

## License & Contributing

- **License**: Apache 2.0, see [LICENSE](LICENSE)
- **Contributing**: Welcome contributions, see [CONTRIBUTING.md](CONTRIBUTING.md)
- **Examples**: `examples/sample-api` for sample OpenAPI project

---

# Appendix: 中文版

## 仓库内容

本仓库为开源就绪包，包含：

| 路径 | 说明 |
|------|------|
| `src/api_security/` | 核心检测、管理 API、计费、租户、AI 修复、自研规则 |
| `admin_static/` | 管理后台前端 |
| `config/` | 配置模板（`api_security.example.yaml`）、自研规则、OWASP 规则 |
| `docs/` | API、Webhook、AI 修复、CI/CD、社区版文档 |
| `examples/` | 示例 OpenAPI 项目 |
| `scripts/` | 自检、报告、告警、GitLab CI 接口 |
| `.github/workflows/` | GitHub Actions 模板 |
| `vscode-extension/` | VS Code 插件源码 |
| `tests/` | 单元与集成测试 |
| `fixtures/` | 测试用 OpenAPI 样本 |

**首次使用**：将 `config/api_security.example.yaml` 复制为 `config/api_security.yaml` 并按需修改。

---

## 功能总览

### 核心检测

| 功能 | 说明 |
|------|------|
| **漏洞检测** | OpenSCA（依赖 CVE）+ Semgrep（代码规则）+ afrog（动态扫描）+ 自研规则 |
| **OWASP API Top 10** | 10 类漏洞均有对应检测逻辑，详见 [docs/OWASP_API_TOP10_COVERAGE.md](docs/OWASP_API_TOP10_COVERAGE.md) |
| **OpenAPI 解析** | 兼容 2.0/3.0，自动识别项目中的 OpenAPI/Swagger 文件 |
| **合规核查** | 缺失 security、敏感字段暴露、缺失 401/403 定义 |
| **增量扫描** | 仅扫描 git 变更文件，缩短 CI 时间 |

### 管理后台

| 功能 | 说明 |
|------|------|
| **统计概览** | 各成员扫描次数、各等级漏洞数量 |
| **漏洞筛选** | 按接口、等级、工具筛选，查看详情含 AI 修复建议 |
| **趋势分析** | 近 7/30 天漏洞数量趋势图 |
| **成员管理** | 新增/编辑/删除成员（商业版按套餐限制人数） |
| **Critical 汇总** | 高危漏洞统一查看，弹窗提醒 |
| **扫描** | 从界面触发扫描，支持进度条 |
| **导出** | Excel/PDF 报告，多维度筛选 |
| **数据清理** | 按天/月保留最近 N 天/月数据 |
| **审计日志** | 操作记录查询与导出 |
| **Webhook** | 飞书/Slack/钉钉/企业微信/自定义，扫描完成或 Critical 时推送，见 [docs/WEBHOOK_SETUP.md](docs/WEBHOOK_SETUP.md) |
| **API 变更** | 上传新旧 OpenAPI 对比，标记高风险变更 |
| **自研规则** | 24 条规则，可启用/禁用 |
| **套餐购买** | 商业版：套餐列表、购买、升级（社区版隐藏） |
| **租户管理** | 商业版：超级管理员创建/禁用租户、SSO 配置 |

### 其他

| 功能 | 说明 |
|------|------|
| **AI 修复建议** | 漏洞详情中展示修复建议与补丁草稿，支持 LLM 或静态模板 |
| **VS Code 插件** | 工作区扫描、问题面板、Webview 结果 |
| **GitHub Actions** | 基础/进阶模板，支持增量扫描、钉钉/企业微信告警 |
| **GitLab CI / Jenkins** | 模板与文档，含 MR 增量扫描 |

---

## 环境要求

- **Python 3.10+**
- **依赖**：`pip install -r requirements.txt`（管理后台需 `pip install -r requirements-admin.txt`）

**可选（完整检测）**：

- **OpenSCA-cli** — 依赖漏洞扫描（未安装则跳过）
- **afrog** — 动态扫描，需配置 `afrog_url`，见 [docs/AFROG_SETUP.md](docs/AFROG_SETUP.md)

---

## 快速开始

### 1. 安装

```bash
pip install -r requirements.txt
# 管理后台
pip install -r requirements-admin.txt
```

### 2. 命令行扫描

```bash
# Windows PowerShell
$env:PYTHONPATH="src"

# 扫描当前目录
python -m api_security.cli scan . --output scan-result.json

# 指定 OpenAPI
python -m api_security.cli scan . --openapi openapi.yaml --output scan-result.json

# 增量扫描（仅变更文件）
python -m api_security.cli scan . --incremental --base-ref origin/main --output scan-result.json
```

### 3. 启动管理后台

```bash
python run_admin.py --port 35555
```

浏览器打开 **http://127.0.0.1:35555/admin**。

**Windows**：双击 `一键启动.bat` 一键启动并打开后台。

### 便捷工具（Windows）

| 文件 | 说明 |
|------|------|
| `一键启动.bat` | 启动管理后台（端口 35555），启动后访问 http://127.0.0.1:35555/admin |
| `验证访问.bat` | 运行 `独立服务器.py`，验证浏览器能否访问管理后台（数据可能为空） |
| `测试服务器.bat` | 运行 `minimal_test_server.py`，启动最小测试服务器（端口 9000），访问 http://127.0.0.1:9000/ 看到 "OK" 即环境正常 |
| `打开管理后台.html` | 本地 HTML 页面，含启动命令说明与后台链接，可双击打开 |
| `安装依赖.bat` | 安装 Python 依赖 |
| `run_admin.bat` / `run_admin.ps1` | 其他管理后台启动脚本 |

### 脚本工具（scripts/）

| 脚本 | 说明 |
|------|------|
| `selfcheck.py` | 快速自检，验证环境与关键路径 |
| `generate_report.py` | 生成扫描报告 |
| `check_license.py` | 检查许可证（商业版） |
| `alert_dingtalk.py` | 钉钉告警 |
| `alert_wechat.py` | 企业微信告警 |
| `gitlab_ci_interface.py` | GitLab CI 接口 |

---

## 命令行使用

### 子命令

| 命令 | 说明 |
|------|------|
| `scan <target>` | 完整 API 安全扫描 |
| `parse <file>` | 仅解析并校验 OpenAPI |
| `identify <path>` | 自动识别 OpenAPI 文件 |
| `afrog-check <url>` | 检测 afrog 目标是否可达 |

### scan 参数

| 参数 | 说明 |
|------|------|
| `--openapi`, `-o` | OpenAPI/Swagger 文件路径 |
| `--afrog-url` | afrog 动态扫描的 API 地址 |
| `--output`, `-O` | 结果输出 JSON 路径 |
| `--no-skip-on-fail` | 解析失败时提示而非跳过 |
| `--no-auto-openapi` | 禁用 OpenAPI 自动识别 |
| `--incremental` | 增量模式，仅扫描 git 变更 |
| `--base-ref` | 增量基准，如 `origin/main` |
| `--previous-result` | 上次结果路径，用于合并展示 |

### parse 参数

| 参数 | 说明 |
|------|------|
| `--strict` | 严格验证 |
| `--output`, `-O` | 输出 JSON 路径 |
| `--fallback-prompt` | 失败时显示提示 |

---

## 管理后台

访问 `http://127.0.0.1:35555/admin`（端口可改）。

### 功能入口

| Tab | 功能 |
|-----|------|
| 套餐购买 | 当前套餐、API 用量、购买/升级（社区版隐藏） |
| 统计概览 | 成员扫描次数、各等级漏洞数 |
| 漏洞筛选 | 多维度筛选、查看详情、AI 修复建议、导出 |
| 趋势分析 | 近 7/30 天趋势图 |
| 成员管理 | 新增/编辑/删除成员 |
| Critical 漏洞 | 高危汇总、弹窗提醒 |
| 扫描 | 配置目标、项目、afrog_url，执行扫描 |
| 数据清理 | 按天/月保留策略、立即清理 |
| 审计日志 | 操作记录、导出 JSON |
| Webhook | 配置 URL、事件、平台、测试发送 |
| API 变更 | 上传 OpenAPI 对比、历史报告 |
| 自研规则 | 启用/禁用规则 |
| 租户管理 | 超级管理员创建/禁用租户（社区版隐藏） |
| 使用教程 | 内置指南 |

### 租户与请求头

多租户时，请求需携带 `X-Enterprise-Id` 或 `X-Tenant-Id`。前端通过页头租户选择器自动添加。

---

## REST API

完整接口说明见 [docs/API.md](docs/API.md)。以下为常用接口概览。

### 通用

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| GET | `/api/edition` | 版本信息（community/enterprise） |
| GET | `/api/tenants` | 列出租户（供选择器） |

### 扫描

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/scan` | 提交扫描，Body: `{target, openapi, afrog_url, project, progress, enterprise_id}` |
| GET | `/api/scan/status/<task_id>` | 扫描进度 |
| GET | `/api/results` | 扫描结果列表 |
| GET | `/api/results/<name>` | 单次扫描详情 |

### 团队管理（/api/admin）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/admin/members` | 成员列表 |
| POST | `/api/admin/members` | 新增成员 |
| PUT | `/api/admin/members/<id>` | 更新成员 |
| DELETE | `/api/admin/members/<id>` | 删除成员 |
| GET | `/api/admin/stats` | 统计 |
| GET | `/api/admin/critical` | Critical 汇总 |
| GET | `/api/admin/findings` | 漏洞列表（支持 api_name, severity, tool 筛选） |
| GET | `/api/admin/findings/<id>` | 漏洞详情（含 AI 修复建议） |
| POST | `/api/admin/export` | 导出 Excel/PDF |
| GET | `/api/admin/trend` | 趋势数据 |
| GET | `/api/admin/trend/chart` | 趋势图 SVG |
| GET | `/api/admin/afrog/check?url=` | afrog 目标可达性 |

### 套餐与计费（/api/billing）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/billing/plans` | 套餐列表 |
| GET | `/api/billing/license` | 当前许可证 |
| POST | `/api/billing/license` | 设置许可证 |
| POST | `/api/billing/quote` | 获取报价 |
| POST | `/api/billing/check` | 权限校验 |
| POST | `/api/billing/purchase` | 购买 |

### 其他

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/admin/audit-logs` | 审计日志 |
| GET | `/api/admin/audit-logs/export` | 导出审计 |
| GET | `/api/admin/webhooks` | Webhook 列表 |
| POST | `/api/admin/webhooks` | 添加 Webhook |
| PUT | `/api/admin/webhooks/<id>` | 更新 Webhook |
| DELETE | `/api/admin/webhooks/<id>` | 删除 Webhook |
| POST | `/api/admin/webhooks/<id>/test` | 测试 Webhook |
| GET | `/api/admin/storage/cleanup-config` | 清理配置 |
| POST | `/api/admin/storage/cleanup-config` | 保存清理配置 |
| POST | `/api/admin/storage/cleanup` | 执行清理 |
| POST | `/api/admin/api-changes/compare` | OpenAPI 对比 |
| GET | `/api/admin/api-changes/reports` | 变更报告列表 |
| GET | `/api/admin/native-rules` | 自研规则列表 |
| POST | `/api/admin/native-rules/<id>/enable` | 启用/禁用规则 |

### 超级管理员（/api/super，需 X-User-Email + SUPER_ADMIN_EMAILS）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/super/tenants` | 列出租户 |
| POST | `/api/super/tenants` | 创建租户 |
| PUT | `/api/super/tenants/<id>` | 更新租户 |
| GET | `/api/super/tenants/<id>` | 租户详情 |

### SSO

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/sso/login?tenant=` | 发起 SSO 登录 |
| GET | `/sso/callback` | OIDC 回调 |
| GET | `/sso/logout` | 登出 |
| GET | `/sso/status` | 登录状态 |

---

## 配置说明

### 环境变量

| 变量 | 说明 |
|------|------|
| `API_SECURITY_EDITION` | `community`（默认）或 `enterprise` |
| `FLASK_SECRET_KEY` | 生产环境必设，用于 Session |
| `UNLIMITED_PACKAGE_TOKEN` | 商业版 GitHub Actions 用 |
| `SUPER_ADMIN_EMAILS` | 超级管理员邮箱，逗号分隔 |
| `DINGTALK_WEBHOOK` | 钉钉机器人 Webhook |
| `WECOM_WEBHOOK` | 企业微信机器人 Webhook |
| `OPENAI_API_KEY` | AI 修复建议用（可选） |
| `X-Enterprise-Id` | API 请求头，租户 ID |

### 可选配置文件

将 `config/api_security.example.yaml` 复制为 `config/api_security.yaml` 并自定义：

```yaml
scan:
  target: "."
  openapi: null
  afrog_url: null

ai_repair:
  enabled: true
  llm_endpoint: "https://api.openai.com/v1/chat/completions"
  model: "gpt-4o-mini"
```

详见 [docs/AI_REPAIR_CONFIG.md](docs/AI_REPAIR_CONFIG.md)。

### 自研规则

规则位于 `config/native_rules/rules.yaml`，可自定义 YAML 规则。详见 [docs/NATIVE_RULES.md](docs/NATIVE_RULES.md)。

---

## CI/CD 集成

### GitHub Actions

- **基础**：`.github/workflows/api-security-basic.yml` — 扫描 + 本地报告
- **进阶**：`api-security-advanced.yml` — 扫描 + 钉钉/企业微信告警

社区版无需 `UNLIMITED_PACKAGE_TOKEN`。详见 [.github/workflows/README.md](.github/workflows/README.md)。

### GitLab CI / Jenkins

- `.gitlab-ci-api-security-basic.yml.example`
- `Jenkinsfile.api-security.example`

详见 [docs/CI_CD_INTEGRATION.md](docs/CI_CD_INTEGRATION.md)。

### 增量扫描

MR/PR 场景自动使用增量扫描，仅扫描变更文件。CLI：`--incremental --base-ref origin/main`。

---

## VS Code 插件

1. 进入 `vscode-extension` 目录
2. `npm install && npm run package` 生成 `.vsix`
3. VS Code：扩展 → 从 VSIX 安装

功能：工作区扫描、问题面板、Webview 结果、增量扫描。详见 [vscode-extension/README.md](vscode-extension/README.md)。

---

## 常见问题

**Q：OpenSCA 未找到？**  
A：需单独安装 OpenSCA-cli，或扫描将跳过该工具。

**Q：afrog 未运行？**  
A：配置 `afrog_url` 指向 afrog 服务，或使用 `docker-compose -f docker-compose.afrog.yml up -d`。见 [docs/AFROG_SETUP.md](docs/AFROG_SETUP.md)。

**Q：社区版与商业版区别？**  
A：社区版无计费、无团队限制、无多租户/SSO。详见 [docs/COMMUNITY_EDITION.md](docs/COMMUNITY_EDITION.md)。

**Q：套餐 API 超限？**  
A：商业版需升级套餐或等待下月重置；社区版无限制。

**Q：如何启用 AI 修复建议？**  
A：将 `config/api_security.example.yaml` 复制为 `config/api_security.yaml`，再配置 `OPENAI_API_KEY` 或 `ai_repair`。见 [docs/AI_REPAIR_CONFIG.md](docs/AI_REPAIR_CONFIG.md)。

---

## 项目结构

```
├── src/
│   ├── api_security/       # 核心包
│   │   ├── core/           # 检测逻辑（OpenSCA、Semgrep、afrog）
│   │   ├── parser/         # OpenAPI 解析与合规
│   │   ├── admin/          # 管理后台 API
│   │   ├── billing/        # 套餐、许可证
│   │   ├── tenant/         # 多租户
│   │   ├── ai_repair/      # AI 修复建议
│   │   ├── api_change/     # API 变更分析
│   │   ├── native_rules/   # 自研规则
│   │   ├── cli.py          # 命令行入口
│   │   └── plugin.py       # Cursor/IDE 集成
│   ├── data/               # 运行时数据（首次运行自动创建）
│   └── scan_results/       # 扫描结果（首次运行自动创建）
├── admin_static/           # 管理后台前端
├── config/
│   ├── api_security.example.yaml   # 配置模板（复制为 api_security.yaml）
│   ├── native_rules/       # 自研规则
│   └── owasp_api_top10/    # OWASP 规则
├── docs/                   # 文档
├── examples/               # 示例项目
├── fixtures/               # 测试用 OpenAPI 样本
├── scripts/                # 自检、报告、告警
├── tests/                  # 单元与集成测试
├── vscode-extension/       # VS Code 插件源码
├── .github/workflows/      # GitHub Actions 模板
├── run_admin.py            # 启动管理后台
├── 一键启动.bat            # Windows 一键启动
├── docker-compose.afrog.yml # afrog Docker 配置
└── requirements.txt
```

---

## 测试与自检

```bash
$env:PYTHONPATH="src"  # Windows PowerShell
python -m pytest tests/ -v
```

**快速自检**：`python scripts/selfcheck.py`

---

## 免责声明

**工具检测结果仅供参考，建议结合实际业务做安全评估。**

---

## 许可证与贡献

- **许可证**：Apache 2.0，见 [LICENSE](LICENSE)
- **贡献**：欢迎贡献，见 [CONTRIBUTING.md](CONTRIBUTING.md)
- **示例**：`examples/sample-api` 为示例 OpenAPI 项目
