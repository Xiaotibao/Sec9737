"""
全流程联调测试
验证 API 漏洞检测、后台、权限、引导等模块
"""

import json
import os
import sys
from pathlib import Path

# 添加 src 到路径
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pytest


class TestAPIDetection:
    """API 漏洞检测与 OpenAPI 解析"""

    def test_scan_with_openapi_fallback(self):
        """扫描 + OpenAPI 自动识别 + 降级"""
        from api_security.plugin import scan
        result = scan(ROOT / "fixtures", project="test")
        assert "detection" in result
        assert "openapi_parsed" in result
        assert result["openapi_parsed"] is True
        assert "alerts" in result
        assert "tool_disclaimer" in result.get("alerts", {})

    def test_cli_scan_output(self):
        """CLI 输出含 tool_disclaimer"""
        from api_security.cli import cmd_scan
        import argparse
        args = argparse.Namespace(
            target="fixtures",
            openapi=None,
            afrog_url=None,
            no_skip_on_fail=False,
            no_auto_openapi=False,
            output=str(ROOT / "scan_integration_test.json"),
            verbose=False,
        )
        code = cmd_scan(args)
        out_path = ROOT / "scan_integration_test.json"
        assert out_path.exists()
        data = json.loads(out_path.read_text(encoding="utf-8"))
        assert "tool_disclaimer" in data
        assert "detection" in data
        out_path.unlink(missing_ok=True)


class TestBillingAndGuide:
    """套餐与引导 API"""

    def test_plans_have_boundary(self):
        """套餐列表含 boundary 字段"""
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/billing/plans")
        assert r.status_code == 200
        data = json.loads(r.data)
        assert "plans" in data
        for p in data["plans"]:
            assert "boundary" in p
        assert "plan_single_limit" in data

    def test_guide_disclaimers(self):
        """引导/风控 API"""
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/guide/disclaimers")
        assert r.status_code == 200
        data = json.loads(r.data)
        assert "tool_disclaimer" in data

    def test_admin_findings(self):
        """漏洞筛选 API"""
        from api_security.admin.app import app
        with app.test_client() as c:
            r = c.get("/api/admin/findings")
        assert r.status_code == 200
        data = json.loads(r.data)
        assert "findings" in data
        assert "total" in data

    def test_disclaimers_api(self):
        """风控文案 API"""
        from api_security.risk_control import get_all_disclaimers
        d = get_all_disclaimers()
        assert "tool_disclaimer" in d
        assert "detection_scope" in d
        assert "compliance_scope" in d
        assert "plan_boundaries" in d


class TestPermissionChecker:
    """套餐权限管控"""

    def test_basic_plan_api_limit(self):
        """基础版 API 限额"""
        from api_security.billing import PermissionChecker
        from api_security.billing.license_store import set_license
        set_license("test_perm", "basic")
        checker = PermissionChecker("test_perm")
        ok, _ = checker.check_api_call("basic")
        assert ok is True

    def test_team_size_unlimited(self):
        """无限版团队规模校验"""
        from api_security.billing import PermissionChecker
        checker = PermissionChecker("test")
        ok, msg = checker.check_team_size("unlimited", 10, 0)
        assert ok is True
        ok2, _ = checker.check_team_size("unlimited", 11, 0)
        assert ok2 is False


class TestAlertFreqLimit:
    """弹窗频率限制"""

    def test_check_24h_limit(self):
        """24h 频率检查"""
        from api_security.alert.freq_limit import check_24h_limit
        # 首次应可弹窗
        assert check_24h_limit("proj1", "fp1") is True
