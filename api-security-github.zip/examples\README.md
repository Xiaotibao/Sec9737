# API Security 示例

## sample-api

包含 OpenAPI 规范的示例项目，用于快速体验扫描功能。

```bash
# 从仓库根目录
$env:PYTHONPATH="src"  # Windows
python -m api_security.cli scan examples/sample-api --output scan-result.json
```

详见 [sample-api/README.md](sample-api/README.md)。

## 更多示例

- **GitHub Actions**：`.github/workflows/api-security-basic.yml`
- **CI/CD 集成**：`docs/CI_CD_INTEGRATION.md`
- **Webhook 配置**：`docs/WEBHOOK_SETUP.md`
