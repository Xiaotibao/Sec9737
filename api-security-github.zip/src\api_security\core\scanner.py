"""
统一扫描入口
整合漏洞检测 + OpenAPI 解析 + 降级机制

流程：
1. OpenAPI 解析与合规（可选，失败时按降级策略跳过）
2. 漏洞检测（OpenSCA + Semgrep + afrog）
3. 高危漏洞提醒（Critical 弹窗、High 通知，含 24h 频率限制）
"""

from pathlib import Path
from typing import Optional, Callable

from loguru import logger

from .detector import APIVulnerabilityDetector, DetectionResult
from ..parser import OpenAPIParser, ComplianceChecker
from ..fallback import FallbackHandler, FallbackAction, identify_and_import_openapi


def run_api_scan(
    target: str | Path,
    openapi: Optional[str | Path] = None,
    afrog_url: Optional[str] = None,
    skip_openapi_on_fail: bool = True,
    auto_identify_openapi: bool = True,
    project: str = "",
    skip_compliance_check: bool = False,
    progress_callback: Optional[Callable[[str, int, str], None]] = None,
    incremental: bool = False,
    base_ref: Optional[str] = None,
    previous_result_path: Optional[str | Path] = None,
) -> dict:
    """
    执行完整 API 安全扫描（可直接调用）

    流程：
    1. 若提供 openapi 路径，解析并做合规核查；解析失败时按降级策略处理
    2. 若未提供且 auto_identify_openapi，尝试自动识别
    3. 执行漏洞检测（OpenSCA + Semgrep + afrog）

    Args:
        target: 扫描目标路径
        openapi: OpenAPI 文档路径（可选）
        afrog_url: afrog 扫描的 API URL（可选）
        skip_openapi_on_fail: 解析失败时是否跳过合规检测
        auto_identify_openapi: 是否自动识别项目中的 OpenAPI 文档
        incremental: 增量模式，仅扫描 git 变更文件
        base_ref: 增量基准引用，如 origin/main
        previous_result_path: 上次扫描结果路径，用于合并

    Returns:
        {
            "detection": DetectionResult,
            "openapi_parsed": bool,
            "compliance": ComplianceResult | None,
            "compliance_skipped": bool,
        }
    """
    def _report(stage: str, progress: int, message: str):
        if progress_callback:
            progress_callback(stage, progress, message)

    target_path = Path(target)
    compliance_result = None
    openapi_parsed = False
    compliance_skipped = False
    changed_files: list[Path] = []
    openapi_changed = True

    if incremental:
        from ..incremental import get_changed_files, get_changed_openapi
        changed_files = get_changed_files(target_path, base_ref=base_ref, include_untracked=True)
        openapi_changed = get_changed_openapi(target_path, base_ref=base_ref)
        _report("openapi_parsing", 5, f"增量模式: {len(changed_files)} 个变更文件")

    # 1. OpenAPI 解析与合规（增量且 OpenAPI 未变更时可跳过合规）
    if not incremental:
        _report("openapi_parsing", 5, "解析 OpenAPI...")
    openapi_path = Path(openapi) if openapi else None
    if not openapi_path and auto_identify_openapi:
        parse_result = identify_and_import_openapi(target_path)
        if parse_result and parse_result.success:
            openapi_path = parse_result.source and Path(parse_result.source)
            openapi_parsed = True
    if not incremental:
        _report("openapi_parsing", 10, "OpenAPI 识别完成" if openapi_parsed else "未发现 OpenAPI")

    skip_compliance_for_incremental = incremental and not openapi_changed
    if openapi_path and not skip_compliance_for_incremental:
        _report("openapi_parsing", 12, "解析 OpenAPI 文档...")
        handler = FallbackHandler(
            on_failure=FallbackAction.SKIP if skip_openapi_on_fail else FallbackAction.PROMPT,
        )
        parse_result, compliance_result = handler.parse_with_fallback(openapi_path)
        openapi_parsed = parse_result.success
        if not parse_result.success:
            compliance_skipped = True
        elif skip_compliance_check:
            compliance_result = None
            compliance_skipped = True
        _report("openapi_parsing", 15, "OpenAPI 解析完成")
    else:
        if not incremental:
            _report("openapi_parsing", 15, "跳过 OpenAPI")
        elif skip_compliance_for_incremental:
            compliance_skipped = True
            _report("openapi_parsing", 15, "OpenAPI 未变更，跳过合规")

    if openapi_path and compliance_result is not None:
        _report("compliance", 20, "合规核查...")
        _report("compliance", 25, "合规核查完成")

    # 2. 漏洞检测（增量时仅 Semgrep 扫变更文件，OpenSCA 可跳过）
    include_paths = [str(p) for p in changed_files] if changed_files else None
    detector = APIVulnerabilityDetector(
        target_path=target_path,
        openapi_path=openapi_path,
        afrog_url=afrog_url,
        include_paths=include_paths,
        skip_opensca_incremental=bool(incremental),
    )
    detection = detector.run(progress_callback=progress_callback)

    # 2.5 增量模式：与历史结果合并
    if incremental and previous_result_path:
        from ..incremental.merge_result import merge_incremental_with_previous
        detection.findings = merge_incremental_with_previous(
            detection.findings,
            previous_result_path,
            changed_files,
            target_path,
        )

    # 2.6 合并 OpenAPI 合规发现（含 OWASP 类别）
    if compliance_result:
        from ..owasp.mapping import compliance_to_findings
        from .detector import Finding
        for cf in compliance_to_findings(compliance_result):
            detection.findings.append(Finding(
                tool=cf["tool"],
                severity=cf["severity"],
                title=cf["title"],
                description=cf["description"],
                location=cf.get("location"),
                rule_id=cf.get("rule_id"),
                owasp_category=cf.get("owasp_category"),
            ))

    _report("done", 100, "扫描完成")

    # 3. 高危漏洞提醒：计算需弹窗/通知的漏洞
    from ..alert import process_findings_for_alerts
    findings_dict = [
        {"tool": f.tool, "severity": f.severity, "title": f.title, "description": f.description,
         "location": f.location, "cve_id": f.cve_id, "rule_id": f.rule_id, "owasp_category": getattr(f, "owasp_category", None), "project": project}
        for f in detection.findings
    ]
    alerts = process_findings_for_alerts(findings_dict, project)

    return {
        "detection": detection,
        "openapi_parsed": openapi_parsed,
        "compliance": compliance_result,
        "compliance_skipped": compliance_skipped,
        "alerts": alerts,
    }
