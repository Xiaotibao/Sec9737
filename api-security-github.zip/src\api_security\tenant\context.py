"""
租户上下文 - 请求级 tenant_id
"""

import os
from contextvars import ContextVar

_tenant_id_var: ContextVar[str] = ContextVar("tenant_id", default="default")


def get_current_tenant_id() -> str:
    """获取当前请求的租户 ID"""
    return _tenant_id_var.get()


def set_current_tenant_id(tenant_id: str) -> None:
    """设置当前租户 ID"""
    _tenant_id_var.set(tenant_id or "default")
