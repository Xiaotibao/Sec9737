"""
多租户 - 企业/租户隔离
"""

from .model import Tenant, get_tenant, list_tenants, create_tenant, update_tenant, ensure_default_tenant
from .context import get_current_tenant_id, set_current_tenant_id
from .data import (
    get_tenant_members,
    get_tenant_member,
    add_tenant_member,
    update_tenant_member,
    delete_tenant_member,
    get_tenant_scan_metadata,
    set_tenant_scan_metadata,
    migrate_to_tenant_storage,
)

__all__ = [
    "Tenant",
    "get_tenant",
    "list_tenants",
    "create_tenant",
    "update_tenant",
    "ensure_default_tenant",
    "get_current_tenant_id",
    "set_current_tenant_id",
    "get_tenant_members",
    "get_tenant_member",
    "add_tenant_member",
    "update_tenant_member",
    "delete_tenant_member",
    "get_tenant_scan_metadata",
    "set_tenant_scan_metadata",
    "migrate_to_tenant_storage",
]


def get_tenant_id_from_request(request) -> str:
    """从请求中获取租户 ID（X-Enterprise-Id / X-Tenant-Id / enterprise_id / tenant_id）"""
    try:
        body = request.get_json(silent=True)
    except Exception:
        body = None
    return (
        request.headers.get("X-Enterprise-Id")
        or request.headers.get("X-Tenant-Id")
        or (body or {}).get("enterprise_id")
        or (body or {}).get("tenant_id")
        or request.args.get("enterprise_id")
        or request.args.get("tenant_id")
        or "default"
    )
