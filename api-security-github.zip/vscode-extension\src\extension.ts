/**
 * API Security VS Code 扩展
 * 调用 api_security 核心逻辑，展示扫描结果到问题面板
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import { spawn } from "child_process";

const DIAGNOSTIC_COLLECTION = "api-security";
const OUTPUT_CHANNEL_NAME = "API Security";

interface Finding {
  tool: string;
  severity: string;
  title: string;
  description: string;
  location?: string;
  cve_id?: string;
  rule_id?: string;
}

interface ScanResult {
  tool_disclaimer?: string;
  detection?: {
    findings: Finding[];
    findings_count?: number;
    tools_run?: string[];
    tools_skipped?: string[];
  };
  openapi_parsed?: boolean;
  compliance_skipped?: boolean;
  compliance?: Record<string, unknown>;
}

let diagnosticCollection: vscode.DiagnosticCollection;
let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
  diagnosticCollection = vscode.languages.createDiagnosticCollection(DIAGNOSTIC_COLLECTION);
  outputChannel = vscode.window.createOutputChannel(OUTPUT_CHANNEL_NAME);

  context.subscriptions.push(
    vscode.commands.registerCommand("api-security.scan", () => runScan(context)),
    vscode.commands.registerCommand("api-security.parse", () => runParse(context)),
    vscode.commands.registerCommand("api-security.viewResults", () => viewResults(context)),
    vscode.commands.registerCommand("api-security.clearResults", () => clearResults()),
    diagnosticCollection
  );

  log("API Security 扩展已激活");
}

export function deactivate() {
  diagnosticCollection.dispose();
}

function log(msg: string) {
  outputChannel.appendLine(`[${new Date().toISOString()}] ${msg}`);
}

function getWorkspaceRoot(): string | undefined {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders || folders.length === 0) return undefined;
  return folders[0].uri.fsPath;
}

function getConfig() {
  const cfg = vscode.workspace.getConfiguration("apiSecurity");
  return {
    pythonPath: cfg.get<string>("pythonPath") || "python",
    target: cfg.get<string>("target") || ".",
    openapiPath: cfg.get<string | null>("openapiPath"),
    afrogUrl: cfg.get<string | null>("afrogUrl"),
    incremental: cfg.get<boolean>("incremental") ?? false,
    baseRef: cfg.get<string | null>("baseRef"),
  };
}

function loadYamlConfig(workspaceRoot: string): Partial<{ target: string; openapi: string | null; afrog_url: string | null; incremental: boolean; base_ref: string | null }> {
  const paths = [
    path.join(workspaceRoot, "api_security.yaml"),
    path.join(workspaceRoot, "config", "api_security.yaml"),
  ];
  for (const p of paths) {
    if (fs.existsSync(p)) {
      try {
        const content = fs.readFileSync(p, "utf-8");
        const target = content.match(/target:\s*["']?([^"'\n]+)/)?.[1]?.trim() || ".";
        const openapi = content.match(/openapi(?:_path)?:\s*(null|[^"\n]+)/)?.[1];
        const afrog = content.match(/afrog_url:\s*(null|[^"\n]+)/)?.[1];
        const inc = content.match(/incremental:\s*(true|false)/i)?.[1]?.toLowerCase() === "true";
        const baseRef = content.match(/base_ref:\s*(null|[^"\n]+)/)?.[1];
        return {
          target: target === "null" ? "." : target,
          openapi: openapi === "null" ? null : (openapi?.trim() || null),
          afrog_url: afrog === "null" ? null : (afrog?.trim() || null),
          incremental: inc,
          base_ref: baseRef === "null" ? null : (baseRef?.trim() || null),
        };
      } catch {
        // ignore parse errors
      }
    }
  }
  return {};
}

function parseLocation(loc: string | undefined, workspaceRoot: string): { uri: vscode.Uri; range: vscode.Range } | null {
  if (!loc || !workspaceRoot) return null;
  // 格式: path 或 path:line 或 path:line:col（支持 Windows C:\path:line）
  const match = loc.match(/^(.+):(\d+)(?::(\d+))?$/);
  let filePath = match ? match[1] : loc;
  const line = match ? Math.max(0, parseInt(match[2], 10) - 1) : 0;
  const col = match && match[3] ? Math.max(0, parseInt(match[3], 10)) : 0;
  if (!path.isAbsolute(filePath)) {
    filePath = path.join(workspaceRoot, filePath);
  }
  if (!fs.existsSync(filePath)) return null;
  const uri = vscode.Uri.file(filePath);
  const range = new vscode.Range(line, col, line, Math.max(col + 1, 1));
  return { uri, range };
}

function severityToDiagnosticSeverity(sev: string): vscode.DiagnosticSeverity {
  switch ((sev || "").toLowerCase()) {
    case "critical": return vscode.DiagnosticSeverity.Error;
    case "high": return vscode.DiagnosticSeverity.Error;
    case "medium": return vscode.DiagnosticSeverity.Warning;
    case "low":
    case "info": return vscode.DiagnosticSeverity.Information;
    default: return vscode.DiagnosticSeverity.Warning;
  }
}

function applyDiagnostics(findings: Finding[], workspaceRoot: string) {
  diagnosticCollection.clear();
  const byFile = new Map<string, vscode.Diagnostic[]>();

  for (const f of findings) {
    const locInfo = parseLocation(f.location, workspaceRoot);
    const uri = locInfo ? locInfo.uri : vscode.Uri.file(path.join(workspaceRoot, ".api-security-placeholder"));
    const range = locInfo ? locInfo.range : new vscode.Range(0, 0, 0, 1);
    const msg = `[${f.tool}] ${f.title}${f.cve_id ? ` (${f.cve_id})` : ""}`;
    const diag = new vscode.Diagnostic(range, `${msg}\n${f.description}`, severityToDiagnosticSeverity(f.severity));
    diag.source = "api-security";
    diag.code = f.rule_id || f.cve_id || f.tool;

    const key = uri.toString();
    if (!byFile.has(key)) byFile.set(key, []);
    byFile.get(key)!.push(diag);
  }

  for (const [uriStr, diags] of byFile) {
    try {
      const uri = vscode.Uri.parse(uriStr);
      if (uri.fsPath.endsWith(".api-security-placeholder")) continue;
      diagnosticCollection.set(uri, diags);
    } catch {
      // skip invalid uri
    }
  }
}

function runScan(context: vscode.ExtensionContext) {
  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showErrorMessage("请先打开工作区");
    return;
  }

  const config = getConfig();
  const yamlCfg = loadYamlConfig(root);
  const target = path.join(root, yamlCfg.target || config.target);
  const openapi = yamlCfg.openapi ?? config.openapiPath;
  const afrogUrl = yamlCfg.afrog_url ?? config.afrogUrl;
  const incremental = yamlCfg.incremental ?? config.incremental;
  const baseRef = yamlCfg.base_ref ?? config.baseRef;

  outputChannel.show();
  log(`开始扫描: ${target}${incremental ? " (增量模式)" : ""}`);

  const args = ["-m", "api_security.cli", "scan", target];
  if (openapi) args.push("--openapi", path.isAbsolute(openapi) ? openapi : path.join(root, openapi));
  if (afrogUrl) args.push("--afrog-url", afrogUrl);
  if (incremental) {
    args.push("--incremental");
    if (baseRef) args.push("--base-ref", baseRef);
    const prevPath = path.join(root, "api-security-scan-result.json");
    if (fs.existsSync(prevPath)) args.push("--previous-result", prevPath);
  }

  const env = { ...process.env };
  const srcPath = path.join(root, "src");
  if (fs.existsSync(path.join(srcPath, "api_security"))) {
    env.PYTHONPATH = (env.PYTHONPATH ? `${env.PYTHONPATH}${path.delimiter}` : "") + srcPath;
  }

  const finalOutPath = path.join(root, "api-security-scan-result.json");
  args.push("--output", finalOutPath);

  const proc = spawn(config.pythonPath, args, {
    cwd: root,
    env,
  });

  let stderr = "";
  proc.stderr?.on("data", (d) => { stderr += d.toString(); log(d.toString().trim()); });
  proc.stdout?.on("data", (d) => log(d.toString().trim()));

  proc.on("close", (code) => {
    const altPath = path.join(root, "api-security-scan-result.json");
    const resultPath = fs.existsSync(finalOutPath) ? finalOutPath : (fs.existsSync(altPath) ? altPath : null);

    if (resultPath) {
      try {
        const data: ScanResult = JSON.parse(fs.readFileSync(resultPath, "utf-8"));
        const findings = data.detection?.findings || [];
        applyDiagnostics(findings, root);
        const count = findings.length;
        log(`扫描完成，发现 ${count} 条`);
        vscode.window.showInformationMessage(`API Security: 扫描完成，发现 ${count} 条`);
      } catch (e) {
        log(`解析结果失败: ${e}`);
      }
    } else {
      log(`扫描退出码: ${code}`);
      if (stderr) log(stderr);
      vscode.window.showWarningMessage("API Security: 扫描完成，但未生成结果文件。请确保已安装 api_security。");
    }
  });

  proc.on("error", (err) => {
    log(`执行失败: ${err.message}`);
    vscode.window.showErrorMessage(`API Security: 执行失败 - ${err.message}`);
  });
}

function runParse(context: vscode.ExtensionContext) {
  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showErrorMessage("请先打开工作区");
    return;
  }

  vscode.window.showOpenDialog({
    canSelectMany: false,
    filters: { "OpenAPI": ["yaml", "yml", "json"] },
  }).then((uris) => {
    if (!uris?.[0]) return;
    const filePath = uris[0].fsPath;
    const config = getConfig();

    outputChannel.show();
    log(`解析 OpenAPI: ${filePath}`);

    const env = { ...process.env };
    const srcPath = path.join(root, "src");
    if (fs.existsSync(path.join(srcPath, "api_security"))) {
      env.PYTHONPATH = (env.PYTHONPATH ? `${env.PYTHONPATH}${path.delimiter}` : "") + srcPath;
    }
    const proc = spawn(config.pythonPath, ["-m", "api_security.cli", "parse", filePath, "--output", path.join(root, "api-security-parse-result.json")], {
      cwd: root,
      env,
    });

    let out = "";
    proc.stdout?.on("data", (d) => { out += d.toString(); log(d.toString().trim()); });
    proc.stderr?.on("data", (d) => { out += d.toString(); log(d.toString().trim()); });

    proc.on("close", (code) => {
      if (code === 0) {
        vscode.window.showInformationMessage("API Security: OpenAPI 解析成功");
      } else {
        vscode.window.showWarningMessage("API Security: 解析失败");
      }
    });
  });
}

function viewResults(_context: vscode.ExtensionContext) {
  const root = getWorkspaceRoot();
  if (!root) return;

  const paths = [
    path.join(root, "api-security-scan-result.json"),
    path.join(root, "src", "scan_results"),
    path.join(root, "scan_results"),
  ];

  let found = false;
  for (const p of paths) {
    if (fs.existsSync(p)) {
      if (fs.statSync(p).isDirectory()) {
        const files = fs.readdirSync(p).filter((f) => f.startsWith("scan_") && f.endsWith(".json")).sort().reverse();
        if (files[0]) {
          const data: ScanResult = JSON.parse(fs.readFileSync(path.join(p, files[0]), "utf-8"));
          showResultsInDoc(data, root);
          found = true;
          break;
        }
      } else {
        const data: ScanResult = JSON.parse(fs.readFileSync(p, "utf-8"));
        showResultsInDoc(data, root);
        found = true;
        break;
      }
    }
  }

  if (!found) {
    vscode.window.showInformationMessage("API Security: 暂无扫描结果，请先执行扫描");
  }
}

function showResultsInDoc(data: ScanResult, root: string) {
  const findings = data.detection?.findings || [];
  const panel = vscode.window.createWebviewPanel(
    "apiSecurityResults",
    "API Security 扫描结果",
    vscode.ViewColumn.Beside,
    {}
  );
  const rows = findings.map((f) => `
    <tr>
      <td>${escapeHtml(f.severity)}</td>
      <td>${escapeHtml(f.tool)}</td>
      <td>${escapeHtml(f.title)}</td>
      <td>${escapeHtml((f.location || "").substring(0, 50))}</td>
      <td>${escapeHtml(f.description.substring(0, 80))}...</td>
    </tr>
  `).join("");
  panel.webview.html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><style>
  body{font-family:var(--vscode-font-family);padding:16px;background:var(--vscode-editor-background);color:var(--vscode-editor-foreground);}
  table{border-collapse:collapse;width:100%;}
  th,td{border:1px solid var(--vscode-panel-border);padding:8px;text-align:left;}
  th{background:var(--vscode-list-hoverBackground);}
  .critical{color:#dc2626;}
  .high{color:#ea580c;}
  .medium{color:#ca8a04;}
</style></head>
<body>
  <h2>扫描结果 (${findings.length} 条)</h2>
  <p>${escapeHtml(data.tool_disclaimer || "工具检测结果仅供参考")}</p>
  <table>
    <tr><th>等级</th><th>工具</th><th>标题</th><th>位置</th><th>描述</th></tr>
    ${rows || "<tr><td colspan='5'>无发现</td></tr>"}
  </table>
</body>
</html>`;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function clearResults() {
  diagnosticCollection.clear();
  vscode.window.showInformationMessage("API Security: 已清除诊断");
}
