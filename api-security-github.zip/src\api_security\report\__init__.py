"""
扫描报告模块
含 API 风险趋势分析
"""

from .trend import get_trend_data, generate_trend_chart_svg

__all__ = ["get_trend_data", "generate_trend_chart_svg"]
