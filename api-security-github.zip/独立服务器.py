#!/usr/bin/env python3
"""
独立服务器 - 使用 Python 内置 http.server 先验证能否访问
仅静态页面，API 需配合主服务使用
运行: python 独立服务器.py
"""
import http.server
import socketserver
import webbrowser
import threading
import time
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT / "admin_static")  # http.server 以当前目录为根

PORT = 35555
URL = f"http://127.0.0.1:{PORT}/index.html"

class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

print("=" * 50)
print("静态页面服务器 (端口 %d)" % PORT)
print("仅用于验证浏览器能否访问")
print("地址: %s" % URL)
print("=" * 50)
print("\n2秒后自动打开浏览器...\n")

def open_browser():
    time.sleep(2)
    webbrowser.open(URL)

threading.Thread(target=open_browser, daemon=True).start()

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")
