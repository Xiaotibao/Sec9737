"""
API 接口批量扫描功能接口 - 预留
支持后续传入批量接口地址实现批量检测
"""

from typing import Any, Iterator

# 预留：批量扫描结果类型
# BatchScanResult = TypedDict("BatchScanResult", {"url": str, "findings": list, "status": str})


class BatchScanAdapter:
    """
    API 批量扫描适配器 - 预留接口
    支持传入 URL 列表，执行批量 API 安全检测
    """

    def scan_urls(self, urls: list[str], **kwargs: Any) -> list[dict]:
        """
        批量扫描接口地址（预留）
        Args:
            urls: 接口 URL 列表，如 ["https://api.example.com/users", ...]
            **kwargs: 扩展参数（超时、并发数、认证等）
        Returns:
            各 URL 的扫描结果列表，每项含 url、findings、status
        """
        raise NotImplementedError("API 批量扫描功能待迭代实现")

    def scan_urls_async(self, urls: list[str], **kwargs: Any) -> Iterator[dict]:
        """
        异步批量扫描（预留）
        支持流式返回结果，适用于大量 URL
        """
        raise NotImplementedError("异步批量扫描待迭代实现")

    def validate_urls(self, urls: list[str]) -> tuple[list[str], list[str]]:
        """
        校验 URL 格式（预留）
        Returns:
            (valid_urls, invalid_urls)
        """
        valid, invalid = [], []
        for u in urls:
            u = (u or "").strip()
            if u and (u.startswith("http://") or u.startswith("https://")):
                valid.append(u)
            elif u:
                invalid.append(u)
        return valid, invalid
