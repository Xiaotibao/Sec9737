"""
API 变更影响分析 - 路由
"""

import json

from flask import Blueprint, request, jsonify

from ..parser import OpenAPIParser
from ..api_change import generate_change_report
from ..storage.api_change import (
    save_baseline_openapi,
    load_baseline_openapi,
    save_change_report,
    load_change_report,
    list_change_reports,
)
from .webhook_sender import trigger_webhooks
from .webhook_config import EVENT_CRITICAL_FOUND, EVENT_API_CHANGE_CRITICAL
from .audit_log import log_audit_from_request

api_change_bp = Blueprint("api_change", __name__, url_prefix="/api/admin")


@api_change_bp.route("/api-changes/compare", methods=["POST"])
def compare_openapi():
    """
    对比 OpenAPI 变更
    Body: {
        "openapi_new": dict | str,  # 新 OpenAPI（dict 或 JSON 字符串）
        "openapi_old": dict | str | null,  # 旧 OpenAPI，null 时使用已保存的基准
        "project": str,
        "save_as_baseline": bool,  # 是否将新版本保存为下次对比的基准
    }
    """
    try:
        data = request.get_json() or {}
        openapi_new_raw = data.get("openapi_new")
        openapi_old_raw = data.get("openapi_old")
        project = data.get("project", "")
        save_as_baseline = data.get("save_as_baseline", True)

        if not openapi_new_raw:
            return jsonify({"error": "请提供 openapi_new"}), 400

        # 解析新 OpenAPI（支持 JSON / YAML）
        if isinstance(openapi_new_raw, dict):
            new_spec = openapi_new_raw
        else:
            raw_str = str(openapi_new_raw).strip()
            try:
                new_spec = json.loads(raw_str)
            except json.JSONDecodeError:
                try:
                    import yaml
                    new_spec = yaml.safe_load(raw_str)
                except Exception:
                    return jsonify({"error": "openapi_new 需为有效的 JSON 或 YAML"}), 400
            if not isinstance(new_spec, dict):
                return jsonify({"error": "openapi_new 格式无效"}), 400

        parser = OpenAPIParser(strict_validation=False)
        # 简单验证
        if "paths" not in new_spec and "swagger" not in new_spec and "openapi" not in new_spec:
            return jsonify({"error": "openapi_new 需为有效的 OpenAPI/Swagger 文档"}), 400

        # 解析旧 OpenAPI
        if openapi_old_raw is not None:
            if isinstance(openapi_old_raw, dict):
                old_spec = openapi_old_raw
            else:
                raw_str = str(openapi_old_raw).strip()
                try:
                    old_spec = json.loads(raw_str)
                except json.JSONDecodeError:
                    try:
                        import yaml
                        old_spec = yaml.safe_load(raw_str)
                    except Exception:
                        return jsonify({"error": "openapi_old 格式无效"}), 400
                if not isinstance(old_spec, dict):
                    return jsonify({"error": "openapi_old 格式无效"}), 400
            source_old = "request"
        else:
            baseline = load_baseline_openapi()
            if not baseline or "spec" not in baseline:
                return jsonify({
                    "error": "无基准 OpenAPI，请先上传并保存基准，或同时提供 openapi_old",
                    "hint": "首次使用时，可上传当前 OpenAPI 并勾选「保存为基准」",
                }), 400
            old_spec = baseline["spec"]
            source_old = baseline.get("source", "baseline")

        report = generate_change_report(
            old_spec=old_spec,
            new_spec=new_spec,
            project=project,
            source_old=source_old,
            source_new="request",
        )

        report_id = save_change_report(report)
        report["report_id"] = report_id

        if save_as_baseline:
            save_baseline_openapi(new_spec, project=project, source="request")

        # Critical 变更触发告警
        if report.get("has_critical"):
            critical_findings = [f for f in report.get("findings", []) if f.get("severity") == "critical"]
            msg = f"API 变更发现 {len(critical_findings)} 个 Critical 风险\n"
            for f in critical_findings[:5]:
                msg += f"- {f.get('op_id', '')}: {f.get('title', '')}\n"
            ctx = {
                "message": msg,
                "project": project,
                "findings": critical_findings,
                "report_id": report_id,
            }
            trigger_webhooks(EVENT_API_CHANGE_CRITICAL, ctx)
            # 同时触发 critical_found 以兼容已配置的 Webhook
            trigger_webhooks(EVENT_CRITICAL_FOUND, {
                "message": msg,
                "critical_findings": [{"title": f.get("title"), "vuln_name": f.get("op_id")} for f in critical_findings],
                "project": project,
            })

        log_audit_from_request("config", "api_change_compare", "success", "system", f"report_id={report_id}", request)

        return jsonify(report)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@api_change_bp.route("/api-changes/baseline", methods=["GET"])
def get_baseline_info():
    """获取基准 OpenAPI 信息（不含完整 spec）"""
    baseline = load_baseline_openapi()
    if not baseline:
        return jsonify({"has_baseline": False})
    return jsonify({
        "has_baseline": True,
        "project": baseline.get("project", ""),
        "source": baseline.get("source", ""),
        "saved_at": baseline.get("saved_at", ""),
    })


@api_change_bp.route("/api-changes/reports", methods=["GET"])
def list_reports():
    """列出变更报告"""
    limit = min(int(request.args.get("limit", 20)), 50)
    reports = list_change_reports(limit=limit)
    return jsonify({"reports": reports})


@api_change_bp.route("/api-changes/reports/<report_id>", methods=["GET"])
def get_report(report_id: str):
    """获取单份变更报告详情"""
    report = load_change_report(report_id)
    if not report:
        return jsonify({"error": "Not found"}), 404
    return jsonify(report)
