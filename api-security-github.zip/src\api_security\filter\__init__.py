"""
API 扫描结果多维度筛选
支持：接口名称、漏洞等级、检测工具 单独/组合筛选
"""

from .finder import filter_findings

__all__ = ["filter_findings"]
