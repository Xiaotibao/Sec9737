"""
批量导出 Excel/PDF 报告
含 API 风险趋势分析图表
"""

import json
from ..risk_control import TOOL_DISCLAIMER
from pathlib import Path
from io import BytesIO
from datetime import datetime

from ..tenant import get_tenant_scan_metadata, get_tenant_members

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESULTS_DIR = PROJECT_ROOT / "scan_results"


def _get_trend_svg(days: int = 7) -> str:
    """获取趋势图 SVG"""
    try:
        from ..report import generate_trend_chart_svg
        return generate_trend_chart_svg(days=days, width=360, height=180)
    except Exception:
        return ""

try:
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False


def _collect_all_findings(tenant_id: str = "default", api_name=None, severity=None, tool=None):
    """汇总所有扫描结果，支持筛选"""
    meta = get_tenant_scan_metadata(tenant_id)
    members = {m.id: m.name for m in get_tenant_members(tenant_id)}
    rows = []
    for scan_file, info in meta.items():
        path = RESULTS_DIR / scan_file
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            findings = data.get("detection", {}).get("findings", [])
            for f in findings:
                rows.append({
                    "scan_file": scan_file,
                    "timestamp": data.get("timestamp"),
                    "project": info.get("project", ""),
                    "member_name": info.get("member_name") or members.get(info.get("member_id"), ""),
                    "severity": f.get("severity", ""),
                    "tool": f.get("tool", ""),
                    "title": f.get("title", ""),
                    "description": (f.get("description") or "")[:200],
                    "location": f.get("location", ""),
                    "cve_id": f.get("cve_id", ""),
                })
        except Exception:
            pass
    if api_name or severity or tool:
        from ..filter import filter_findings
        rows = filter_findings(rows, api_name=api_name, severity=severity, tool=tool)
    return rows


def export_excel(tenant_id: str = "default", api_name=None, severity=None, tool=None, include_trend=True) -> tuple[BytesIO, str]:
    """导出 Excel"""
    if not EXCEL_AVAILABLE:
        raise RuntimeError("pip install openpyxl")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "漏洞报告"
    ws.append([TOOL_DISCLAIMER])
    ws.merge_cells("A1:J1")
    ws.cell(1, 1).font = Font(italic=True, size=10)
    ws.append([])

    if include_trend:
        try:
            from ..report import get_trend_data
            td = get_trend_data(7, tenant_id)
            if td.get("labels"):
                ws_trend = wb.create_sheet("趋势分析", 0)
                ws_trend["A1"] = "API 风险趋势（近7天）"
                for i, (lb, cnt) in enumerate(zip(td["labels"], td["counts"]), 2):
                    ws_trend[f"A{i}"] = lb
                    ws_trend[f"B{i}"] = cnt
        except Exception:
            pass

    headers = ["扫描文件", "时间", "项目", "成员", "等级", "工具", "标题", "描述", "位置", "CVE"]
    ws.append(headers)
    header_row = ws.max_row
    for c in range(1, len(headers) + 1):
        ws.cell(header_row, c).font = Font(bold=True)
        ws.cell(header_row, c).fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

    rows = _collect_all_findings(tenant_id=tenant_id, api_name=api_name, severity=severity, tool=tool)
    for r in rows:
        ws.append([
            r.get("scan_file", ""),
            r.get("timestamp", ""),
            r.get("project", ""),
            r.get("member_name", ""),
            r.get("severity", ""),
            r.get("tool", ""),
            r.get("title", ""),
            r.get("description", ""),
            r.get("location", ""),
            r.get("cve_id", ""),
        ])

    from openpyxl.utils import get_column_letter
    for col_idx in range(1, len(headers) + 1):
        col_letter = get_column_letter(col_idx)
        max_len = 0
        for row in ws.iter_rows(min_col=col_idx, max_col=col_idx):
            for c in row:
                if hasattr(c, "value"):
                    max_len = max(max_len, len(str(c.value or "")))
        ws.column_dimensions[col_letter].width = min(max_len + 2, 50)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = f"api-security-report-{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return buf, filename


def export_pdf(tenant_id: str = "default", api_name=None, severity=None, tool=None, include_trend=True) -> tuple[BytesIO, str]:
    """导出 PDF"""
    if not PDF_AVAILABLE:
        raise RuntimeError("pip install reportlab")

    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=60, leftMargin=60)
    styles = getSampleStyleSheet()
    style = ParagraphStyle(name="Custom", parent=styles["Normal"], fontSize=9)

    elements = []
    elements.append(Paragraph("API Security Scan Report", styles["Heading1"]))
    elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles["Normal"]))
    elements.append(Paragraph(TOOL_DISCLAIMER, ParagraphStyle(name="Disclaimer", parent=styles["Normal"], fontSize=9, textColor=colors.grey)))
    elements.append(Spacer(1, 20))
    if include_trend:
        try:
            from ..report import get_trend_data
            td = get_trend_data(7, tenant_id)
            if td.get("labels") and td.get("counts"):
                elements.append(Paragraph("API 风险趋势（近7天）", styles["Heading2"]))
                table_data = [["日期", "漏洞数"]] + list(zip(td["labels"], [str(c) for c in td["counts"]]))
                t = Table(table_data, colWidths=[80, 60])
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ]))
                elements.append(t)
                elements.append(Paragraph(f"合计: {td.get('total', 0)} 条", styles["Normal"]))
                elements.append(Spacer(1, 12))
        except Exception:
            pass

    rows = _collect_all_findings(tenant_id=tenant_id, api_name=api_name, severity=severity, tool=tool)
    if not rows:
        elements.append(Paragraph("No findings.", styles["Normal"]))
    else:
        table_data = [["成员", "项目", "等级", "工具", "标题", "描述"]]
        for r in rows[:100]:  # 限制行数避免 PDF 过大
            table_data.append([
                r.get("member_name", "")[:15],
                r.get("project", "")[:15],
                r.get("severity", ""),
                r.get("tool", ""),
                (r.get("title") or "")[:30],
                (r.get("description") or "")[:80],
            ])
        t = Table(table_data, colWidths=[60, 60, 40, 40, 100, 150])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 9),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
            ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
            ("FONTSIZE", (0, 1), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        elements.append(t)
        if len(rows) > 100:
            elements.append(Spacer(1, 10))
            elements.append(Paragraph(f"... and {len(rows) - 100} more findings.", styles["Normal"]))

    doc.build(elements)
    buf.seek(0)
    filename = f"api-security-report-{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return buf, filename
