"""
风险风控配套 - 统一文字配置与限制标注
避免过度承诺，明确套餐边界，合规表述
"""

# ---------------------------------------------------------------------------
# 对外展示统一表述（插件、后台、报告）
# ---------------------------------------------------------------------------

# 检测能力表述：覆盖 OWASP API Top10 常见漏洞类型
DETECTION_SCOPE = "覆盖 OWASP API Top10 常见漏洞类型"

# API 设计合规表述：基于 OpenAPI/Swagger 的轻量核查
COMPLIANCE_SCOPE = "基于 OpenAPI/Swagger 的 API 设计合规轻量核查"

# 工具检测免责声明（扫描结果、报告、弹窗）
TOOL_DISCLAIMER = "工具检测结果仅供参考，建议结合实际业务做安全评估"

# 合并的对外能力描述（用于插件/后台简介）
PUBLIC_CAPABILITY_DESC = f"{DETECTION_SCOPE}；{COMPLIANCE_SCOPE}"


# ---------------------------------------------------------------------------
# CI/CD 模板标注
# ---------------------------------------------------------------------------

# 建议测试环境先验证，再部署至生产环境
CICD_ENV_WARNING = "建议测试环境先验证，再部署至生产环境"


# ---------------------------------------------------------------------------
# 企业版套餐边界（无模糊表述）
# ---------------------------------------------------------------------------

# 同一企业仅限 1 个套餐（基础/进阶/旗舰）
PLAN_SINGLE_LIMIT = "同一企业仅限购买 1 个套餐（基础版/进阶版/旗舰版不可叠加）"

# 无限版套餐边界
PLAN_UNLIMITED_BOUNDARY = "无限版套餐含 10 人内，超员按 200 元/人/年扩容"

# 套餐边界说明（按套餐）
PLAN_BOUNDARIES = {
    "basic": "基础版：同一企业仅限 1 个套餐",
    "advanced": "进阶版：同一企业仅限 1 个套餐",
    "flagship": "旗舰版：同一企业仅限 1 个套餐",
    "unlimited": "无限版：含 10 人内，超员按 200 元/人/年扩容；同一企业仅限 1 个套餐",
}


def get_plan_boundary(plan_id: str) -> str:
    """获取套餐边界说明"""
    return PLAN_BOUNDARIES.get(plan_id, PLAN_SINGLE_LIMIT)


def get_all_disclaimers() -> dict:
    """获取全部风控文案（供 API/前端使用）"""
    return {
        "detection_scope": DETECTION_SCOPE,
        "compliance_scope": COMPLIANCE_SCOPE,
        "tool_disclaimer": TOOL_DISCLAIMER,
        "public_capability": PUBLIC_CAPABILITY_DESC,
        "cicd_env_warning": CICD_ENV_WARNING,
        "plan_single_limit": PLAN_SINGLE_LIMIT,
        "plan_unlimited_boundary": PLAN_UNLIMITED_BOUNDARY,
        "plan_boundaries": PLAN_BOUNDARIES,
    }
