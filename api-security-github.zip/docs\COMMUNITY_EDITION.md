# API Security 社区版与商业版功能边界

## 版本说明

| 版本 | 环境变量 | 说明 |
|------|----------|------|
| **社区版** | `API_SECURITY_EDITION=community`（默认） | 功能精简，无计费、无团队限制，开源可贡献 |
| **商业版** | `API_SECURITY_EDITION=enterprise` | 完整功能，套餐计费、团队规模管控、SSO、多租户 |

## 功能对比

| 功能 | 社区版 | 商业版 |
|------|--------|--------|
| CLI 扫描（OpenSCA + Semgrep + afrog） | ✅ | ✅ |
| OpenAPI 解析与合规核查 | ✅ | ✅ |
| 管理后台（统计、漏洞筛选、导出） | ✅ | ✅ |
| 成员管理 | ✅ 无人数限制 | ✅ 按套餐限制 |
| API 调用次数 | ✅ 无限制 | 按套餐（10万~无限/月） |
| 套餐购买与计费 | ❌ | ✅ |
| 多租户与 SSO | ❌ | ✅ |
| 租户管理（超级管理员） | ❌ | ✅ |
| Webhook、审计、数据清理 | ✅ | ✅ |
| GitHub Actions 集成 | ✅ | ✅ |
| 自研规则、API 变更检测 | ✅ | ✅ |

## 社区版安装

```bash
pip install -r requirements-community.txt
# 或
pip install -r requirements.txt
```

默认即为社区版，无需额外配置。

## 商业版启用

```bash
export API_SECURITY_EDITION=enterprise
python run_admin.py --port 35555
```

## 打包与发布

- **社区版**：可独立发布至 PyPI，包名建议 `api-security` 或 `api-security-community`
- **商业版**：私有或商业渠道分发，包名 `api-security-enterprise`

同一代码库通过环境变量切换版本，便于维护与升级。
