"""
管理后台启动脚本
用法: python -m api_security.admin.run
"""

import argparse

from .app import run

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()
    run(host=args.host, port=args.port, debug=args.debug)
