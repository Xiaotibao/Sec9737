# API Security 示例项目

用于演示 API 安全扫描的示例 OpenAPI 项目。

## 结构

```
sample-api/
├── openapi.yaml    # OpenAPI 3.0 规范
├── main.py         # 简易 Flask API（可选运行）
└── README.md
```

## 快速扫描

```bash
# 从项目根目录
cd examples/sample-api

# 扫描当前目录（自动识别 openapi.yaml）
python -m api_security.cli scan . --output result.json

# 指定 OpenAPI 文件
python -m api_security.cli scan . --openapi openapi.yaml --output result.json
```

## 运行示例 API（可选）

```bash
pip install flask
python main.py
# 访问 http://127.0.0.1:5000/docs 查看 Swagger UI
```

## 预期发现

扫描可能发现：

- 缺失 `security` 定义的接口
- 响应中包含敏感字段（如 `password`）
- 缺失 401/403 错误定义
- 依赖漏洞（若使用 OpenSCA）
- 代码中的潜在注入点（若使用 Semgrep）
