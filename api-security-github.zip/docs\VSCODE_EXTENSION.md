# VS Code 插件使用文档

## 概述

API Security VS Code 扩展在 Cursor 之外支持 VS Code，与核心逻辑（`api_security`）共用，实现：

- 扫描、解析、查看结果
- 问题面板与编辑器内嵌诊断
- 读取 `api_security.yaml` 配置

## 安装

### 从源码安装（开发模式）

1. 确保已安装 Node.js 18+ 和 npm
2. 进入扩展目录并安装依赖：

   ```bash
   cd vscode-extension
   npm install
   npm run compile
   ```

3. 在 VS Code 中按 F5 启动扩展开发主机，或使用「从文件夹安装」加载 `vscode-extension` 目录

### 打包为 VSIX

```bash
cd vscode-extension
npm install
npm run package
```

生成的 `api-security-0.1.0.vsix` 可通过「扩展 → 从 VSIX 安装」安装。

## 前置条件

- **Python 3.10+**
- **api_security**：
  - 若工作区为本项目（含 `src/api_security`），扩展会自动使用
  - 否则需在项目根目录执行 `pip install -e .` 安装

## 命令

| 命令 | 说明 |
|------|------|
| API Security: 执行扫描 | 对当前工作区执行 API 安全扫描 |
| API Security: 解析 OpenAPI | 选择 OpenAPI 文件并解析 |
| API Security: 查看扫描结果 | 在 Webview 中查看最近扫描结果 |
| API Security: 清除诊断 | 清除问题面板中的 API Security 诊断 |

## 配置

### VS Code 设置

- `apiSecurity.pythonPath`：Python 解释器路径（默认 `python`）
- `apiSecurity.target`：扫描目标路径（默认 `.`）
- `apiSecurity.openapiPath`：OpenAPI 文档路径（默认自动识别）
- `apiSecurity.afrogUrl`：afrog 动态扫描 URL（默认 `null`）
- `apiSecurity.incremental`：增量模式，仅扫描 git 变更文件（默认 `false`）
- `apiSecurity.baseRef`：增量基准引用，如 `origin/main`（默认 `null`，自动检测）

### api_security.yaml

在工作区根目录或 `config/` 下创建 `api_security.yaml`：

```yaml
scan:
  target: "."
  openapi: null
  afrog_url: null
  incremental: false
  base_ref: null
```

扩展会优先读取该配置。启用 `incremental` 时，若存在上次扫描结果，会自动合并展示。

## 结果展示

- **问题面板**：有 `location` 的漏洞会显示在对应文件的诊断中
- **Webview**：执行「查看扫描结果」可在侧边栏查看表格形式结果
- **输出面板**：扫描日志输出到「API Security」通道

## 发布到 VS Code Marketplace

1. 安装 vsce：`npm install -g @vscode/vsce`
2. 登录：`vsce login <publisher>`
3. 发布：`vsce publish`

需先在 [Visual Studio Marketplace](https://marketplace.visualstudio.com/) 注册 Publisher。

## 验收标准

- [x] VS Code 用户可安装插件
- [x] 可执行扫描并查看结果
- [x] 问题面板展示诊断
- [x] 支持 api_security.yaml 配置
