"""
LLM 客户端 - OpenAI 兼容 API
"""

import json
from typing import Optional

import requests
from loguru import logger

from .config import get_ai_repair_config


def call_llm(
    user_prompt: str,
    system_prompt: Optional[str] = None,
) -> Optional[str]:
    """
    调用 LLM API 生成文本
    返回 None 表示失败或未配置
    """
    cfg = get_ai_repair_config()
    if not cfg.get("api_key"):
        return None

    url = cfg.get("llm_endpoint", "").rstrip("/")
    if not url.endswith("/chat/completions"):
        url = url.rstrip("/") + "/chat/completions"

    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type": "application/json",
    }
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": user_prompt})

    payload = {
        "model": cfg.get("model", "gpt-4o-mini"),
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 1024,
    }

    try:
        r = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=cfg.get("timeout", 30),
        )
        r.raise_for_status()
        data = r.json()
        content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        return content.strip() if content else None
    except requests.RequestException as e:
        logger.warning(f"LLM 调用失败: {e}")
        return None
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        logger.warning(f"LLM 响应解析失败: {e}")
        return None
