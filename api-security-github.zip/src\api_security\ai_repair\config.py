"""
AI 修复配置 - LLM 端点、API Key
支持环境变量与配置文件
"""

import os
from pathlib import Path
from typing import Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATHS = [
    PROJECT_ROOT / "config" / "api_security.yaml",
    PROJECT_ROOT / "api_security.yaml",
]


def _load_yaml_config() -> dict:
    for p in CONFIG_PATHS:
        if p.exists():
            try:
                with open(p, encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except Exception:
                pass
    return {}


def get_ai_repair_config() -> dict:
    """
    获取 AI 修复配置
    优先级：环境变量 > 配置文件
    """
    cfg = _load_yaml_config() if YAML_AVAILABLE else {}
    ai_cfg = cfg.get("ai_repair") or cfg.get("ai") or {}

    return {
        "enabled": ai_cfg.get("enabled", True),
        "llm_endpoint": os.environ.get("OPENAI_API_BASE") or ai_cfg.get("llm_endpoint") or "https://api.openai.com/v1/chat/completions",
        "api_key": os.environ.get("OPENAI_API_KEY") or ai_cfg.get("api_key") or "",
        "model": ai_cfg.get("model") or "gpt-4o-mini",
        "timeout": ai_cfg.get("timeout", 30),
    }


def is_llm_configured() -> bool:
    """是否已配置 LLM（有 API Key）"""
    c = get_ai_repair_config()
    return bool(c.get("api_key") and c.get("enabled"))
