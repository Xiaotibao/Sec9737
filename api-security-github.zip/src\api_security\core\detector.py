"""
API 漏洞检测核心
集成 OpenSCA（依赖漏洞）、Semgrep（静态分析）、afrog（动态扫描）
覆盖常见 API 安全风险：注入、未授权访问、已知 CVE 等
对外表述：覆盖常见 API 安全风险
"""

import subprocess
import shutil
from pathlib import Path
from typing import Optional, Callable
from dataclasses import dataclass, field

from loguru import logger


@dataclass
class Finding:
    """单条检测发现"""
    tool: str  # opensca | semgrep | afrog | openapi_compliance
    severity: str  # critical | high | medium | low | info
    title: str
    description: str
    location: Optional[str] = None
    cve_id: Optional[str] = None
    rule_id: Optional[str] = None
    owasp_category: Optional[str] = None  # API1:2023 ~ API10:2023


@dataclass
class DetectionResult:
    """检测结果汇总"""
    success: bool
    findings: list[Finding] = field(default_factory=list)
    tools_run: list[str] = field(default_factory=list)
    tools_skipped: list[str] = field(default_factory=list)
    error: Optional[str] = None


class APIVulnerabilityDetector:
    """
    API 漏洞检测器
    按优先级调用 OpenSCA、Semgrep、afrog
    """

    def __init__(
        self,
        target_path: str | Path,
        openapi_path: Optional[str | Path] = None,
        enable_opensca: bool = True,
        enable_semgrep: bool = True,
        enable_afrog: bool = True,
        afrog_url: Optional[str] = None,
        include_paths: Optional[list[str | Path]] = None,
        skip_opensca_incremental: bool = True,
    ):
        """
        Args:
            target_path: 扫描目标路径（代码/项目目录）
            openapi_path: OpenAPI 文档路径，可选
            enable_opensca: 是否启用 OpenSCA
            enable_semgrep: 是否启用 Semgrep
            enable_afrog: 是否启用 afrog（需提供 URL）
            afrog_url: afrog 扫描的 API 基础 URL
            include_paths: 增量扫描时仅扫描这些路径（Semgrep）
            skip_opensca_incremental: 增量模式下是否跳过 OpenSCA（依赖可缓存）
        """
        self.target_path = Path(target_path)
        self.openapi_path = Path(openapi_path) if openapi_path else None
        self.enable_opensca = enable_opensca
        self.enable_semgrep = enable_semgrep
        self.enable_afrog = enable_afrog
        self.afrog_url = afrog_url
        self.include_paths = [Path(p) for p in (include_paths or [])]
        self.skip_opensca_incremental = skip_opensca_incremental

    def run(self, progress_callback: Optional[Callable[[str, int, str], None]] = None) -> DetectionResult:
        """执行完整检测流程"""
        def _report(stage: str, progress: int, message: str):
            if progress_callback:
                progress_callback(stage, progress, message)

        findings: list[Finding] = []
        tools_run: list[str] = []
        tools_skipped: list[str] = []

        # 高优先级：Semgrep（静态分析，增量时仅扫变更文件）
        _report("semgrep", 28, "Semgrep 静态分析...")
        if self.enable_semgrep:
            try:
                semgrep_findings = self._run_semgrep()
                findings.extend(semgrep_findings)
                tools_run.append("semgrep")
            except Exception as e:
                logger.warning(f"Semgrep 执行失败: {e}")
                tools_skipped.append("semgrep")
        else:
            tools_skipped.append("semgrep")
        _report("semgrep", 45, "Semgrep 完成")

        # 自研规则（与 Semgrep 互补）
        _report("native_rules", 46, "自研规则扫描...")
        try:
            from ..native_rules import NativeRuleEngine
            engine = NativeRuleEngine()
            scan_targets = self.include_paths if self.include_paths else None
            native_findings = engine.scan_path(self.target_path, include_paths=scan_targets)
            findings.extend(native_findings)
            if native_findings:
                tools_run.append("native_rules")
        except Exception as e:
            logger.warning(f"自研规则执行失败: {e}")
            tools_skipped.append("native_rules")
        _report("native_rules", 47, "自研规则完成")

        # 高优先级：OpenSCA（依赖漏洞，增量模式可跳过以加速）
        _report("opensca", 48, "OpenSCA 依赖扫描...")
        if self.enable_opensca and not (self.include_paths and self.skip_opensca_incremental):
            try:
                opensca_findings = self._run_opensca()
                findings.extend(opensca_findings)
                tools_run.append("opensca")
            except Exception as e:
                logger.warning(f"OpenSCA 执行失败: {e}")
                tools_skipped.append("opensca")
        else:
            tools_skipped.append("opensca")
        _report("opensca", 65, "OpenSCA 完成")

        # 中优先级：afrog（动态扫描，需运行中的 API）
        _report("afrog", 68, "afrog 动态扫描...")
        if self.enable_afrog and self.afrog_url:
            ok, msg = self._check_afrog_target_reachable()
            if not ok:
                logger.warning(f"afrog 目标不可达: {msg}，跳过动态扫描")
                tools_skipped.append(f"afrog (目标不可达: {msg})")
            else:
                try:
                    afrog_findings = self._run_afrog()
                    findings.extend(afrog_findings)
                    tools_run.append("afrog")
                except Exception as e:
                    logger.warning(f"afrog 执行失败: {e}")
                    tools_skipped.append("afrog")
        elif self.enable_afrog:
            tools_skipped.append("afrog (未提供 URL)")
        _report("afrog", 90, "afrog 完成")

        return DetectionResult(
            success=True,
            findings=findings,
            tools_run=tools_run,
            tools_skipped=tools_skipped,
        )

    def _run_semgrep(self) -> list[Finding]:
        """调用 Semgrep 进行 API 相关静态分析，优先使用 OWASP API Top 10 规则"""
        findings: list[Finding] = []
        semgrep_cmd = shutil.which("semgrep")
        base_cmd = [semgrep_cmd or "python", "-m" if not semgrep_cmd else None, "semgrep"][:2]
        if semgrep_cmd:
            base_cmd = [semgrep_cmd]
        else:
            base_cmd = ["python", "-m", "semgrep"]

        # 优先使用 OWASP API Top 10 规则，与 auto 合并
        owasp_rules_path = self._get_owasp_rules_path()
        scan_targets = [str(p) for p in self.include_paths] if self.include_paths else [str(self.target_path)]
        if owasp_rules_path.exists():
            cmd = base_cmd + ["scan", "--config", str(owasp_rules_path), "--config", "auto"] + scan_targets + ["--json"]
        else:
            cmd = base_cmd + ["scan", "--config", "auto"] + scan_targets + ["--json"]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(self.target_path.parent) if self.target_path.is_file() else str(self.target_path),
            )
            if result.returncode in (0, 1):  # 1 表示有发现
                import json
                from ..owasp.mapping import get_owasp_category_from_rule_id, get_owasp_category_from_metadata
                try:
                    data = json.loads(result.stdout or result.stderr or "{}")
                    for r in data.get("results", []):
                        rule_id = r.get("check_id")
                        extra = r.get("extra", {})
                        metadata = extra.get("metadata", {})
                        owasp_cat = get_owasp_category_from_metadata(metadata) or get_owasp_category_from_rule_id(rule_id)
                        p = r.get("path", "")
                        start = r.get("start") or {}
                        if isinstance(start, dict) and start.get("line"):
                            loc = f"{p}:{start.get('line', 1)}:{start.get('col', 0)}"
                        else:
                            loc = p
                        findings.append(Finding(
                            tool="semgrep",
                            severity=extra.get("severity", "medium").lower(),
                            title=rule_id or "rule",
                            description=extra.get("message", ""),
                            location=loc,
                            rule_id=rule_id,
                            owasp_category=owasp_cat,
                        ))
                except json.JSONDecodeError:
                    pass
        except subprocess.TimeoutExpired:
            logger.warning("Semgrep 超时")
        except FileNotFoundError:
            logger.warning("未找到 semgrep，请安装: pip install semgrep")
        return findings

    def _get_owasp_rules_path(self) -> Path:
        """获取 OWASP API Top 10 规则目录路径"""
        root = Path(__file__).resolve().parents[2]
        return root / "config" / "owasp_api_top10"

    def _run_opensca(self) -> list[Finding]:
        """调用 OpenSCA 进行依赖漏洞扫描"""
        findings: list[Finding] = []
        opensca_cmd = shutil.which("opensca") or shutil.which("OpenSCA")
        if not opensca_cmd:
            logger.warning("未找到 OpenSCA，请安装 OpenSCA-cli")
            return findings

        try:
            result = subprocess.run(
                [opensca_cmd, "scan", "-path", str(self.target_path), "-out", "json"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0 and result.stdout:
                import json
                data = json.loads(result.stdout)
                for vuln in data.get("vulnerabilities", []) or data.get("data", []):
                    v = vuln if isinstance(vuln, dict) else {}
                    findings.append(Finding(
                        tool="opensca",
                        severity=v.get("severity", "medium").lower(),
                        title=v.get("title", v.get("vuln_id", "CVE")),
                        description=v.get("description", ""),
                        cve_id=v.get("vuln_id") or v.get("cve_id"),
                    ))
        except subprocess.TimeoutExpired:
            logger.warning("OpenSCA 超时")
        except Exception as e:
            logger.warning(f"OpenSCA 执行异常: {e}")
        return findings

    def _check_afrog_target_reachable(self) -> tuple[bool, str]:
        """检测 afrog_url（待扫描的 API）是否可达，返回 (可达, 错误信息)"""
        url = (self.afrog_url or "").strip()
        if not url:
            return False, "未配置 afrog_url"
        if not url.startswith(("http://", "https://")):
            return False, "afrog_url 须以 http:// 或 https:// 开头"
        try:
            import urllib.request
            req = urllib.request.Request(url, method="GET")
            req.add_header("User-Agent", "API-Security-HealthCheck/1.0")
            urllib.request.urlopen(req, timeout=5)
            return True, ""
        except urllib.error.URLError as e:
            return False, str(e.reason) if getattr(e, "reason", None) else str(e)
        except Exception as e:
            return False, str(e)

    def _run_afrog(self) -> list[Finding]:
        """调用 afrog 进行 API 动态漏洞扫描"""
        findings: list[Finding] = []
        afrog_cmd = shutil.which("afrog")
        if not afrog_cmd:
            logger.warning("未找到 afrog，请安装 afrog")
            return findings

        try:
            result = subprocess.run(
                [afrog_cmd, "-t", self.afrog_url or "", "-json"],
                capture_output=True,
                text=True,
                timeout=600,
            )
            if result.stdout:
                import json
                try:
                    data = json.loads(result.stdout)
                    for r in data.get("results", []) or (data if isinstance(data, list) else []):
                        item = r if isinstance(r, dict) else {}
                        findings.append(Finding(
                            tool="afrog",
                            severity=item.get("severity", "medium").lower(),
                            title=item.get("name", item.get("id", "finding")),
                            description=item.get("description", ""),
                            location=item.get("url"),
                        ))
                except json.JSONDecodeError:
                    pass
        except subprocess.TimeoutExpired:
            logger.warning("afrog 超时")
        except Exception as e:
            logger.warning(f"afrog 执行异常: {e}")
        return findings


def run_api_scan(
    target: str | Path,
    openapi: Optional[str | Path] = None,
    afrog_url: Optional[str] = None,
) -> DetectionResult:
    """
    可直接调用的 API 扫描函数

    Args:
        target: 扫描目标路径
        openapi: OpenAPI 文档路径（可选）
        afrog_url: afrog 扫描的 API URL（可选）

    Returns:
        DetectionResult
    """
    detector = APIVulnerabilityDetector(
        target_path=target,
        openapi_path=openapi,
        afrog_url=afrog_url,
    )
    return detector.run()
