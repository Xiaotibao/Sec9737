"""
计费对接接口
支持套餐购买、升级、扩容包计费
"""

from typing import Any, Optional
from dataclasses import dataclass

from .plans import (
    PLAN_BASIC,
    PLAN_ADVANCED,
    PLAN_FLAGSHIP,
    PLAN_UNLIMITED,
    get_plan,
    EXPANSION_PRICE_PER_PERSON,
)


@dataclass
class BillingQuote:
    """计费报价"""
    plan_id: str
    plan_name: str
    price_yearly: int
    expansion_count: int
    expansion_fee: int
    total: int


class BillingAdapter:
    """
    计费对接适配器
    对接支付渠道，实现套餐购买与升级
    """

    def get_plan_price(self, plan_id: str) -> int:
        """获取套餐年费（元）"""
        p = get_plan(plan_id)
        return p.price_yearly if p else 0

    def quote(
        self,
        plan_id: str,
        expansion_count: int = 0,
    ) -> BillingQuote:
        """
        获取报价
        Args:
            plan_id: 套餐
            expansion_count: 扩容人数（仅无限版有效）
        """
        p = get_plan(plan_id)
        if not p:
            return BillingQuote("", "", 0, 0, 0, 0)
        exp_fee = expansion_count * p.expansion_price if plan_id == PLAN_UNLIMITED else 0
        return BillingQuote(
            plan_id=plan_id,
            plan_name=p.name,
            price_yearly=p.price_yearly,
            expansion_count=expansion_count,
            expansion_fee=exp_fee,
            total=p.price_yearly + exp_fee,
        )

    def create_order(
        self,
        enterprise_id: str,
        plan_id: str,
        expansion_count: int = 0,
    ) -> dict:
        """
        创建订单（预留对接支付）
        Returns:
            { "order_id", "amount", "pay_url", ... }
        """
        quote = self.quote(plan_id, expansion_count)
        return {
            "order_id": "",
            "plan_id": plan_id,
            "amount": quote.total,
            "pay_url": "",
            "message": "计费对接待接入支付渠道",
        }

    def verify_payment(self, order_id: str) -> tuple[bool, str]:
        """
        校验支付结果（预留）
        Returns:
            (success, message)
        """
        return False, "支付校验待对接"
