"""
增量结果与历史结果合并
按 location + rule_id 去重，保留未变更文件的历史发现
"""

import json
from pathlib import Path
from typing import Optional

from loguru import logger

from ..core.detector import Finding, DetectionResult


def _finding_key(f: dict | Finding) -> str:
    """生成去重键：location + rule_id"""
    loc = (f.get("location") if isinstance(f, dict) else f.location) or ""
    rid = (f.get("rule_id") if isinstance(f, dict) else f.rule_id) or ""
    return f"{loc}::{rid}"


def _location_in_changed(location: Optional[str], changed_paths: list[Path], cwd: Path) -> bool:
    """判断 location 是否属于变更文件"""
    if not location or not changed_paths:
        return False
    loc_part = location.split(":")[0].strip()
    if not loc_part:
        return False
    loc_path = (cwd / loc_part).resolve()
    for cp in changed_paths:
        try:
            cp_res = cp.resolve()
            if loc_path == cp_res:
                return True
            if str(loc_path).startswith(str(cp_res) + str(Path("/"))) or str(cp_res) in str(loc_path):
                return True
        except Exception:
            pass
    return False


def load_previous_findings(path: str | Path) -> list[dict]:
    """从 JSON 加载上次扫描的 findings"""
    path = Path(path)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        findings = data.get("detection", {}).get("findings", [])
        return findings if isinstance(findings, list) else []
    except Exception as e:
        logger.warning(f"加载历史结果失败 {path}: {e}")
        return []


def merge_incremental_with_previous(
    incremental_findings: list[Finding],
    previous_result_path: Optional[str | Path],
    changed_paths: list[Path],
    target_path: Path,
) -> list[Finding]:
    """
    合并增量结果与历史结果

    - 历史结果中，属于变更文件的发现会被增量结果覆盖
    - 历史结果中，未变更文件的发现保留
    - 增量结果全部加入
    - 按 location + rule_id 去重

    Args:
        incremental_findings: 本次增量扫描的发现
        previous_result_path: 上次扫描结果 JSON 路径
        changed_paths: 本次变更的文件路径列表
        target_path: 项目根路径，用于解析 location 相对路径

    Returns:
        合并后的 Finding 列表
    """
    seen: set[str] = set()
    merged: list[Finding] = []

    # 1. 从历史结果中保留「未变更文件」的发现
    if previous_result_path:
        prev = load_previous_findings(previous_result_path)
        cwd = target_path.parent if target_path.is_file() else target_path
        for p in prev:
            loc = p.get("location")
            if _location_in_changed(loc, changed_paths, cwd):
                continue  # 变更文件，用增量结果覆盖
            key = _finding_key(p)
            if key in seen:
                continue
            seen.add(key)
            merged.append(Finding(
                tool=p.get("tool", ""),
                severity=p.get("severity", "info"),
                title=p.get("title", ""),
                description=p.get("description", ""),
                location=loc,
                cve_id=p.get("cve_id"),
                rule_id=p.get("rule_id"),
                owasp_category=p.get("owasp_category"),
            ))

    # 2. 加入增量结果（覆盖变更文件的发现）
    for f in incremental_findings:
        key = _finding_key(f)
        if key in seen:
            continue
        seen.add(key)
        merged.append(f)

    return merged
