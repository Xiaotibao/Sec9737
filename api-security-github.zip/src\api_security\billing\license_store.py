"""
企业套餐许可证存储
同一企业仅可购买 1 个基础/进阶/旗舰，无限可扩容
"""

import json
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
LICENSE_FILE = DATA_DIR / "license.json"


def _load() -> dict:
    """{ enterprise_id: { plan_id, expansion_count, ... } }"""
    if not LICENSE_FILE.exists():
        return {}
    try:
        return json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: dict):
    DATA_DIR.mkdir(exist_ok=True)
    LICENSE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get_enterprise_plan(enterprise_id: str) -> Optional[str]:
    """获取企业当前套餐"""
    return _load().get(enterprise_id, {}).get("plan_id")


def get_expansion_count(enterprise_id: str) -> int:
    """获取企业已购扩容人数"""
    return _load().get(enterprise_id, {}).get("expansion_count", 0)


def set_license(enterprise_id: str, plan_id: str, expansion_count: int = 0) -> bool:
    """设置企业许可证"""
    data = _load()
    data[enterprise_id] = {
        "plan_id": plan_id,
        "expansion_count": max(0, expansion_count),
    }
    _save(data)
    return True
