"""
SSO 单点登录 - OIDC 集成
支持企业 IdP 对接，按租户配置 issuer/client_id/secret
"""

from flask import Blueprint, request, redirect, url_for, session, jsonify
from urllib.parse import urlencode

from ..tenant import get_tenant, get_tenant_id_from_request

sso_bp = Blueprint("sso", __name__, url_prefix="/sso")


def _oidc_available(tenant_id: str) -> bool:
    """租户是否已配置 OIDC"""
    t = get_tenant(tenant_id)
    return bool(t and t.sso_issuer and t.sso_client_id and t.sso_client_secret)


@sso_bp.route("/login", methods=["GET"])
def login():
    """
    发起 SSO 登录
    Query: tenant=xxx, redirect_uri=xxx（可选）
    若租户未配置 SSO，重定向到管理后台并提示
    """
    tenant_id = request.args.get("tenant") or get_tenant_id_from_request(request) or "default"
    redirect_uri = request.args.get("redirect_uri") or "/admin"
    session["sso_tenant_id"] = tenant_id
    session["sso_redirect_uri"] = redirect_uri

    if not _oidc_available(tenant_id):
        return redirect(f"{redirect_uri}?sso=unconfigured&tenant={tenant_id}")

    try:
        from authlib.integrations.requests_client import OAuth2Session
    except ImportError:
        return redirect(f"{redirect_uri}?sso=no_authlib&tenant={tenant_id}")

    t = get_tenant(tenant_id)
    issuer = (t.sso_issuer or "").rstrip("/")
    client_id = t.sso_client_id or ""
    redirect_url = request.url_root.rstrip("/") + "/sso/callback"
    scope = "openid email profile"

    # OIDC Discovery
    try:
        disco_url = f"{issuer}/.well-known/openid-configuration"
        import requests
        r = requests.get(disco_url, timeout=5)
        disco = r.json() if r.ok else {}
    except Exception:
        disco = {}

    auth_endpoint = disco.get("authorization_endpoint") or f"{issuer}/authorize"
    auth_url = (
        f"{auth_endpoint}?"
        + urlencode({
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": redirect_url,
            "scope": scope,
            "state": tenant_id,
        })
    )
    return redirect(auth_url)


@sso_bp.route("/callback", methods=["GET"])
def callback():
    """
    OIDC 回调
    用 code 换 token，解析 id_token 获取用户信息，写入 session
    """
    redirect_uri = session.get("sso_redirect_uri", "/admin")
    tenant_id = session.get("sso_tenant_id", "default")
    code = request.args.get("code")
    state = request.args.get("state")
    error = request.args.get("error")

    if error:
        return redirect(f"{redirect_uri}?sso_error={error}&tenant={tenant_id}")

    if not code:
        return redirect(f"{redirect_uri}?sso=no_code&tenant={tenant_id}")

    if not _oidc_available(tenant_id):
        return redirect(f"{redirect_uri}?sso=unconfigured&tenant={tenant_id}")

    try:
        from authlib.integrations.requests_client import OAuth2Session
        import requests
    except ImportError:
        return redirect(f"{redirect_uri}?sso=no_authlib&tenant={tenant_id}")

    t = get_tenant(tenant_id)
    issuer = (t.sso_issuer or "").rstrip("/")
    client_id = t.sso_client_id or ""
    client_secret = t.sso_client_secret or ""
    token_url = f"{issuer}/token"
    redirect_url = request.url_root.rstrip("/") + "/sso/callback"

    try:
        disco_url = f"{issuer}/.well-known/openid-configuration"
        r = requests.get(disco_url, timeout=5)
        disco = r.json() if r.ok else {}
        token_url = disco.get("token_endpoint") or token_url
    except Exception:
        pass

    client = OAuth2Session(client_id, client_secret=client_secret)
    token = client.fetch_token(
        token_url,
        authorization_response=request.url,
        redirect_uri=redirect_url,
    )

    id_token = token.get("id_token")
    user_email = ""
    if id_token:
        try:
            from authlib.jose import jwt
            payload = jwt.decode(id_token, key=client_secret or client_id)
            user_email = payload.get("email") or payload.get("preferred_username") or payload.get("sub", "")
        except Exception:
            try:
                import base64
                import json
                parts = id_token.split(".")
                if len(parts) >= 2:
                    pad = parts[1] + "=" * (4 - len(parts[1]) % 4)
                    payload = json.loads(base64.urlsafe_b64decode(pad))
                    user_email = payload.get("email") or payload.get("preferred_username") or payload.get("sub", "")
            except Exception:
                pass

    session["sso_user_email"] = user_email
    session["sso_tenant_id"] = tenant_id
    session["sso_logged_in"] = True
    return redirect(redirect_uri)


@sso_bp.route("/logout", methods=["GET", "POST"])
def logout():
    """清除 SSO session"""
    for k in list(session.keys()):
        if k.startswith("sso_"):
            session.pop(k, None)
    redirect_uri = request.args.get("redirect_uri", "/admin")
    return redirect(redirect_uri)


@sso_bp.route("/status", methods=["GET"])
def status():
    """当前 SSO 登录状态"""
    return jsonify({
        "logged_in": session.get("sso_logged_in", False),
        "tenant_id": session.get("sso_tenant_id"),
        "user_email": session.get("sso_user_email"),
    })
