# API 变更影响分析

## 概述

对比新旧 OpenAPI 文档，自动识别新增/删除/修改的接口与字段，并标记高风险变更。

## 使用方式

### 管理后台

1. 进入「API 变更」Tab
2. 粘贴或上传新 OpenAPI 文档（JSON/YAML）
3. 勾选「保存为基准」可将当前版本作为下次对比的基准
4. 点击「执行对比」生成报告

**首次使用**：需先上传当前 OpenAPI 并保存为基准，之后每次上传新版本即可自动对比。

### API

```
POST /api/admin/api-changes/compare
Content-Type: application/json

{
  "openapi_new": { ... },      // 或 JSON 字符串
  "openapi_old": null,          // null 时使用已保存基准
  "project": "项目名",
  "save_as_baseline": true
}
```

**响应**：含 `diff`、`findings`、`summary`、`has_critical`、`report_id`

## 高风险变更类型

| 级别 | 变更类型 | 说明 |
|------|----------|------|
| Critical | 认证被移除 | 接口的 security 定义被移除 |
| High | 401/403 定义被移除 | 响应中删除未授权错误定义 |
| High | 响应新增敏感字段 | 如 password、token 等 |
| Medium | 接口已删除 | 可能影响调用方 |
| Low | 新增接口 | 需确认认证与敏感字段 |
| Low | 接口标记废弃 | 需制定迁移计划 |

## 告警

当存在 **Critical** 级别变更时，会触发 Webhook：
- 事件类型：`api_change_critical`
- 可在 Webhook 配置页勾选「API 变更 Critical」订阅

## 存储

- 基准 OpenAPI：`data/api_change/openapi_baseline.json`
- 变更报告：`data/api_change/reports/api_change_YYYYMMDD_HHMMSS.json`
