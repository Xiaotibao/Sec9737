"""
自研规则格式定义
支持 YAML/JSON，基于正则匹配
"""

from typing import Optional
from dataclasses import dataclass, field


@dataclass
class NativeRule:
    """单条规则"""
    id: str
    pattern: str  # 正则表达式
    message: str
    severity: str  # critical | high | medium | low | info
    languages: list[str]  # python, javascript, typescript, java, go, generic
    owasp_category: Optional[str] = None
    cwe: Optional[str] = None
    enabled: bool = True
    version: str = "1.0"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "pattern": self.pattern,
            "message": self.message,
            "severity": self.severity,
            "languages": self.languages,
            "owasp_category": self.owasp_category,
            "cwe": self.cwe,
            "enabled": self.enabled,
            "version": self.version,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "NativeRule":
        return cls(
            id=d.get("id", ""),
            pattern=d.get("pattern", ""),
            message=d.get("message", ""),
            severity=d.get("severity", "medium"),
            languages=d.get("languages", ["generic"]),
            owasp_category=d.get("owasp_category"),
            cwe=d.get("cwe"),
            enabled=d.get("enabled", True),
            version=d.get("version", "1.0"),
        )
