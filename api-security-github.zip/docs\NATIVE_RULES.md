# 自研规则库

## 概述

自研规则库独立于 Semgrep/afrog，基于正则匹配扫描代码，覆盖 IDOR、越权、敏感信息泄露等 API 安全风险，与现有工具互补。

## 规则格式

规则存放在 `config/native_rules/*.yaml`，格式示例：

```yaml
rules:
  - id: native-xxx
    pattern: "正则表达式"
    message: "发现描述"
    severity: critical | high | medium | low | info
    languages: [python, javascript, typescript, java, go, generic]
    owasp_category: "API1:2023"  # 可选
    enabled: true
```

## 规则列表（24 条）

| 类别 | 规则 ID | 说明 |
|------|---------|------|
| IDOR | native-idor-req-params | 请求参数中的 ID 需校验归属 |
| IDOR | native-idor-path-param | 路径参数需校验权限 |
| IDOR | native-idor-django-pk | Django get_object_or_404 使用请求 pk |
| IDOR | native-idor-flask-request | Flask 从请求获取 ID |
| 认证 | native-hardcoded-secret | 硬编码凭证 |
| 认证 | native-jwt-weak-secret | JWT 密钥过短 |
| 认证 | native-skip-auth | 跳过认证配置 |
| 批量分配 | native-object-assign-body | Object.assign(req.body) |
| 批量分配 | native-spread-req-body | 展开请求体 |
| 批量分配 | native-update-whole-body | 直接使用请求体更新 |
| 授权 | native-admin-route | 管理类接口 |
| 授权 | native-flask-route-no-auth | Flask 路由可能缺认证 |
| 配置 | native-cors-wildcard | CORS 允许 * |
| 配置 | native-debug-enabled | debug 模式 |
| 注入 | native-sql-fstring | f-string 拼接 SQL |
| 注入 | native-sql-concat | 字符串拼接 SQL |
| 注入 | native-os-system | os.system |
| 注入 | native-eval | eval/Function |
| 注入 | native-nosql-where | NoSQL $where |
| 注入 | native-raw-query | 原始 SQL 查询 |
| 日志 | native-password-in-log | 密码写入日志 |
| 日志 | native-user-input-in-log | 用户输入写入日志 |
| 泄露 | native-stack-trace | 堆栈信息暴露 |
| 泄露 | native-inner-exception | 原始异常抛出 |

## 规则管理

- **管理后台**：「自研规则」Tab 中可启用/禁用单条规则
- **存储**：启用状态保存在 `data/native_rules_config.json`
- **自定义规则**：在 `config/native_rules/` 下新增 YAML 文件即可

## 与扫描集成

扫描流程中自动执行自研规则，结果与 Semgrep、OpenSCA、afrog 合并展示。工具筛选中可选「自研规则」。
