"""
解析失败降级机制测试
"""

import pytest
from pathlib import Path

from api_security.parser import ParseResult
from api_security.fallback import FallbackHandler, FallbackAction, identify_and_import_openapi

FIXTURES = Path(__file__).parent.parent / "fixtures"


class TestFallbackHandler:
    """降级处理器测试"""

    def test_parse_success_no_fallback(self):
        """解析成功时不应触发降级"""
        handler = FallbackHandler(on_failure=FallbackAction.SKIP)
        result, compliance = handler.parse_with_fallback(FIXTURES / "openapi_v2_petstore.yaml")
        assert result.success
        assert compliance is not None
        assert compliance.passed or True  # 可能有不通过项

    def test_parse_fail_skip(self):
        """解析失败 + SKIP - 返回 None 合规，不影响流程"""
        handler = FallbackHandler(on_failure=FallbackAction.SKIP)
        result, compliance = handler.parse_with_fallback("/nonexistent/file.yaml")
        assert not result.success
        assert compliance is None

    def test_should_skip_compliance(self):
        """解析失败时应跳过合规"""
        handler = FallbackHandler()
        assert handler.should_skip_compliance(ParseResult(success=False, error="err"))
        assert not handler.should_skip_compliance(ParseResult(success=True, spec={}, version="3.0"))


class TestDocIdentifier:
    """文档自动识别测试"""

    def test_identify_in_directory(self):
        """在目录中自动识别 OpenAPI 文档"""
        result = identify_and_import_openapi(FIXTURES)
        assert result is not None
        assert result.success
        assert result.version in ("2.0", "3.0")

    def test_identify_direct_file(self):
        """直接指定文件"""
        result = identify_and_import_openapi(FIXTURES / "openapi_v2_petstore.yaml")
        assert result is not None
        assert result.success
