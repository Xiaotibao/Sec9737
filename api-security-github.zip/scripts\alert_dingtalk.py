#!/usr/bin/env python3
"""
钉钉机器人告警对接脚本
支持 GitHub Actions 扫描结果推送至钉钉群
"""

import json
import os
import sys
from datetime import datetime

try:
    import requests
except ImportError:
    print("pip install requests", file=sys.stderr)
    sys.exit(1)


def send_dingtalk(
    webhook_url: str,
    title: str,
    text: str,
    at_all: bool = False,
) -> bool:
    """
    发送钉钉群机器人消息

    Args:
        webhook_url: 钉钉机器人 Webhook 地址
        title: 消息标题
        text: 消息内容（支持 Markdown）
        at_all: 是否 @所有人

    Returns:
        发送成功返回 True
    """
    payload = {
        "msgtype": "markdown",
        "markdown": {
            "title": title,
            "text": f"## {title}\n\n{text}",
        },
    }
    if at_all:
        payload["at"] = {"isAtAll": True}

    try:
        resp = requests.post(webhook_url, json=payload, timeout=10)
        result = resp.json()
        if result.get("errcode") == 0:
            return True
        print(f"DingTalk error: {result}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"DingTalk send failed: {e}", file=sys.stderr)
        return False


def build_scan_report(
    findings_count: int,
    repo: str = "",
    branch: str = "",
    run_url: str = "",
    passed: bool = False,
) -> str:
    """构建扫描报告文本"""
    status = "通过" if passed else "发现风险"
    lines = [
        f"- **状态**: {status}",
        f"- **发现数量**: {findings_count} 条",
        f"- **仓库**: {repo}",
        f"- **分支**: {branch}",
        f"- **时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
    ]
    if run_url:
        lines.append(f"- **流水线**: [查看详情]({run_url})")
    return "\n".join(lines)


def main() -> int:
    """
    命令行入口
    环境变量: DINGTALK_WEBHOOK, GITHUB_REPOSITORY, GITHUB_REF, GITHUB_RUN_ID, GITHUB_SERVER_URL
    """
    webhook = os.environ.get("DINGTALK_WEBHOOK", "").strip()
    if not webhook:
        print("DINGTALK_WEBHOOK not set, skip DingTalk alert", file=sys.stderr)
        return 0

    repo = os.environ.get("GITHUB_REPOSITORY", "unknown")
    branch = os.environ.get("GITHUB_REF", "main").replace("refs/heads/", "")
    run_id = os.environ.get("GITHUB_RUN_ID", "")
    server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
    run_url = f"{server}/{repo}/actions/runs/{run_id}" if run_id else ""

    findings_count = int(os.environ.get("SCAN_FINDINGS_COUNT", "0"))
    passed = findings_count == 0

    title = f"API Security Scan - {repo}"
    text = build_scan_report(findings_count, repo, branch, run_url, passed)

    ok = send_dingtalk(webhook, title, text, at_all=False)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
