#!/usr/bin/env python3
"""
启动管理后台并自动打开浏览器
双击运行或: python 启动并打开浏览器.py
"""
import os
import sys
import time
import webbrowser
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT / "src"))

PORT = 9000
URL = f"http://127.0.0.1:{PORT}/admin"

def run_server():
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    from api_security.admin.app import app
    try:
        from waitress import serve
        serve(app, host="127.0.0.1", port=PORT, threads=4)
    except ImportError:
        app.run(host="127.0.0.1", port=PORT, use_reloader=False)

def main():
    print("=" * 50)
    print("API 安全管理后台")
    print(f"正在启动... 端口 {PORT}")
    print(f"地址: {URL}")
    print("=" * 50)

    # 后台线程启动服务器
    t = threading.Thread(target=run_server, daemon=True)
    t.start()

    # 等待启动
    time.sleep(2)

    # 打开浏览器
    print(f"\n正在打开浏览器...\n")
    webbrowser.open(URL)

    print("服务器运行中，关闭此窗口将停止")
    print("按 Ctrl+C 停止\n")
    try:
        while t.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n已停止")

if __name__ == "__main__":
    main()
