"""
规则加载 - 从 YAML/JSON 加载，支持启用状态覆盖
"""

import json
import re
from pathlib import Path
from typing import Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from .schema import NativeRule

# 项目根目录（config/ 所在）：loader 在 api_security/native_rules/，parents[2]=src，parents[3]=project_root
_PROJECT_ROOT = Path(__file__).resolve().parents[3]
RULES_DIR = _PROJECT_ROOT / "config" / "native_rules"
CONFIG_FILE = _PROJECT_ROOT / "data" / "native_rules_config.json"


def get_rules_path() -> Path:
    """获取规则目录"""
    return RULES_DIR


def _load_enabled_overrides() -> dict[str, bool]:
    """加载用户配置的启用/禁用状态"""
    if not CONFIG_FILE.exists():
        return {}
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return data.get("rules", {})  # { rule_id: enabled }
    except Exception:
        return {}


def _save_enabled_overrides(overrides: dict[str, bool]) -> None:
    """保存启用/禁用状态"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps({"rules": overrides, "version": "1.0"}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_rules(
    rules_dir: Optional[Path] = None,
    include_disabled: bool = False,
) -> list[NativeRule]:
    """
    加载所有规则
    include_disabled: 是否包含已禁用的规则（用于管理界面）
    """
    base = rules_dir or RULES_DIR
    overrides = _load_enabled_overrides()
    rules: list[NativeRule] = []

    for ext in ("*.yaml", "*.yml", "*.json"):
        for path in base.glob(ext):
            if path.name.startswith("_"):
                continue
            try:
                raw = path.read_text(encoding="utf-8")
                if ext.endswith("json"):
                    data = json.loads(raw)
                elif YAML_AVAILABLE:
                    data = yaml.safe_load(raw)
                else:
                    continue
                if not data:
                    continue
                items = data.get("rules", data) if isinstance(data, dict) else data
                if not isinstance(items, list):
                    items = [data]
                for item in items:
                    if not isinstance(item, dict) or not item.get("pattern"):
                        continue
                    rule = NativeRule.from_dict(item)
                    if rule.id in overrides:
                        rule.enabled = overrides[rule.id]
                    if include_disabled or rule.enabled:
                        rules.append(rule)
            except Exception:
                pass

    return rules


def set_rule_enabled(rule_id: str, enabled: bool) -> bool:
    """设置规则启用状态"""
    overrides = _load_enabled_overrides()
    overrides[rule_id] = enabled
    _save_enabled_overrides(overrides)
    return True


def get_rule_enabled_overrides() -> dict[str, bool]:
    """获取所有规则的启用覆盖"""
    return _load_enabled_overrides()


def save_rule_enabled_overrides(overrides: dict[str, bool]) -> None:
    """保存启用覆盖（批量）"""
    _save_enabled_overrides(overrides)
