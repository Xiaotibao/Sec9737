# PowerShell 启动脚本（使用 ; 而非 &&）
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$env:PYTHONPATH = "src"
python run_admin.py --port 35555
