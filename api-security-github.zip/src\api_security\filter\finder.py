"""
扫描结果多维度筛选逻辑
维度：接口名称（title/location）、漏洞等级、检测工具
"""

from typing import Any, Optional

# 支持的检测工具
TOOLS = frozenset({"opensca", "semgrep", "afrog"})
# 支持的漏洞等级
SEVERITIES = frozenset({"critical", "high", "medium", "low", "info"})


def filter_findings(
    findings: list[dict | Any],
    api_name: Optional[str] = None,
    severity: Optional[str] = None,
    tool: Optional[str] = None,
) -> list[dict]:
    """
    多维度筛选扫描结果
    支持单独或组合筛选，空值表示不限制该维度

    Args:
        findings: 漏洞列表（dict 或对象）
        api_name: 接口名称关键词，匹配 title 或 location
        severity: 漏洞等级 critical|high|medium|low|info
        tool: 检测工具 opensca|semgrep|afrog

    Returns:
        筛选后的漏洞列表（统一为 dict）
    """
    result = []
    for f in findings:
        d = _to_dict(f)
        if _match_api_name(d, api_name) and _match_severity(d, severity) and _match_tool(d, tool):
            result.append(d)
    return result


def _to_dict(f: Any) -> dict:
    if isinstance(f, dict):
        return f
    return {
        "tool": getattr(f, "tool", ""),
        "severity": getattr(f, "severity", ""),
        "title": getattr(f, "title", ""),
        "description": getattr(f, "description", ""),
        "location": getattr(f, "location", ""),
        "cve_id": getattr(f, "cve_id", ""),
        "rule_id": getattr(f, "rule_id", ""),
    }


def _match_api_name(d: dict, api_name: Optional[str]) -> bool:
    if not api_name or not api_name.strip():
        return True
    kw = api_name.strip().lower()
    title = (d.get("title") or "").lower()
    location = (d.get("location") or "").lower()
    return kw in title or kw in location


def _match_severity(d: dict, severity: Optional[str]) -> bool:
    if not severity or not severity.strip():
        return True
    sev = severity.strip().lower()
    if sev not in SEVERITIES:
        return True
    return (d.get("severity") or "").strip().lower() == sev


def _match_tool(d: dict, tool: Optional[str]) -> bool:
    if not tool or not tool.strip():
        return True
    t = tool.strip().lower()
    if t not in TOOLS:
        return True
    return (d.get("tool") or "").strip().lower() == t
