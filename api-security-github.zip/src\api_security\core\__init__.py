"""
API 漏洞检测核心模块
集成 OpenSCA + Semgrep + afrog，覆盖常见 API 安全风险
"""

from .detector import APIVulnerabilityDetector, DetectionResult
from .scanner import run_api_scan

__all__ = [
    "APIVulnerabilityDetector",
    "DetectionResult",
    "run_api_scan",
]
