"""
命令行入口
适配 Cursor 编程环境，支持调试与集成
"""

import argparse
import json
import sys
from pathlib import Path

from loguru import logger

from .core.scanner import run_api_scan
from .parser import OpenAPIParser, ComplianceChecker
from .fallback import FallbackHandler, FallbackAction, identify_and_import_openapi
from .risk_control import TOOL_DISCLAIMER


def _setup_logging(verbose: bool = False):
    logger.remove()
    level = "DEBUG" if verbose else "INFO"
    logger.add(sys.stderr, level=level)


def cmd_scan(args: argparse.Namespace) -> int:
    """执行完整 API 安全扫描"""
    target = Path(args.target)
    if not target.exists():
        logger.error(f"目标路径不存在: {target}")
        return 1

    result = run_api_scan(
        target=target,
        openapi=args.openapi,
        afrog_url=args.afrog_url,
        skip_openapi_on_fail=not args.no_skip_on_fail,
        auto_identify_openapi=not args.no_auto_openapi,
        incremental=getattr(args, "incremental", False),
        base_ref=getattr(args, "base_ref", None),
        previous_result_path=getattr(args, "previous_result", None),
    )

    detection = result["detection"]
    compliance = result["compliance"]

    # 输出漏洞发现
    if detection.findings:
        logger.info(f"共发现 {len(detection.findings)} 条风险")
        for f in detection.findings:
            logger.warning(f"[{f.tool}] {f.severity}: {f.title} - {f.description[:80]}...")
    else:
        logger.info("未发现漏洞")

    # 输出合规结果
    if compliance:
        if not compliance.passed:
            if compliance.missing_security:
                logger.warning(f"缺失 security 定义: {compliance.missing_security}")
            if compliance.sensitive_fields_in_response:
                logger.warning(f"响应含敏感字段: {compliance.sensitive_fields_in_response}")
            if compliance.missing_auth_errors:
                logger.warning(f"缺失 401/403 定义: {compliance.missing_auth_errors}")
        else:
            logger.info("OpenAPI 设计合规核查通过")
    elif result["compliance_skipped"]:
        logger.info("已跳过 OpenAPI 合规检测（解析失败）")

    if args.output:
        out_path = Path(args.output)
        out_data = {
            "tool_disclaimer": TOOL_DISCLAIMER,
            "detection": {
                "success": detection.success,
                "findings_count": len(detection.findings),
                "findings": [
                    {
                        "tool": f.tool,
                        "severity": f.severity,
                        "title": f.title,
                        "description": f.description,
                        "location": f.location,
                        "cve_id": f.cve_id,
                        "rule_id": getattr(f, "rule_id", None),
                        "owasp_category": getattr(f, "owasp_category", None),
                    }
                    for f in detection.findings
                ],
                "tools_run": detection.tools_run,
                "tools_skipped": detection.tools_skipped,
            },
            "openapi_parsed": result["openapi_parsed"],
            "compliance_skipped": result["compliance_skipped"],
        }
        if compliance:
            out_data["compliance"] = {
                "passed": compliance.passed,
                "missing_security": compliance.missing_security,
                "sensitive_fields_in_response": compliance.sensitive_fields_in_response,
                "missing_auth_errors": compliance.missing_auth_errors,
            }
        out_path.write_text(json.dumps(out_data, ensure_ascii=False, indent=2), encoding="utf-8")
        logger.info(f"结果已写入: {out_path}")

    return 0 if not detection.findings else 1


def cmd_parse(args: argparse.Namespace) -> int:
    """仅解析 OpenAPI 文档"""
    parser = OpenAPIParser(strict_validation=args.strict)
    result = parser.parse(args.file)

    if not result.success:
        logger.error(f"解析失败: {result.error}")
        if args.fallback_prompt:
            logger.info("请上传符合 OpenAPI 2.0/3.0 规范的文档，或跳过该检测流程")
        return 1

    logger.info(f"解析成功，版本: {result.version}")
    checker = ComplianceChecker()
    compliance = checker.check(result)

    if compliance.passed:
        logger.info("合规核查通过")
    else:
        logger.warning("合规问题:")
        if compliance.missing_security:
            logger.warning(f"  缺失 security: {compliance.missing_security}")
        if compliance.sensitive_fields_in_response:
            logger.warning(f"  敏感字段: {compliance.sensitive_fields_in_response}")
        if compliance.missing_auth_errors:
            logger.warning(f"  缺失 401/403: {compliance.missing_auth_errors}")

    if args.output:
        Path(args.output).write_text(
            json.dumps({
                "parse_success": True,
                "version": result.version,
                "compliance": {
                    "passed": compliance.passed,
                    "missing_security": compliance.missing_security,
                    "sensitive_fields_in_response": compliance.sensitive_fields_in_response,
                    "missing_auth_errors": compliance.missing_auth_errors,
                },
            }, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return 0


def cmd_afrog_check(args: argparse.Namespace) -> int:
    """检测 afrog 目标 URL 是否可达"""
    from .core.detector import APIVulnerabilityDetector
    detector = APIVulnerabilityDetector(target_path=Path("."), afrog_url=args.url)
    ok, msg = detector._check_afrog_target_reachable()
    if ok:
        logger.info("目标可达，可执行 afrog 扫描")
        return 0
    logger.error(f"目标不可达: {msg}")
    return 1


def cmd_identify(args: argparse.Namespace) -> int:
    """自动识别 OpenAPI 文档"""
    result = identify_and_import_openapi(args.path, recursive=args.recursive)
    if result and result.success:
        logger.info(f"已识别: {result.source} (版本 {result.version})")
        return 0
    logger.warning("未找到有效的 OpenAPI 文档")
    return 1


def main() -> int:
    """主入口"""
    ap = argparse.ArgumentParser(description="API 安全企业版 - 覆盖常见 API 安全风险")
    ap.add_argument("-v", "--verbose", action="store_true", help="详细输出")
    sub = ap.add_subparsers(dest="cmd", required=True)

    # scan
    p_scan = sub.add_parser("scan", help="执行完整 API 安全扫描")
    p_scan.add_argument("target", help="扫描目标路径")
    p_scan.add_argument("--openapi", "-o", help="OpenAPI 文档路径")
    p_scan.add_argument("--afrog-url", help="afrog 扫描的 API URL")
    p_scan.add_argument("--output", "-O", help="结果输出 JSON 路径")
    p_scan.add_argument("--no-skip-on-fail", action="store_true", help="解析失败时提示而非跳过")
    p_scan.add_argument("--no-auto-openapi", action="store_true", help="禁用自动识别 OpenAPI")
    p_scan.add_argument("--incremental", "--changed-only", dest="incremental", action="store_true",
                        help="增量模式：仅扫描 git 变更文件，缩短 CI 时间")
    p_scan.add_argument("--base-ref", help="增量基准引用，如 origin/main、HEAD~1")
    p_scan.add_argument("--previous-result", help="上次扫描结果 JSON 路径，用于合并展示")
    p_scan.set_defaults(func=cmd_scan)

    # parse
    p_parse = sub.add_parser("parse", help="仅解析 OpenAPI 文档")
    p_parse.add_argument("file", help="OpenAPI 文件路径或 URL")
    p_parse.add_argument("--strict", action="store_true", help="严格验证")
    p_parse.add_argument("--output", "-O", help="输出 JSON 路径")
    p_parse.add_argument("--fallback-prompt", action="store_true", help="失败时显示提示")
    p_parse.set_defaults(func=cmd_parse)

    # identify
    p_id = sub.add_parser("identify", help="自动识别 OpenAPI 文档")
    p_id.add_argument("path", help="搜索路径")
    p_id.add_argument("--no-recursive", dest="recursive", action="store_false", help="不递归")
    p_id.set_defaults(func=cmd_identify)

    # afrog-check
    p_afrog = sub.add_parser("afrog-check", help="检测 afrog 目标 URL 是否可达")
    p_afrog.add_argument("url", help="待扫描的 API 地址，如 http://localhost:8080")
    p_afrog.set_defaults(func=cmd_afrog_check)

    args = ap.parse_args()
    _setup_logging(args.verbose)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
