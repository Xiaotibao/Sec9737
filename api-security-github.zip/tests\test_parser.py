"""
OpenAPI/Swagger 解析与合规核查测试
使用至少 3 个真实的 OpenAPI 2.0/3.0 文档验证解析成功率
"""

import pytest
from pathlib import Path

from api_security.parser import OpenAPIParser, ParseResult, ComplianceChecker, ComplianceResult

FIXTURES = Path(__file__).parent.parent / "fixtures"


class TestOpenAPIParser:
    """解析脚本测试"""

    def test_parse_openapi_v2_yaml(self):
        """OpenAPI 2.0 YAML - 解析成功"""
        path = FIXTURES / "openapi_v2_petstore.yaml"
        assert path.exists(), "fixture 不存在"
        result = OpenAPIParser().parse(path)
        assert result.success
        assert result.version == "2.0"
        assert result.spec is not None
        assert "paths" in result.spec
        assert "/pets" in result.spec["paths"]

    def test_parse_openapi_v3_yaml(self):
        """OpenAPI 3.0 YAML - 解析成功"""
        path = FIXTURES / "openapi_v3_petstore.yaml"
        assert path.exists()
        result = OpenAPIParser().parse(path)
        assert result.success
        assert result.version == "3.0"
        assert result.spec is not None
        assert "paths" in result.spec

    def test_parse_openapi_v3_json(self):
        """OpenAPI 3.0 JSON - 解析成功"""
        path = FIXTURES / "openapi_v3_with_issues.json"
        assert path.exists()
        result = OpenAPIParser().parse(path)
        assert result.success
        assert result.version == "3.0"
        assert result.spec is not None

    def test_parse_nonexistent_fails(self):
        """不存在的文件 - 解析失败"""
        result = OpenAPIParser().parse("/nonexistent/path.yaml")
        assert not result.success
        assert result.error is not None

    def test_is_openapi_document(self):
        """自动识别 OpenAPI 文档"""
        parser = OpenAPIParser()
        assert parser.is_openapi_document('{"swagger": "2.0", "paths": {}}')
        assert parser.is_openapi_document('openapi: 3.0.0\npaths: {}')
        assert not parser.is_openapi_document("just plain text")


class TestComplianceChecker:
    """合规核查测试"""

    def test_v2_petstore_compliance(self):
        """v2 Petstore - 有 security 和 401/403，应通过"""
        path = FIXTURES / "openapi_v2_petstore.yaml"
        result = OpenAPIParser().parse(path)
        assert result.success
        compliance = ComplianceChecker().check(result)
        # GET /pets 无 security 但可能有 global，POST 有 security
        # 根据实际文档，GET 无 security 会报 missing
        assert isinstance(compliance, ComplianceResult)

    def test_v3_with_issues_compliance(self):
        """v3 含问题的文档 - 应检测到缺失与敏感字段"""
        path = FIXTURES / "openapi_v3_with_issues.json"
        result = OpenAPIParser().parse(path)
        assert result.success
        compliance = ComplianceChecker().check(result)
        assert not compliance.passed
        # 应检测到 password, api_key 等敏感字段
        assert len(compliance.sensitive_fields_in_response) > 0
        # 应检测到缺失 401/403
        assert len(compliance.missing_auth_errors) > 0
