@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo API 安全管理后台
echo ================================================
echo.
python run_admin.py --port 5001
echo.
pause
