"""
扫描结果反馈 - 高危漏洞提醒逻辑
无缝集成至扫描结果，输出需弹窗/通知的漏洞列表
"""

from typing import Any

from .severity import is_critical, is_high, get_vuln_fingerprint
from .freq_limit import check_24h_limit
from ..risk_control import TOOL_DISCLAIMER

# 固定弹窗文案模板
POPUP_TEMPLATE = "【生产环境高危风险提醒】检测到{vuln_name}漏洞，可能导致数据泄露/服务崩溃，团队版可统一管理整改，了解详情→"


def _finding_to_dict(f: Any) -> dict:
    """统一转为字典"""
    if isinstance(f, dict):
        return f
    return {
        "tool": getattr(f, "tool", ""),
        "severity": getattr(f, "severity", ""),
        "title": getattr(f, "title", ""),
        "description": getattr(f, "description", ""),
        "location": getattr(f, "location", None),
        "cve_id": getattr(f, "cve_id", None),
        "rule_id": getattr(f, "rule_id", None),
    }


def process_findings_for_alerts(
    findings: list[Any],
    project: str = "",
) -> dict:
    """
    处理扫描结果，输出需弹窗/通知的漏洞
    应用 24 小时频率限制，不包含「本月不再提醒」逻辑（由前端 localStorage 处理）

    Args:
        findings: 扫描发现的漏洞列表（dict 或 Finding），dict 可含 "project" 覆盖
        project: 默认项目标识，用于 24h 频率限制

    Returns:
        {
            "critical_popups": [  # 需弹窗的 Critical，已过 24h 频率过滤
                { "fingerprint", "vuln_name", "message", "finding", ... }
            ],
            "high_notifications": [  # 需系统通知的 High
                { "fingerprint", "vuln_name", "finding", ... }
            ],
        }
    """
    critical_popups = []
    high_notifications = []

    for f in findings:
        d = _finding_to_dict(f)
        fp = get_vuln_fingerprint(d)
        proj = d.get("project") if isinstance(d, dict) else project

        if is_critical(d):
            if check_24h_limit(proj, fp):
                vuln_name = d.get("title") or d.get("rule_id") or d.get("cve_id") or "未知"
                critical_popups.append({
                    "fingerprint": fp,
                    "vuln_name": vuln_name,
                    "message": POPUP_TEMPLATE.format(vuln_name=vuln_name),
                    "finding": d,
                    "project": proj,
                })
        elif is_high(d):
            vuln_name = d.get("title") or d.get("rule_id") or d.get("cve_id") or "未知"
            high_notifications.append({
                "fingerprint": fp,
                "vuln_name": vuln_name,
                "finding": d,
            })

    return {
        "critical_popups": critical_popups,
        "high_notifications": high_notifications,
        "tool_disclaimer": TOOL_DISCLAIMER,
    }
