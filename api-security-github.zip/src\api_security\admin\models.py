"""
极简团队管理 - 数据模型与存储层
MVP 使用 JSON 文件存储，便于快速部署
"""

import json
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict
from datetime import datetime

# 数据目录
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "scan_results"
RESULTS_DIR.mkdir(exist_ok=True)
MEMBERS_FILE = DATA_DIR / "members.json"
SCAN_META_FILE = DATA_DIR / "scan_metadata.json"


def _ensure_data_dir():
    DATA_DIR.mkdir(exist_ok=True)


def _load_json(path: Path, default: dict | list) -> dict | list:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save_json(path: Path, data: dict | list):
    _ensure_data_dir()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# 成员模型
# ---------------------------------------------------------------------------

@dataclass
class Member:
    id: int
    name: str
    email: str
    created_at: str

    def to_dict(self):
        return asdict(self)


def get_members() -> list[Member]:
    """获取所有成员"""
    data = _load_json(MEMBERS_FILE, [])
    return [Member(**m) for m in data if isinstance(m, dict)]


def get_member(member_id: int) -> Optional[Member]:
    """按 ID 获取成员"""
    for m in get_members():
        if m.id == member_id:
            return m
    return None


def add_member(name: str, email: str) -> Member:
    """新增成员"""
    members = get_members()
    new_id = max((m.id for m in members), default=0) + 1
    member = Member(id=new_id, name=name, email=email, created_at=datetime.now().isoformat())
    members.append(member)
    _save_json(MEMBERS_FILE, [m.to_dict() for m in members])
    return member


def update_member(member_id: int, name: Optional[str] = None, email: Optional[str] = None) -> Optional[Member]:
    """更新成员"""
    members = get_members()
    for m in members:
        if m.id == member_id:
            new_name = name if name is not None else m.name
            new_email = email if email is not None else m.email
            updated = Member(m.id, new_name, new_email, m.created_at)
            members = [x for x in members if x.id != member_id] + [updated]
            _save_json(MEMBERS_FILE, [x.to_dict() for x in members])
            return updated
    return None


def delete_member(member_id: int) -> bool:
    """删除成员"""
    members = [m for m in get_members() if m.id != member_id]
    if len(members) == len(get_members()):
        return False
    _save_json(MEMBERS_FILE, [m.to_dict() for m in members])
    return True


# ---------------------------------------------------------------------------
# 扫描记录元数据（关联成员与扫描文件）
# ---------------------------------------------------------------------------

def get_scan_metadata() -> dict:
    """{ scan_file: { member_id, project, member_name } }"""
    return _load_json(SCAN_META_FILE, {})


def set_scan_metadata(scan_file: str, member_id: int, project: str, member_name: str = ""):
    """记录扫描与成员的关联"""
    meta = get_scan_metadata()
    meta[scan_file] = {
        "member_id": member_id,
        "project": project,
        "member_name": member_name,
    }
    _save_json(SCAN_META_FILE, meta)
