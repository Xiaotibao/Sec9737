"""
API 扫描结果多维度筛选 API
"""

import json

from flask import Blueprint, request, jsonify

from ..filter import filter_findings
from ..remediation import enrich_finding_detail
from ..tenant import get_tenant_id_from_request, get_tenant_scan_metadata, get_tenant_members
from .models import RESULTS_DIR, PROJECT_ROOT

filter_bp = Blueprint("filter", __name__, url_prefix="/api/admin")


def _collect_findings_with_ids(tenant_id: str = "default"):
    """汇总所有 findings，为每条分配 id = scan_file::index"""
    meta = get_tenant_scan_metadata(tenant_id)
    members = {m.id: m.name for m in get_tenant_members(tenant_id)}
    all_findings = []

    for scan_file, info in meta.items():
        path = RESULTS_DIR / scan_file
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            findings = data.get("detection", {}).get("findings", [])
            for idx, f in enumerate(findings):
                row = dict(f)
                row["id"] = f"{scan_file}::{idx}"
                row["scan_file"] = scan_file
                row["timestamp"] = data.get("timestamp")
                row["project"] = info.get("project", "")
                row["member_name"] = info.get("member_name") or members.get(info.get("member_id"), "")
                all_findings.append(row)
        except Exception:
            pass

    # 仅 default 租户包含未关联成员的扫描（向后兼容）
    if tenant_id == "default":
        for path in RESULTS_DIR.glob("scan_*.json"):
            if path.name in meta:
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                findings = data.get("detection", {}).get("findings", [])
                for idx, f in enumerate(findings):
                    row = dict(f)
                    row["id"] = f"{path.name}::{idx}"
                    row["scan_file"] = path.name
                    row["timestamp"] = data.get("timestamp")
                    row["project"] = ""
                    row["member_name"] = ""
                    all_findings.append(row)
            except Exception:
                pass

    return all_findings


@filter_bp.route("/findings", methods=["GET"])
def list_findings_filtered():
    """
    获取扫描结果，支持多维度筛选
    Query: api_name=, severity=, tool=
    """
    tenant_id = get_tenant_id_from_request(request)
    api_name = request.args.get("api_name", "").strip() or None
    severity = request.args.get("severity", "").strip() or None
    tool = request.args.get("tool", "").strip() or None

    all_findings = _collect_findings_with_ids(tenant_id)
    filtered = filter_findings(all_findings, api_name=api_name, severity=severity, tool=tool)
    return jsonify({"findings": filtered, "total": len(filtered)})


@filter_bp.route("/afrog/check", methods=["GET"])
def afrog_check():
    """
    afrog 目标连通性检查
    Query: url= 待扫描的 API 地址
    """
    url = request.args.get("url", "").strip()
    if not url:
        return jsonify({"reachable": False, "message": "请提供 url 参数"}), 400
    from ..core.detector import APIVulnerabilityDetector
    detector = APIVulnerabilityDetector(target_path=".", afrog_url=url)
    ok, msg = detector._check_afrog_target_reachable()
    return jsonify({"reachable": ok, "message": msg if not ok else "目标可达"})


@filter_bp.route("/findings/<finding_id>", methods=["GET"])
def get_finding_detail(finding_id: str):
    """
    获取单条漏洞详情，含修复建议与参考链接
    finding_id 格式: scan_file::index
    """
    tenant_id = get_tenant_id_from_request(request)
    if "::" not in finding_id or ".." in finding_id:
        return jsonify({"error": "Invalid id"}), 400
    scan_file, idx_str = finding_id.split("::", 1)
    try:
        idx = int(idx_str)
    except ValueError:
        return jsonify({"error": "Invalid id"}), 400

    path = RESULTS_DIR / scan_file
    if not path.exists() or not path.name.startswith("scan_"):
        return jsonify({"error": "Not found"}), 404

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        findings = data.get("detection", {}).get("findings", [])
        if idx < 0 or idx >= len(findings):
            return jsonify({"error": "Not found"}), 404
        f = dict(findings[idx])
        f["id"] = finding_id
        f["scan_file"] = scan_file
        f["timestamp"] = data.get("timestamp")
        meta = get_tenant_scan_metadata(tenant_id).get(scan_file, {})
        f["project"] = meta.get("project", "")
        f["member_name"] = meta.get("member_name", "")
        detail = enrich_finding_detail(f)

        # AI 修复建议（含补丁草稿，未配置 LLM 时降级为静态）
        try:
            from ..ai_repair import get_ai_repair_suggestion
            ai_repair = get_ai_repair_suggestion(f, project_root=PROJECT_ROOT)
            detail["ai_remediation"] = ai_repair.get("remediation")
            detail["ai_patch"] = ai_repair.get("patch")
            detail["ai_patch_formatted"] = ai_repair.get("patch_formatted", "")
            detail["ai_source"] = ai_repair.get("source", "static")
        except Exception:
            detail["ai_remediation"] = detail.get("remediation")
            detail["ai_patch"] = None
            detail["ai_patch_formatted"] = ""
            detail["ai_source"] = "static"

        return jsonify(detail)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
