"""
简易 Flask API - 用于演示扫描
运行: python main.py
访问: http://127.0.0.1:5000/docs
"""

from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

USERS = [
    {"id": 1, "username": "alice", "email": "alice@example.com"},
    {"id": 2, "username": "bob", "email": "bob@example.com"},
]


@app.route("/users", methods=["GET"])
def list_users():
    return jsonify(USERS)


@app.route("/users/<int:uid>", methods=["GET"])
def get_user(uid):
    for u in USERS:
        if u["id"] == uid:
            return jsonify(u)
    return jsonify({"error": "Not found"}), 404


@app.route("/login", methods=["POST"])
def login():
    return jsonify({"token": "demo-token"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
