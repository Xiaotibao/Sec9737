"""
Webhook 配置 - 支持多 URL、多事件类型
存储：data/webhooks.json
"""

import json
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict

from .models import DATA_DIR

WEBHOOKS_FILE = DATA_DIR / "webhooks.json"

EVENT_SCAN_COMPLETE = "scan_complete"
EVENT_CRITICAL_FOUND = "critical_found"
EVENT_API_CHANGE_CRITICAL = "api_change_critical"

PLATFORM_GENERIC = "generic"
PLATFORM_FEISHU = "feishu"
PLATFORM_SLACK = "slack"
PLATFORM_DINGTALK = "dingtalk"
PLATFORM_WECOM = "wecom"


@dataclass
class WebhookConfig:
    id: str
    name: str
    url: str
    events: list[str]  # [scan_complete, critical_found]
    platform: str = PLATFORM_GENERIC
    headers: Optional[dict] = None
    enabled: bool = True

    def to_dict(self):
        return asdict(self)


def _load_webhooks() -> list[dict]:
    if not WEBHOOKS_FILE.exists():
        return []
    try:
        data = json.loads(WEBHOOKS_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_webhooks(webhooks: list[dict]):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WEBHOOKS_FILE.write_text(json.dumps(webhooks, ensure_ascii=False, indent=2), encoding="utf-8")


def get_webhooks() -> list[dict]:
    """获取所有 Webhook 配置"""
    return _load_webhooks()


def get_webhooks_for_event(event: str) -> list[dict]:
    """获取订阅指定事件的已启用 Webhook"""
    return [w for w in _load_webhooks() if w.get("enabled", True) and event in (w.get("events") or [])]


def add_webhook(name: str, url: str, events: list[str], platform: str = PLATFORM_GENERIC, headers: Optional[dict] = None) -> dict:
    """新增 Webhook"""
    webhooks = _load_webhooks()
    max_id = max((int(w.get("id", "0").replace("wh", "") or 0) for w in webhooks if str(w.get("id", "")).startswith("wh")), default=0)
    new_id = f"wh{max_id + 1}"
    w = {
        "id": new_id,
        "name": name,
        "url": url.strip(),
        "events": events or [EVENT_SCAN_COMPLETE],
        "platform": platform or PLATFORM_GENERIC,
        "headers": headers or {"Content-Type": "application/json"},
        "enabled": True,
    }
    webhooks.append(w)
    _save_webhooks(webhooks)
    return w


def update_webhook(wh_id: str, **kwargs) -> Optional[dict]:
    """更新 Webhook"""
    webhooks = _load_webhooks()
    for i, w in enumerate(webhooks):
        if w.get("id") == wh_id:
            for k, v in kwargs.items():
                if k in ("name", "url", "events", "platform", "headers", "enabled") and v is not None:
                    webhooks[i][k] = v
            _save_webhooks(webhooks)
            return webhooks[i]
    return None


def delete_webhook(wh_id: str) -> bool:
    """删除 Webhook"""
    webhooks = [w for w in _load_webhooks() if w.get("id") != wh_id]
    if len(webhooks) == len(_load_webhooks()):
        return False
    _save_webhooks(webhooks)
    return True
