"""
影响分析 - 标记高风险变更
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RiskFinding:
    """风险发现"""
    severity: str  # critical | high | medium | low
    op_id: str
    change_type: str
    title: str
    description: str
    details: dict = field(default_factory=dict)


def analyze_change_impact(diff_result: dict) -> list[dict]:
    """
    分析变更影响，标记高风险
    返回 RiskFinding 列表（转为 dict）
    """
    findings: list[dict] = []

    # 1. 删除的接口 - medium（可能影响调用方）
    for op_id in diff_result.get("operations_removed", []):
        findings.append({
            "severity": "medium",
            "op_id": op_id,
            "change_type": "removed",
            "title": "接口已删除",
            "description": f"{op_id} 已从 API 中移除，可能影响现有调用方",
            "details": {},
        })

    # 2. 修改的操作 - 检查高风险
    for item in diff_result.get("operations_modified", []):
        op_id = item.get("op_id", "")
        details = item.get("details", {})

        if details.get("auth_removed"):
            findings.append({
                "severity": "critical",
                "op_id": op_id,
                "change_type": "modified",
                "title": "认证被移除",
                "description": f"{op_id} 的 security 定义被移除，接口可能变为未认证访问",
                "details": details,
            })
        if details.get("auth_errors_removed"):
            findings.append({
                "severity": "high",
                "op_id": op_id,
                "change_type": "modified",
                "title": "401/403 错误定义被移除",
                "description": f"{op_id} 的 401/403 响应定义被移除，文档与客户端可能无法正确处理未授权场景",
                "details": details,
            })
        if details.get("sensitive_fields_added"):
            fields = details["sensitive_fields_added"]
            findings.append({
                "severity": "high",
                "op_id": op_id,
                "change_type": "modified",
                "title": "响应新增敏感字段",
                "description": f"{op_id} 的响应 schema 新增敏感字段: {', '.join(fields)}",
                "details": details,
            })
        if details.get("now_deprecated"):
            findings.append({
                "severity": "low",
                "op_id": op_id,
                "change_type": "modified",
                "title": "接口已标记废弃",
                "description": f"{op_id} 已标记为 deprecated，需制定迁移计划",
                "details": details,
            })
        if details.get("auth_added"):
            findings.append({
                "severity": "low",
                "op_id": op_id,
                "change_type": "modified",
                "title": "新增认证要求",
                "description": f"{op_id} 新增 security 定义，需确保客户端适配",
                "details": details,
            })

    # 3. 新增的接口 - low（需关注是否定义认证）
    for op_id in diff_result.get("operations_added", []):
        findings.append({
            "severity": "low",
            "op_id": op_id,
            "change_type": "added",
            "title": "新增接口",
            "description": f"{op_id} 为新增接口，建议确认认证与敏感字段定义",
            "details": {},
        })

    return findings


def has_critical_findings(findings: list[dict]) -> bool:
    """是否存在 Critical 级别发现"""
    return any(f.get("severity") == "critical" for f in findings)
