"""
自研规则引擎 - 基于正则的代码扫描
"""

import re
from pathlib import Path
from typing import Optional

from loguru import logger

from ..core.detector import Finding
from .loader import load_rules
from .schema import NativeRule

# 语言 -> 文件扩展名
LANG_EXT = {
    "python": (".py",),
    "javascript": (".js", ".mjs", ".cjs"),
    "typescript": (".ts", ".tsx"),
    "java": (".java",),
    "go": (".go",),
    "ruby": (".rb",),
    "php": (".php",),
    "generic": (".py", ".js", ".ts", ".java", ".go", ".rb", ".php", ".yaml", ".yml", ".json"),
}


def _lang_matches_ext(languages: list[str], ext: str) -> bool:
    ext = ext.lower()
    for lang in languages:
        exts = LANG_EXT.get(lang, ())
        if ext in exts or "generic" in languages:
            return True
    return False


def _compile_pattern(pattern: str) -> Optional[re.Pattern]:
    try:
        return re.compile(pattern, re.IGNORECASE)
    except re.error:
        return None


class NativeRuleEngine:
    """
    自研规则引擎
    基于正则匹配扫描代码文件
    """

    def __init__(self, rules: Optional[list[NativeRule]] = None):
        self.rules = rules or load_rules()
        self._compiled: dict[str, re.Pattern] = {}
        for r in self.rules:
            if r.enabled and r.pattern:
                compiled = _compile_pattern(r.pattern)
                if compiled:
                    self._compiled[r.id] = compiled

    def scan_path(
        self,
        target: Path,
        include_paths: Optional[list[Path]] = None,
    ) -> list[Finding]:
        """
        扫描目标路径
        include_paths: 增量时仅扫描这些路径
        """
        target = Path(target).resolve()
        if target.is_file():
            files = [target] if self._should_scan(target, include_paths) else []
        else:
            files = self._collect_files(target, include_paths)

        findings: list[Finding] = []
        for path in files:
            try:
                findings.extend(self._scan_file(path, target))
            except Exception as e:
                logger.debug(f"扫描文件失败 {path}: {e}")

        return findings

    def _should_scan(self, path: Path, include_paths: Optional[list[Path]]) -> bool:
        if not include_paths:
            return True
        path_res = path.resolve()
        return any(path_res == p.resolve() or str(path_res).startswith(str(p.resolve())) for p in include_paths)

    def _collect_files(self, root: Path, include_paths: Optional[list[Path]]) -> list[Path]:
        all_exts = set()
        for exts in LANG_EXT.values():
            all_exts.update(exts)

        files: list[Path] = []
        if include_paths:
            for p in include_paths:
                p = Path(p).resolve()
                if p.is_file() and p.suffix.lower() in all_exts:
                    files.append(p)
                elif p.is_dir():
                    for ext in all_exts:
                        files.extend(p.rglob(f"*{ext}"))
        else:
            for ext in all_exts:
                files.extend(root.rglob(f"*{ext}"))

        # 排除常见非源码目录
        skip_dirs = {"node_modules", ".git", "__pycache__", "venv", ".venv", "dist", "build"}
        result = []
        for f in files:
            if any(s in f.parts for s in skip_dirs):
                continue
            result.append(f)
        return list(dict.fromkeys(result))

    def _scan_file(self, path: Path, root: Path) -> list[Finding]:
        findings: list[Finding] = []
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return findings

        try:
            rel_path = path.relative_to(root)
        except ValueError:
            rel_path = path
        rel_str = str(rel_path).replace("\\", "/")
        ext = path.suffix.lower()

        for rule in self.rules:
            if not rule.enabled or rule.id not in self._compiled:
                continue
            if not _lang_matches_ext(rule.languages, ext):
                continue
            pattern = self._compiled[rule.id]
            for line_no, line in enumerate(content.splitlines(), 1):
                if pattern.search(line):
                    location = f"{rel_str}:{line_no}"
                    findings.append(Finding(
                        tool="native_rules",
                        severity=rule.severity,
                        title=rule.message,
                        description=rule.message,
                        location=location,
                        rule_id=rule.id,
                        owasp_category=rule.owasp_category,
                    ))
                    break  # 每规则每文件只报一次

        return findings
