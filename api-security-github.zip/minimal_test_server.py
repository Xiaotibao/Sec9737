#!/usr/bin/env python3
"""
最小测试服务器 - 用于排查 404 问题
运行后访问 http://127.0.0.1:9000/ 应看到 "OK"
若此脚本能正常访问，说明环境无问题，问题在主应用
"""
import sys
import logging
# 抑制 Flask 开发服务器警告（PowerShell 会将其当作错误）
logging.getLogger("werkzeug").setLevel(logging.ERROR)
print("启动最小测试服务器...", flush=True)

try:
    from flask import Flask
except ImportError:
    print("错误: 请先安装 flask (pip install flask)")
    sys.exit(1)

app = Flask(__name__)

@app.route("/")
def index():
    return "OK - 服务器正常", 200, {"Content-Type": "text/plain; charset=utf-8"}

@app.route("/api/debug")
def debug():
    from pathlib import Path
    root = Path(__file__).resolve().parent
    admin = root / "admin_static" / "index.html"
    return {
        "status": "ok",
        "message": "最小测试服务器",
        "admin_index_exists": admin.exists(),
        "admin_path": str(admin),
    }

if __name__ == "__main__":
    port = 9000
    print("=" * 50, flush=True)
    print("最小测试服务器", flush=True)
    print(f"请在浏览器打开: http://127.0.0.1:{port}/", flush=True)
    print("=" * 50, flush=True)
    sys.stdout.flush()
    sys.stderr.flush()
    try:
        from waitress import serve
        serve(app, host="127.0.0.1", port=port, threads=2)
    except ImportError:
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
