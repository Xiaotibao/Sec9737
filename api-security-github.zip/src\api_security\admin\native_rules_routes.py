"""
自研规则管理 API
"""

import json

from flask import Blueprint, request, jsonify

from ..native_rules import load_rules, get_rules_path
from ..native_rules.loader import set_rule_enabled, get_rule_enabled_overrides, save_rule_enabled_overrides

native_rules_bp = Blueprint("native_rules", __name__, url_prefix="/api/admin")


@native_rules_bp.route("/native-rules", methods=["GET"])
def list_rules():
    """
    获取规则列表（含启用状态）
    Query: include_disabled=1 包含已禁用的规则
    """
    include_disabled = request.args.get("include_disabled", "0") == "1"
    rules = load_rules(include_disabled=include_disabled)
    items = [r.to_dict() for r in rules]
    return jsonify({"rules": items, "total": len(items)})


@native_rules_bp.route("/native-rules/<rule_id>/enable", methods=["POST"])
def enable_rule(rule_id: str):
    """启用规则"""
    data = request.get_json() or {}
    enabled = data.get("enabled", True)
    set_rule_enabled(rule_id, enabled)
    return jsonify({"success": True, "rule_id": rule_id, "enabled": enabled})


@native_rules_bp.route("/native-rules/batch-enable", methods=["POST"])
def batch_enable():
    """批量设置启用状态"""
    data = request.get_json() or {}
    updates = data.get("updates", [])  # [{id, enabled}, ...]
    overrides = get_rule_enabled_overrides()
    for u in updates:
        rid = u.get("id")
        enabled = u.get("enabled", True)
        if rid:
            overrides[rid] = enabled
    save_rule_enabled_overrides(overrides)
    return jsonify({"success": True})


@native_rules_bp.route("/native-rules/path", methods=["GET"])
def get_rules_path_info():
    """获取规则目录路径（用于文档）"""
    return jsonify({"path": str(get_rules_path())})
