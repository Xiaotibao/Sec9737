"""
OpenAPI Diff - 对比新旧 OpenAPI，识别新增/删除/修改的接口与字段
"""

from typing import Any
from dataclasses import dataclass, field

METHODS = ("get", "post", "put", "patch", "delete", "head", "options")


@dataclass
class PathChange:
    """路径级变更"""
    path: str
    change_type: str  # "added" | "removed" | "modified"
    old_operations: dict[str, dict] = field(default_factory=dict)
    new_operations: dict[str, dict] = field(default_factory=dict)
    added_ops: list[str] = field(default_factory=list)
    removed_ops: list[str] = field(default_factory=list)
    modified_ops: list[str] = field(default_factory=list)


@dataclass
class OperationChange:
    """操作级变更详情"""
    op_id: str  # "GET /api/users"
    change_type: str  # "added" | "removed" | "modified"
    details: dict = field(default_factory=dict)  # security_changed, params_changed, etc.


def _get_operations(path_item: dict) -> dict[str, dict]:
    """提取 path 下的所有 HTTP 方法操作"""
    if not isinstance(path_item, dict):
        return {}
    return {m: path_item[m] for m in METHODS if m in path_item and isinstance(path_item[m], dict)}


def _get_paths(spec: dict) -> dict[str, dict]:
    """提取 paths"""
    return spec.get("paths") or {}


def _op_id(method: str, path: str) -> str:
    return f"{method.upper()} {path}"


def _compare_operation(old_op: dict, new_op: dict, op_id: str) -> dict:
    """比较单个操作的变更详情"""
    details: dict[str, Any] = {}
    if not old_op and new_op:
        return {"added": True}
    if old_op and not new_op:
        return {"removed": True}
    if not old_op or not new_op:
        return details

    # security 变更
    old_sec = old_op.get("security")
    new_sec = new_op.get("security")
    if old_sec != new_sec:
        details["security_changed"] = {"old": old_sec, "new": new_sec}
        if (old_sec and len(old_sec) > 0) and (not new_sec or len(new_sec) == 0):
            details["auth_removed"] = True
        elif (not old_sec or len(old_sec) == 0) and new_sec and len(new_sec) > 0:
            details["auth_added"] = True

    # responses 401/403
    old_resp = old_op.get("responses") or {}
    new_resp = new_op.get("responses") or {}
    old_has_auth_err = "401" in str(old_resp) or "403" in str(old_resp)
    new_has_auth_err = "401" in str(new_resp) or "403" in str(new_resp)
    if old_has_auth_err and not new_has_auth_err:
        details["auth_errors_removed"] = True
    elif not old_has_auth_err and new_has_auth_err:
        details["auth_errors_added"] = True

    # parameters 简化比较
    old_params = old_op.get("parameters") or []
    new_params = new_op.get("parameters") or []
    if len(old_params) != len(new_params):
        details["parameters_changed"] = True

    # deprecated
    if not old_op.get("deprecated") and new_op.get("deprecated"):
        details["now_deprecated"] = True
    elif old_op.get("deprecated") and not new_op.get("deprecated"):
        details["undeprecated"] = True

    return details


def _extract_sensitive_from_schema(schema: dict, sensitive_names: frozenset, prefix: str = "") -> list[str]:
    """递归提取 schema 中的敏感字段路径"""
    found = []
    if not isinstance(schema, dict):
        return found
    props = schema.get("properties") or {}
    for name, sub in props.items():
        path = f"{prefix}.{name}" if prefix else name
        if any(s in name.lower() for s in sensitive_names):
            found.append(path)
        if isinstance(sub, dict) and "$ref" not in sub:
            found.extend(_extract_sensitive_from_schema(sub, sensitive_names, path))
    items = schema.get("items")
    if isinstance(items, dict):
        found.extend(_extract_sensitive_from_schema(items, sensitive_names, f"{prefix}[]" if prefix else "[]"))
    return found


def _get_response_schemas(resp: dict) -> list:
    schema = resp.get("schema")
    if schema:
        return [schema]
    content = resp.get("content") or {}
    return [c.get("schema") for c in content.values() if isinstance(c, dict) and c.get("schema")]


def _sensitive_in_responses(op: dict, sensitive_names: frozenset) -> list[str]:
    """检查响应中的敏感字段"""
    found = []
    for resp in (op.get("responses") or {}).values():
        if not isinstance(resp, dict):
            continue
        for schema in _get_response_schemas(resp):
            if schema:
                found.extend(_extract_sensitive_from_schema(schema, sensitive_names))
    return found


SENSITIVE_NAMES = frozenset({
    "password", "passwd", "pwd", "secret", "token", "api_key", "apikey",
    "access_token", "refresh_token", "credential", "private_key",
    "ssn", "credit_card", "cvv", "bank_account", "phone", "mobile", "email",
})


def openapi_diff(
    old_spec: dict,
    new_spec: dict,
) -> dict:
    """
    对比新旧 OpenAPI，返回变更摘要

    Returns:
        {
            "paths_added": [path, ...],
            "paths_removed": [path, ...],
            "paths_modified": [PathChange, ...],
            "operations_added": [op_id, ...],
            "operations_removed": [op_id, ...],
            "operations_modified": [OperationChange, ...],
        }
    """
    old_paths = _get_paths(old_spec)
    new_paths = _get_paths(new_spec)

    paths_added = [p for p in new_paths if p not in old_paths]
    paths_removed = [p for p in old_paths if p not in new_paths]
    paths_common = [p for p in old_paths if p in new_paths]

    paths_modified: list[PathChange] = []
    operations_added: list[str] = []
    operations_removed: list[str] = []
    operations_modified: list[dict] = []

    for path in paths_added:
        ops = _get_operations(new_paths[path])
        for m in ops:
            operations_added.append(_op_id(m, path))

    for path in paths_removed:
        ops = _get_operations(old_paths[path])
        for m in ops:
            operations_removed.append(_op_id(m, path))

    for path in paths_common:
        old_ops = _get_operations(old_paths[path])
        new_ops = _get_operations(new_paths[path])
        added = [m for m in new_ops if m not in old_ops]
        removed = [m for m in old_ops if m not in new_ops]
        modified = [m for m in old_ops if m in new_ops and old_ops[m] != new_ops[m]]

        for m in added:
            operations_added.append(_op_id(m, path))
        for m in removed:
            operations_removed.append(_op_id(m, path))

        if added or removed or modified:
            paths_modified.append(PathChange(
                path=path,
                change_type="modified",
                old_operations=old_ops,
                new_operations=new_ops,
                added_ops=[_op_id(m, path) for m in added],
                removed_ops=[_op_id(m, path) for m in removed],
                modified_ops=[_op_id(m, path) for m in modified],
            ))

        for m in modified:
            op_id = _op_id(m, path)
            details = _compare_operation(old_ops[m], new_ops[m], op_id)
            # 检查新增敏感字段
            old_sens = _sensitive_in_responses(old_ops[m], SENSITIVE_NAMES)
            new_sens = _sensitive_in_responses(new_ops[m], SENSITIVE_NAMES)
            added_sens = [f for f in new_sens if f not in old_sens]
            if added_sens:
                details["sensitive_fields_added"] = added_sens
            operations_modified.append({
                "op_id": op_id,
                "change_type": "modified",
                "details": details,
            })

    return {
        "paths_added": paths_added,
        "paths_removed": paths_removed,
        "paths_modified": [p.__dict__ for p in paths_modified],
        "operations_added": operations_added,
        "operations_removed": operations_removed,
        "operations_modified": operations_modified,
    }
