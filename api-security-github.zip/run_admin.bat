@echo off
chcp 65001 >nul
cd /d "%~dp0"
pip install flask flask-cors openpyxl reportlab PyYAML requests loguru openapi-spec-validator -q 2>nul
python run_admin.py --port 5000
if errorlevel 1 pause
