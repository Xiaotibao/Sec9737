"""
OpenAPI/Swagger 解析模块
兼容 2.0/3.0 全版本，实现轻量设计合规核查
"""

from .openapi_parser import OpenAPIParser, ParseResult
from .compliance_types import ComplianceResult
from .compliance_checker import ComplianceChecker

__all__ = [
    "OpenAPIParser",
    "ParseResult",
    "ComplianceResult",
    "ComplianceChecker",
]
