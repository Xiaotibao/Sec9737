"""
漏洞等级判断
Critical: 触发弹窗 | High: 仅系统通知
"""

from typing import Any


def is_critical(finding: dict | Any) -> bool:
    """
    判断是否为 Critical 级别
    仅 Critical 触发非关闭式弹窗
    """
    sev = _get_severity(finding)
    return sev == "critical"


def is_high(finding: dict | Any) -> bool:
    """
    判断是否为 High 级别
    High 仅触发普通系统通知，不弹窗
    """
    sev = _get_severity(finding)
    return sev == "high"


def _get_severity(finding: dict | Any) -> str:
    """提取 severity，统一小写"""
    if isinstance(finding, dict):
        return (finding.get("severity") or "").strip().lower()
    return (getattr(finding, "severity", None) or "").strip().lower()


def get_vuln_fingerprint(finding: dict | Any) -> str:
    """
    生成漏洞类型指纹，用于频率限制与「本月不再提醒」
    同一类漏洞：相同 tool + rule_id/cve_id/title
    """
    if isinstance(finding, dict):
        tool = finding.get("tool", "")
        rule_id = finding.get("rule_id") or finding.get("cve_id") or ""
        title = (finding.get("title") or "")[:80]
    else:
        tool = getattr(finding, "tool", "")
        rule_id = getattr(finding, "rule_id", None) or getattr(finding, "cve_id", None) or ""
        title = (getattr(finding, "title", None) or "")[:80]
    key = f"{tool}:{rule_id or title}"
    return key.strip() or "unknown"
