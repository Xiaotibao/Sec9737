"""
定价与权限管控 API
套餐购买、升级、权限校验
"""

from flask import Blueprint, request, jsonify

from ..billing import PermissionChecker, BillingAdapter
from ..billing.plans import PLANS, FEATURE_OPENAPI_COMPLIANCE, FEATURE_GITHUB_ACTIONS
from ..billing.license_store import get_enterprise_plan, set_license, get_expansion_count
from ..risk_control import get_plan_boundary, PLAN_SINGLE_LIMIT, PLAN_UNLIMITED_BOUNDARY
from ..tenant import get_tenant_id_from_request, get_tenant_members
from .audit_log import log_audit_from_request, OP_PLAN_PURCHASE, OP_PLAN_SET

billing_bp = Blueprint("billing", __name__, url_prefix="/api/billing")


def _enterprise_id() -> str:
    """从请求获取企业 ID，默认 default"""
    return get_tenant_id_from_request(request)


# ---------------------------------------------------------------------------
# 套餐与报价
# ---------------------------------------------------------------------------

@billing_bp.route("/plans", methods=["GET"])
def list_plans():
    """获取套餐列表与定价（含套餐边界标注）"""
    items = []
    for pid, p in PLANS.items():
        items.append({
            "id": pid,
            "name": p.name,
            "price_yearly": p.price_yearly,
            "api_calls_per_month": p.api_calls_per_month,
            "max_team_size": p.max_team_size,
            "expansion_price": p.expansion_price,
            "features": list(p.features),
            "boundary": get_plan_boundary(pid),
        })
    return jsonify({
        "plans": items,
        "plan_single_limit": PLAN_SINGLE_LIMIT,
        "plan_unlimited_boundary": PLAN_UNLIMITED_BOUNDARY,
    })


@billing_bp.route("/quote", methods=["POST"])
def get_quote():
    """
    获取报价
    Body: { "plan_id": "unlimited", "expansion_count": 2 }
    """
    data = request.get_json() or {}
    plan_id = data.get("plan_id", "")
    expansion_count = int(data.get("expansion_count", 0))
    adapter = BillingAdapter()
    quote = adapter.quote(plan_id, expansion_count)
    return jsonify({
        "plan_id": quote.plan_id,
        "plan_name": quote.plan_name,
        "price_yearly": quote.price_yearly,
        "expansion_count": quote.expansion_count,
        "expansion_fee": quote.expansion_fee,
        "total": quote.total,
    })


# ---------------------------------------------------------------------------
# 权限校验
# ---------------------------------------------------------------------------

@billing_bp.route("/check", methods=["POST"])
def check_permission():
    """
    权限校验
    Body: { "action": "api_call"|"feature"|"team_size", "feature"?: "...", ... }
    """
    eid = _enterprise_id()
    checker = PermissionChecker(eid)
    plan_id = checker.get_plan_id()
    data = request.get_json() or {}
    action = data.get("action", "")

    if action == "api_call":
        ok, msg = checker.check_api_call(plan_id)
        return jsonify({"allowed": ok, "message": msg, "plan_id": plan_id})

    if action == "feature":
        feature = data.get("feature", "")
        ok, msg = checker.check_feature(plan_id, feature)
        return jsonify({"allowed": ok, "message": msg, "plan_id": plan_id})

    if action == "team_size":
        count = len(get_tenant_members(_enterprise_id()))
        exp = checker.get_expansion_count()
        ok, msg = checker.check_team_size(plan_id, count, exp)
        return jsonify({"allowed": ok, "message": msg, "current": count, "expansion": exp})

    return jsonify({"allowed": False, "message": "未知 action"}), 400


# ---------------------------------------------------------------------------
# 许可证与购买入口
# ---------------------------------------------------------------------------

@billing_bp.route("/license", methods=["GET"])
def get_license():
    """获取当前企业许可证"""
    eid = _enterprise_id()
    plan_id = get_enterprise_plan(eid)
    expansion = get_expansion_count(eid)
    checker = PermissionChecker(eid)
    usage = checker._usage.get_monthly_usage()
    from ..billing.plans import get_plan
    p = get_plan(plan_id) if plan_id else None
    limit = p.api_calls_per_month if p else 100_000
    return jsonify({
        "enterprise_id": eid,
        "plan_id": plan_id or "basic",
        "plan_name": p.name if p else "基础版",
        "expansion_count": expansion,
        "usage_this_month": usage,
        "api_limit": limit,
    })


@billing_bp.route("/purchase", methods=["POST"])
def purchase():
    """
    套餐购买/升级入口（预留对接支付）
    Body: { "plan_id": "unlimited", "expansion_count": 0 }
    """
    eid = _enterprise_id()
    data = request.get_json() or {}
    plan_id = data.get("plan_id", "")
    expansion_count = int(data.get("expansion_count", 0))

    checker = PermissionChecker(eid)
    ok, msg = checker.check_single_limited_plan(get_enterprise_plan(eid), plan_id)
    if not ok:
        return jsonify({"success": False, "error": msg}), 400

    adapter = BillingAdapter()
    order = adapter.create_order(eid, plan_id, expansion_count)
    log_audit_from_request(OP_PLAN_PURCHASE, f"plan:{plan_id}", "success", "system", f"expansion={expansion_count}", request)
    return jsonify({
        "success": True,
        "order": order,
        "message": "请完成支付后生效，支付对接待接入",
    })


@billing_bp.route("/upgrade", methods=["POST"])
def upgrade():
    """
    套餐升级入口
    Body: { "plan_id": "flagship" }
    """
    return purchase()


@billing_bp.route("/license", methods=["POST"])
def set_license_route():
    """
    设置许可证（开发/测试用，生产需通过支付回调）
    Body: { "plan_id": "unlimited", "expansion_count": 0 }
    """
    eid = _enterprise_id()
    data = request.get_json() or {}
    plan_id = data.get("plan_id", "")
    expansion_count = int(data.get("expansion_count", 0))
    if plan_id not in ("basic", "advanced", "flagship", "unlimited"):
        return jsonify({"success": False, "error": "无效套餐"}), 400
    set_license(eid, plan_id, expansion_count)
    log_audit_from_request(OP_PLAN_SET, f"plan:{plan_id}", "success", "system", f"expansion={expansion_count}", request)
    return jsonify({"success": True, "plan_id": plan_id})
