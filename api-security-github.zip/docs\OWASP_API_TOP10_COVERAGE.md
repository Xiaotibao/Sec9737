# OWASP API Security Top 10 2023 覆盖说明

本文档说明本工具对 OWASP API Security Top 10 2023 各类漏洞的检测逻辑、规则与示例，便于追溯与验收。

---

## 覆盖总览

| 序号 | OWASP 类别 | 检测方式 | 规则/检查项 | 状态 |
|------|-------------|----------|-------------|------|
| 1 | API1:2023 失效的对象级授权 | Semgrep | owasp-api1-* | ✅ |
| 2 | API2:2023 失效的身份认证 | Semgrep + OpenAPI 合规 | owasp-api2-*, compliance-missing-auth-errors | ✅ |
| 3 | API3:2023 失效的对象属性级授权 | Semgrep + OpenAPI 合规 | owasp-api3-*, compliance-sensitive-field | ✅ |
| 4 | API4:2023 无限制的资源消耗 | Semgrep | owasp-api4-* | ✅ |
| 5 | API5:2023 失效的功能级授权 | Semgrep + OpenAPI 合规 | owasp-api5-*, api-missing-auth, compliance-missing-security | ✅ |
| 6 | API6:2023 批量分配 | Semgrep | owasp-api6-* | ✅ |
| 7 | API7:2023 安全配置错误 | Semgrep | owasp-api7-* | ✅ |
| 8 | API8:2023 注入 | Semgrep + OpenSCA | owasp-api8-*, api-sql-injection, OpenSCA CVE | ✅ |
| 9 | API9:2023 资产管理不当 | Semgrep + OpenAPI 合规 | owasp-api9-*, compliance-deprecated | ✅ |
| 10 | API10:2023 日志与监控不足 | Semgrep | owasp-api10-*, api-sensitive-log | ✅ |

---

## 详细说明

### API1:2023 失效的对象级授权 (BOLA/IDOR)

**描述**：API 未校验当前用户是否有权访问所请求的对象，导致越权访问。

**检测规则**（`config/owasp_api_top10/rules.yaml`）：

| 规则 ID | 说明 | 示例 |
|---------|------|------|
| owasp-api1-idor-path-param | 路径参数 `/entity/:id` 需校验归属 | `app.get("/users/:id", handler)` |
| owasp-api1-idor-req-params | 使用 req.params/query 中的 id 时需校验 | `User.findById(req.params.id)` |

**触发示例**（JavaScript）：
```javascript
app.get("/users/:id", (req, res) => {
  User.findById(req.params.id);  // 未校验当前用户是否有权访问
});
```

---

### API2:2023 失效的身份认证

**描述**：身份认证机制存在缺陷，如弱密钥、硬编码凭证、Token 未校验等。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api2-weak-jwt-secret | JWT 密钥过短或硬编码 | Semgrep |
| owasp-api2-hardcoded-credentials | 硬编码 password/secret/token | Semgrep |
| owasp-api2-skip-auth | 跳过认证的配置 | Semgrep |
| compliance-missing-auth-errors | 接口未定义 401/403 错误响应 | OpenAPI 合规 |

**触发示例**：
```javascript
jwt.sign(payload, "short_secret");  // 密钥过短
const password = "hardcoded123";    // 硬编码凭证
```

---

### API3:2023 失效的对象属性级授权

**描述**：API 暴露了不应暴露的对象属性，或允许客户端选择返回/更新的字段。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api3-object-assign-req-body | Object.assign 直接合并 req.body | Semgrep |
| owasp-api3-spread-req-body | 展开 req.body 到对象 | Semgrep |
| compliance-sensitive-field | 响应 schema 含敏感字段 (password, api_key 等) | OpenAPI 合规 |

**触发示例**：
```javascript
Object.assign(user, req.body);  // 可能覆盖 role、isAdmin 等
```

**OpenAPI 示例**：
```yaml
responses:
  200:
    schema:
      properties:
        password: { type: string }  # 敏感字段不应在响应中
```

---

### API4:2023 无限制的资源消耗

**描述**：API 未对请求大小、频率、返回数量进行限制，存在 DoS 风险。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api4-select-all | SELECT * FROM 全表查询 | Semgrep |
| owasp-api4-find-without-limit | .find() 无 limit 分页 | Semgrep |

**触发示例**：
```javascript
Model.find({});           // 无 limit
db.query("SELECT * FROM users");  // 全表查询
```

---

### API5:2023 失效的功能级授权

**描述**：API 未校验调用者是否有权执行该操作（如管理员接口对普通用户开放）。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api5-missing-auth-decorator | 路由可能缺失认证装饰器 | Semgrep |
| owasp-api5-admin-without-check | 管理类接口需权限校验 | Semgrep |
| api-missing-auth | API 路由可能缺失认证 | config/semgrep_rules.yaml |
| compliance-missing-security | 接口未定义 security | OpenAPI 合规 |

**触发示例**（Python）：
```python
@app.route("/admin/users")
def list_users():
    return User.query.all()  # 未校验是否为管理员
```

---

### API6:2023 批量分配

**描述**：API 允许客户端通过请求体批量更新字段，可能覆盖敏感属性（如 role、isAdmin）。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api6-patch-body-direct | 直接将 req.body 用于 update | Semgrep |
| owasp-api6-put-whole-body | .update(req.body) 未白名单 | Semgrep |

**触发示例**：
```javascript
User.update(req.body);  // 客户端可传入 { role: "admin" }
```

---

### API7:2023 安全配置错误

**描述**：CORS、调试模式、错误信息等配置不当，导致信息泄露或跨域风险。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api7-cors-wildcard | CORS 允许 * | Semgrep |
| owasp-api7-debug-enabled | 生产环境启用 debug | Semgrep |
| owasp-api7-stack-trace-exposed | 错误响应暴露堆栈 | Semgrep |

**触发示例**：
```javascript
"Access-Control-Allow-Origin": "*"
DEBUG = true
```

---

### API8:2023 注入

**描述**：SQL、NoSQL、命令等注入，导致数据泄露或系统被控。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api8-sql-injection | SQL 拼接用户输入 | Semgrep |
| owasp-api8-command-injection | os.system 用户输入 | Semgrep |
| owasp-api8-nosql-injection | $where/$regex 拼接 | Semgrep |
| api-sql-injection | 参数化查询缺失 | config/semgrep_rules.yaml |
| OpenSCA | 依赖中的已知 CVE | OpenSCA |

**触发示例**：
```python
query.execute(user_input)  # SQL 注入
os.system(user_input)     # 命令注入
```

---

### API9:2023 资产管理不当

**描述**：废弃接口未下线、API 版本管理混乱、文档与实现不一致等。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api9-deprecated-api | 代码中 @deprecated | Semgrep |
| owasp-api9-version-in-url | /v1/ 版本路径 | Semgrep |
| compliance-deprecated | OpenAPI 中 deprecated: true | OpenAPI 合规 |

**触发示例**：
```yaml
# OpenAPI
paths:
  /legacy/users:
    get:
      deprecated: true
```

---

### API10:2023 日志与监控不足

**描述**：敏感信息写入日志、异常未记录、缺乏安全事件监控等。

**检测规则**：

| 规则 ID | 说明 | 来源 |
|---------|------|------|
| owasp-api10-sensitive-in-log | log.*(user_input) | Semgrep |
| owasp-api10-password-in-log | 日志含 password | Semgrep |
| owasp-api10-empty-catch | 空 catch 块 | Semgrep |
| api-sensitive-log | 记录用户输入 | config/semgrep_rules.yaml |

**触发示例**：
```javascript
log.info("User login:", req.body.password);  // 密码不应入日志
try { ... } catch (e) { }  // 空 catch 不便于排查
```

---

## 规则文件位置

- **OWASP 专用规则**：`config/owasp_api_top10/rules.yaml`
- **通用 API 规则**：`config/semgrep_rules.yaml`
- **自定义规则**：`config/custom_rules/`（用户可扩展）

## 扫描时的规则加载

执行 `python -m api_security.cli scan <target>` 时：

1. 优先加载 `config/owasp_api_top10/` 下的 OWASP 规则
2. 同时加载 Semgrep 社区规则 (`--config auto`)
3. 若提供 OpenAPI，执行合规核查并合并到检测结果

## 结果中的 OWASP 类别

每条 Finding 可包含 `owasp_category` 字段（如 `API1:2023`），便于：

- 按 OWASP 类别筛选
- 导出报告时标注类别
- 统计各类别发现数量

---

*文档版本：v1.0 | 与 OWASP API Security Top 10 2023 对应*
