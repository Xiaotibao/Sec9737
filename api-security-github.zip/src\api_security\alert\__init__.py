"""
高危漏洞提醒模块
Critical: 非关闭式弹窗 | High: 普通系统通知
含频率限制与「本月不再提醒」逻辑
"""

from .severity import is_critical, is_high, get_vuln_fingerprint
from .freq_limit import check_24h_limit, record_popup
from .feedback import process_findings_for_alerts

__all__ = [
    "is_critical",
    "is_high",
    "get_vuln_fingerprint",
    "check_24h_limit",
    "record_popup",
    "process_findings_for_alerts",
]
