"""
企业版数据加密存储与清理周期 API
"""

from flask import Blueprint, request, jsonify

from ..storage import get_cleanup_config, set_cleanup_config, cleanup_old_data
from .audit_log import log_audit_from_request, OP_CONFIG, OP_CLEANUP

storage_bp = Blueprint("storage", __name__, url_prefix="/api/admin")


@storage_bp.route("/storage/cleanup-config", methods=["GET"])
def get_config():
    """获取数据清理配置"""
    return jsonify(get_cleanup_config())


@storage_bp.route("/storage/cleanup-config", methods=["POST"])
def update_config():
    """
    设置数据清理配置
    Body: { "enabled": true, "unit": "day"|"month", "value": 30 }
    """
    data = request.get_json() or {}
    enabled = data.get("enabled", False)
    unit = data.get("unit", "day")
    value = int(data.get("value", 30))
    cfg = set_cleanup_config(enabled=enabled, unit=unit, value=value)
    log_audit_from_request(OP_CONFIG, "cleanup_config", "success", "system", f"enabled={enabled},unit={unit},value={value}", request)
    return jsonify({"success": True, "config": cfg})


@storage_bp.route("/storage/cleanup", methods=["POST"])
def run_cleanup():
    """执行数据清理"""
    result = cleanup_old_data()
    log_audit_from_request(OP_CLEANUP, "cleanup", "success", "system", f"deleted={result.get('deleted',0)},kept={result.get('kept',0)}", request)
    return jsonify({"success": True, **result})
