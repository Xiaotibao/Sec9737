# AI 辅助修复 - 配置与隐私说明

## 概述

AI 辅助修复在漏洞详情中提供「一键修复建议」与代码补丁草稿。支持 LLM（如 OpenAI API）生成个性化建议，未配置时自动降级为静态建议。

## 配置方式

### 环境变量（推荐）

```bash
export OPENAI_API_KEY="sk-xxx"
# 可选：自定义端点（兼容 OpenAI 格式）
export OPENAI_API_BASE="https://api.openai.com/v1"
```

### 配置文件

在 `config/api_security.yaml` 中：

```yaml
ai_repair:
  enabled: true
  llm_endpoint: "https://api.openai.com/v1/chat/completions"
  api_key: null   # 建议用环境变量，避免泄露
  model: "gpt-4o-mini"
  timeout: 30
```

## 降级策略

| 配置状态 | 行为 |
|----------|------|
| 未配置 API Key | 使用静态修复建议模板 |
| 已配置 API Key | 调用 LLM 生成建议，失败时回退静态 |
| `enabled: false` | 仅静态建议 |

## 补丁草稿

以下漏洞类型提供可直接参考的代码补丁草稿（静态模板，无需 LLM）：

- **SQL 注入**：参数化查询示例（Python / Node.js）
- **硬编码密钥**：环境变量替代示例
- **缺失认证**：认证装饰器/中间件示例

补丁可在漏洞详情中「复制补丁」后，根据实际代码调整应用。

## 隐私与安全

- **API Key**：建议仅通过环境变量配置，勿提交到代码仓库
- **数据发送**：调用 LLM 时，会发送漏洞描述、位置及**相关代码片段**（漏洞行附近 ±5 行）至配置的端点
- **本地部署**：可配置自建或本地 LLM 端点（如 Ollama、vLLM），数据不出企业
- **禁用**：设置 `ai_repair.enabled: false` 或移除 API Key 可完全禁用 LLM 调用

## 验收标准

- 用户可在漏洞详情中看到 AI 修复建议区块
- 对支持类型可看到代码补丁草稿
- 可复制补丁到剪贴板
- 未配置 LLM 时仍展示静态建议
