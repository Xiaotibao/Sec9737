#!/usr/bin/env python3
"""
权限校验逻辑 - 3999元无限套餐专属功能
限制非无限套餐用户调用 API 安全扫描工作流
在 GitHub Actions 中通过 UNLIMITED_PACKAGE_TOKEN 密钥校验
"""

import os
import sys


def check_unlimited_package() -> bool:
    """
    校验是否为无限套餐用户
    社区版：无需 token，直接通过
    商业版：通过环境变量 UNLIMITED_PACKAGE_TOKEN 判断

    Returns:
        True 表示有权限，False 表示无权限
    """
    edition = os.environ.get("API_SECURITY_EDITION", "community").lower().strip()
    if edition in ("community", "ce", ""):
        return True  # 社区版无需 token
    token = os.environ.get("UNLIMITED_PACKAGE_TOKEN", "").strip()
    if not token:
        return False
    return True


def main() -> int:
    """
    命令行入口，供 GitHub Actions 调用
    有权限返回 0，无权限返回 1 并打印提示
    """
    if check_unlimited_package():
        print("License check passed: Unlimited package verified.")
        return 0

    print("=" * 60)
    print("ERROR: Enterprise edition requires Unlimited Package (3999元/年)")
    print("Set API_SECURITY_EDITION=community for free community edition,")
    print("or add UNLIMITED_PACKAGE_TOKEN for enterprise.")
    print("=" * 60)
    return 1


if __name__ == "__main__":
    sys.exit(main())
