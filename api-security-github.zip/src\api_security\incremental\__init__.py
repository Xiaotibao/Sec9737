"""
增量扫描 - 基于 git diff 识别变更，仅扫描变更部分
"""

from .change_detector import get_changed_files, get_changed_openapi
from .merge_result import merge_incremental_with_previous, load_previous_findings

__all__ = [
    "get_changed_files",
    "get_changed_openapi",
    "merge_incremental_with_previous",
    "load_previous_findings",
]
