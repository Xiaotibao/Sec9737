"""
审计日志 API
"""

import json
from io import BytesIO

from flask import Blueprint, request, jsonify, send_file

from .audit_log import query_audit_logs

audit_bp = Blueprint("audit", __name__, url_prefix="/api/admin")


@audit_bp.route("/audit-logs", methods=["GET"])
def list_audit_logs():
    """
    查询审计日志
    Query: start_date=YYYYMMDD, end_date=YYYYMMDD, operation_type=, limit=500
    """
    start_date = request.args.get("start_date", "").strip() or None
    end_date = request.args.get("end_date", "").strip() or None
    operation_type = request.args.get("operation_type", "").strip() or None
    limit = min(1000, max(1, int(request.args.get("limit", 500))))
    logs = query_audit_logs(
        start_date=start_date,
        end_date=end_date,
        operation_type=operation_type,
        limit=limit,
    )
    return jsonify({"logs": logs, "total": len(logs)})


@audit_bp.route("/audit-logs/export", methods=["GET"])
def export_audit_logs():
    """导出审计日志为 JSON"""
    start_date = request.args.get("start_date", "").strip() or None
    end_date = request.args.get("end_date", "").strip() or None
    operation_type = request.args.get("operation_type", "").strip() or None
    logs = query_audit_logs(start_date=start_date, end_date=end_date, operation_type=operation_type, limit=5000)
    buf = BytesIO(json.dumps(logs, ensure_ascii=False, indent=2).encode("utf-8"))
    from datetime import datetime
    filename = f"audit_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    return send_file(buf, mimetype="application/json", as_attachment=True, download_name=filename)
