"""
租户数据隔离 - 按租户存储与查询
"""

import json
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, asdict
from datetime import datetime

from .model import get_tenant_data_dir, Tenant

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESULTS_DIR = PROJECT_ROOT / "scan_results"


def _tenant_path(tenant_id: str, filename: str) -> Path:
    d = get_tenant_data_dir(tenant_id)
    d.mkdir(parents=True, exist_ok=True)
    return d / filename


def _load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# 成员（按租户）
# ---------------------------------------------------------------------------

@dataclass
class TenantMember:
    id: int
    name: str
    email: str
    created_at: str

    def to_dict(self):
        return asdict(self)


def get_tenant_members(tenant_id: str) -> list[TenantMember]:
    data = _load_json(_tenant_path(tenant_id, "members.json"), [])
    return [TenantMember(**m) for m in data if isinstance(m, dict)]


def get_tenant_member(tenant_id: str, member_id: int) -> Optional[TenantMember]:
    for m in get_tenant_members(tenant_id):
        if m.id == member_id:
            return m
    return None


def add_tenant_member(tenant_id: str, name: str, email: str) -> TenantMember:
    members = get_tenant_members(tenant_id)
    new_id = max((m.id for m in members), default=0) + 1
    member = TenantMember(id=new_id, name=name, email=email, created_at=datetime.now().isoformat())
    members.append(member)
    _save_json(_tenant_path(tenant_id, "members.json"), [asdict(m) for m in members])
    return member


def update_tenant_member(tenant_id: str, member_id: int, name: Optional[str] = None, email: Optional[str] = None) -> Optional[TenantMember]:
    members = get_tenant_members(tenant_id)
    for m in members:
        if m.id == member_id:
            m.name = name if name is not None else m.name
            m.email = email if email is not None else m.email
            _save_json(_tenant_path(tenant_id, "members.json"), [asdict(x) for x in members])
            return m
    return None


def delete_tenant_member(tenant_id: str, member_id: int) -> bool:
    members = [m for m in get_tenant_members(tenant_id) if m.id != member_id]
    if len(members) == len(get_tenant_members(tenant_id)):
        return False
    _save_json(_tenant_path(tenant_id, "members.json"), [asdict(m) for m in members])
    return True


# ---------------------------------------------------------------------------
# 扫描元数据（按租户，含 tenant_id）
# ---------------------------------------------------------------------------

def get_tenant_scan_metadata(tenant_id: str) -> dict:
    """{ scan_file: { member_id, project, member_name, tenant_id } }"""
    data = _load_json(_tenant_path(tenant_id, "scan_metadata.json"), {})
    return {k: v for k, v in data.items() if v.get("tenant_id", tenant_id) == tenant_id}


def set_tenant_scan_metadata(tenant_id: str, scan_file: str, member_id: int, project: str, member_name: str = ""):
    meta = get_tenant_scan_metadata(tenant_id)
    meta[scan_file] = {
        "member_id": member_id,
        "project": project,
        "member_name": member_name,
        "tenant_id": tenant_id,
    }
    _save_json(_tenant_path(tenant_id, "scan_metadata.json"), meta)


# ---------------------------------------------------------------------------
# 迁移：将旧数据迁移到 default 租户
# ---------------------------------------------------------------------------

def migrate_to_tenant_storage():
    """首次启用多租户时，将旧数据迁移到 default"""
    from ..admin.models import MEMBERS_FILE, SCAN_META_FILE, _load_json
    default_path = _tenant_path("default", "members.json")
    if not default_path.exists() and MEMBERS_FILE.exists():
        data = _load_json(MEMBERS_FILE, [])
        _save_json(default_path, data)
    meta_path = _tenant_path("default", "scan_metadata.json")
    if not meta_path.exists() and SCAN_META_FILE.exists():
        data = _load_json(SCAN_META_FILE, {})
        for k, v in data.items():
            if isinstance(v, dict):
                v["tenant_id"] = "default"
        _save_json(meta_path, data)
