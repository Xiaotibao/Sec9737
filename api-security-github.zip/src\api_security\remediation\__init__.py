"""
漏洞修复建议与参考链接
按漏洞类型维护 remediation 模板与 references
"""

from .templates import get_remediation, get_references, enrich_finding_detail

__all__ = ["get_remediation", "get_references", "enrich_finding_detail"]
