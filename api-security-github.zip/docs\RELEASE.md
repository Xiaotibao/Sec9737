# 发布指南 Release Guide

## 社区版发布

### 1. 版本号

在 `pyproject.toml` 和 `setup.py` 中更新 `version`。

### 2. 构建

```bash
pip install build
python -m build
```

生成 `dist/api_security-*.whl` 和 `dist/api-security-*.tar.gz`。

### 3. 发布到 PyPI

```bash
pip install twine
twine upload dist/*
```

### 4. GitHub Release

1. 创建 Tag：`git tag v1.0.0`
2. 推送：`git push origin v1.0.0`
3. 在 GitHub Releases 页面创建 Release，附上：
   - 变更说明（CHANGELOG）
   - 构建产物（wheel、sdist）
   - 安装说明

### 5. 文档站

- README 作为主文档
- docs/ 目录可部署至 GitHub Pages 或 Read the Docs

## 示例项目

`examples/sample-api` 可作为快速体验的示例，发布时一并包含。

## 商业版

商业版通过私有渠道分发，设置 `API_SECURITY_EDITION=enterprise` 启用完整功能。
