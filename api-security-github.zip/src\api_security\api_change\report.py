"""
变更影响报告
"""

from datetime import datetime
from typing import Optional

from .diff import openapi_diff
from .impact import analyze_change_impact, has_critical_findings


def generate_change_report(
    old_spec: dict,
    new_spec: dict,
    project: str = "",
    source_old: str = "",
    source_new: str = "",
) -> dict:
    """
    生成完整的变更影响报告

    Returns:
        {
            "timestamp": str,
            "project": str,
            "source_old": str,
            "source_new": str,
            "diff": {...},
            "findings": [...],
            "summary": {"added": n, "removed": n, "modified": n, "critical": n, "high": n},
            "has_critical": bool,
        }
    """
    diff_result = openapi_diff(old_spec, new_spec)
    findings = analyze_change_impact(diff_result)

    summary = {
        "added": len(diff_result.get("operations_added", [])),
        "removed": len(diff_result.get("operations_removed", [])),
        "modified": len(diff_result.get("operations_modified", [])),
        "critical": sum(1 for f in findings if f.get("severity") == "critical"),
        "high": sum(1 for f in findings if f.get("severity") == "high"),
        "medium": sum(1 for f in findings if f.get("severity") == "medium"),
        "low": sum(1 for f in findings if f.get("severity") == "low"),
    }

    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "project": project,
        "source_old": source_old,
        "source_new": source_new,
        "diff": diff_result,
        "findings": findings,
        "summary": summary,
        "has_critical": has_critical_findings(findings),
    }
