"""
阶梯定价策略与套餐定义
基础299/进阶999/旗舰1999/无限3999+扩容包200/人/年
"""

from dataclasses import dataclass
from typing import Optional

# 套餐标识
PLAN_BASIC = "basic"
PLAN_ADVANCED = "advanced"
PLAN_FLAGSHIP = "flagship"
PLAN_UNLIMITED = "unlimited"

# 扩容包单价（元/人/年）
EXPANSION_PRICE_PER_PERSON = 200

# 套餐功能权限映射
FEATURE_OPENAPI_COMPLIANCE = "openapi_compliance"  # OpenAPI 合规核查
FEATURE_GITHUB_ACTIONS = "github_actions"  # GitHub Actions 集成
FEATURE_BATCH_SCAN = "batch_scan"  # 批量扫描
FEATURE_TEAM_ADMIN = "team_admin"  # 团队管理后台


@dataclass
class Plan:
    """套餐定义"""
    id: str
    name: str
    price_yearly: int  # 元/年
    api_calls_per_month: Optional[int]  # None 表示不限
    max_team_size: Optional[int]  # None 表示不限，unlimited 为 10
    expansion_price: int  # 超员单价 元/人/年
    features: frozenset[str]

    @property
    def is_limited_plan(self) -> bool:
        """基础/进阶/旗舰：同一企业仅可购买1个"""
        return self.id in (PLAN_BASIC, PLAN_ADVANCED, PLAN_FLAGSHIP)


# 套餐配置
PLANS = {
    PLAN_BASIC: Plan(
        id=PLAN_BASIC,
        name="基础版",
        price_yearly=299,
        api_calls_per_month=100_000,
        max_team_size=None,
        expansion_price=0,
        features=frozenset({FEATURE_TEAM_ADMIN}),
    ),
    PLAN_ADVANCED: Plan(
        id=PLAN_ADVANCED,
        name="进阶版",
        price_yearly=999,
        api_calls_per_month=500_000,
        max_team_size=None,
        expansion_price=0,
        features=frozenset({FEATURE_TEAM_ADMIN, FEATURE_BATCH_SCAN}),
    ),
    PLAN_FLAGSHIP: Plan(
        id=PLAN_FLAGSHIP,
        name="旗舰版",
        price_yearly=1999,
        api_calls_per_month=1_000_000,
        max_team_size=None,
        expansion_price=0,
        features=frozenset({
            FEATURE_TEAM_ADMIN,
            FEATURE_BATCH_SCAN,
            FEATURE_OPENAPI_COMPLIANCE,
        }),
    ),
    PLAN_UNLIMITED: Plan(
        id=PLAN_UNLIMITED,
        name="无限版",
        price_yearly=3999,
        api_calls_per_month=None,
        max_team_size=10,
        expansion_price=EXPANSION_PRICE_PER_PERSON,
        features=frozenset({
            FEATURE_TEAM_ADMIN,
            FEATURE_BATCH_SCAN,
            FEATURE_OPENAPI_COMPLIANCE,
            FEATURE_GITHUB_ACTIONS,
        }),
    ),
}


def get_plan(plan_id: str) -> Optional[Plan]:
    """获取套餐配置"""
    return PLANS.get(plan_id)


def has_feature(plan_id: str, feature: str) -> bool:
    """套餐是否开放某功能"""
    p = get_plan(plan_id)
    return p is not None and feature in p.features


def get_api_limit(plan_id: str) -> Optional[int]:
    """获取套餐月 API 调用上限，None 表示不限"""
    p = get_plan(plan_id)
    return p.api_calls_per_month if p else 0


def get_max_team_size(plan_id: str) -> Optional[int]:
    """获取套餐团队人数上限"""
    p = get_plan(plan_id)
    return p.max_team_size if p else None
