# API 安全企业版 - 使用教程

## 一、快速开始

### 1.1 环境要求

- Python 3.10+
- 依赖：`pip install -r requirements.txt`

### 1.2 命令行扫描

```bash
# 设置 PYTHONPATH（Windows PowerShell）
$env:PYTHONPATH="src"

# 扫描当前目录
python -m api_security.cli scan . --output scan-result.json

# 指定 OpenAPI 文档
python -m api_security.cli scan . --openapi openapi.yaml --output scan-result.json
```

### 1.3 启动管理后台

```bash
python run_admin.py --port 5000
```

访问 `http://localhost:5000/admin` 进入团队管理后台。

---

## 二、检测能力说明

- **覆盖范围**：OWASP API Top10 常见漏洞类型
- **合规核查**：基于 OpenAPI/Swagger 的 API 设计合规轻量核查
- **工具链**：OpenSCA（依赖漏洞）、Semgrep（静态分析）、afrog（动态扫描，需配置 URL）

**重要**：工具检测结果仅供参考，建议结合实际业务做安全评估。

---

## 三、afrog 快速部署

afrog 用于对**运行中的 API** 进行动态漏洞扫描。`afrog_url` 为待扫描的 API 地址（非 afrog 服务地址）。

### 3.1 Docker 一键部署（推荐）

```bash
docker-compose -f docker-compose.afrog.yml up -d
# 访问 http://localhost:35555/admin
```

扫描时填写 `afrog_url`：
- 宿主机 API：`http://host.docker.internal:8080`
- 外网 API：`https://api.example.com`

### 3.2 本地安装

从 [afrog Releases](https://github.com/zan8in/afrog/releases/latest) 下载对应平台二进制，解压后放入 PATH。

### 3.3 连通性检查

扫描前会自动检测 `afrog_url` 是否可达，不可达时跳过 afrog 并给出明确提示。

- **CLI**：`python -m api_security.cli afrog-check http://localhost:8080`
- **管理后台**：在「扫描」页填写 afrog URL 后点击「检测」

详见 **[AFROG_SETUP.md](AFROG_SETUP.md)**。

---

## 四、GitHub Actions 集成

### 4.1 基础模板

复制 `.github/workflows/api-security-basic.yml` 到仓库 `.github/workflows/`，配置 `UNLIMITED_PACKAGE_TOKEN` 密钥。

### 4.2 进阶模板（钉钉/企业微信告警）

使用 `api-security-advanced.yml`，额外配置 `DINGTALK_WEBHOOK` 或 `WECOM_WEBHOOK`。

### 4.3 环境验证提示

**建议测试环境先验证，再部署至生产环境。** 模板中已包含醒目标注与步骤提示。

---

## 五、管理后台功能

### 5.1 套餐购买

- 查看当前套餐与 API 使用量
- 选择套餐并购买/升级
- 套餐边界已明确标注（同一企业仅限 1 个套餐，无限版限 10 人内）

### 5.2 漏洞筛选

- 按接口名称、等级、工具筛选
- 导出 Excel/PDF 报告（含免责声明）

### 5.3 Critical 漏洞

- 统一查看团队所有 Critical 漏洞
- 弹窗提醒（24h 频率限制，可「本月不再提醒」）
- 企业版升级入口

### 5.4 高意向用户预售

满足条件时展示预售横幅：预付 100 元抵扣 500 元 + 早鸟优惠。

---

## 六、插件集成（Cursor）

```python
from api_security import (
    scan,
    get_upgrade_prompt,
    is_high_intent_user,
    get_tutorial_links,
    PUBLIC_CAPABILITY_DESC,
    TOOL_DISCLAIMER,
)

# 执行扫描
result = scan(".", project="my-project")

# 获取能力描述
print(PUBLIC_CAPABILITY_DESC)  # 覆盖 OWASP API Top10...
print(TOOL_DISCLAIMER)         # 工具检测结果仅供参考...
```

---

## 七、配置模板

### 7.1 api_security.yaml（可选）

```yaml
# 扫描配置
scan:
  target: "."
  openapi: null
  afrog_url: null
```

### 7.2 环境变量

| 变量 | 说明 |
|------|------|
| UNLIMITED_PACKAGE_TOKEN | 无限套餐凭证（GitHub Actions） |
| DINGTALK_WEBHOOK | 钉钉机器人 Webhook |
| WECOM_WEBHOOK | 企业微信机器人 Webhook |
| X-Enterprise-Id | 企业 ID（API 请求头） |

---

## 八、常见问题

**Q：OpenSCA 未找到？**  
A：需单独安装 OpenSCA-cli，或扫描将跳过该工具。

**Q：afrog 未运行？**  
A：需配置 `afrog_url` 指向 afrog 服务地址。

**Q：套餐 API 超限？**  
A：升级套餐或等待下月重置。

**Q：团队人数超限？**  
A：无限版需购买扩容包（200 元/人/年）。
