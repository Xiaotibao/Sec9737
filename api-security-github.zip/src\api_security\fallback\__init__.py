"""
解析失败降级机制
当 OpenAPI 文档解析失败时，自动提示用户或跳过，不影响整体扫描流程
"""

from .handler import FallbackHandler, FallbackAction
from .doc_identifier import identify_and_import_openapi

__all__ = [
    "FallbackHandler",
    "FallbackAction",
    "identify_and_import_openapi",
]
