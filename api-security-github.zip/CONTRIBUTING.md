# 贡献指南 Contributing Guide

感谢您对 API Security 社区版的关注与贡献！

## 如何贡献

### 报告问题

- 使用 GitHub Issues 提交 Bug 或功能建议
- 描述清晰：复现步骤、环境信息、预期与实际行为
- 搜索已有 Issue 避免重复

### 提交代码

1. **Fork 本仓库** 并克隆到本地
2. **创建分支**：`git checkout -b feature/your-feature` 或 `fix/your-fix`
3. **编写代码**：遵循项目风格，补充必要注释
4. **运行测试**：`python -m pytest tests/ -v`
5. **提交**：`git commit -m "feat: 简短描述"`
6. **推送**：`git push origin feature/your-feature`
7. **发起 Pull Request**：说明改动目的与测试情况

### 提交信息规范

- `feat:` 新功能
- `fix:` 修复 Bug
- `docs:` 文档
- `refactor:` 重构
- `test:` 测试
- `chore:` 构建/工具

## 开发环境

```bash
# 克隆
git clone https://github.com/your-org/api-security.git
cd api-security

# 依赖
pip install -r requirements.txt
pip install -r requirements-admin.txt  # 管理后台

# 设置 PYTHONPATH
export PYTHONPATH=src  # Linux/macOS
$env:PYTHONPATH="src"  # Windows PowerShell

# 运行测试
python -m pytest tests/ -v

# 启动管理后台
python run_admin.py --port 35555
```

## 代码风格

- Python：遵循 PEP 8，建议使用 Black 格式化
- 类型注解：新代码尽量添加类型提示
- 文档字符串：公开函数/类需有 docstring

## 社区版与商业版

- 社区版（默认）：`API_SECURITY_EDITION=community`
- 商业版：`API_SECURITY_EDITION=enterprise`

贡献时请确保改动在社区版下可正常运行，不依赖商业版专属功能。

## 许可证

贡献即表示您同意将代码以 Apache 2.0 许可证授权。
