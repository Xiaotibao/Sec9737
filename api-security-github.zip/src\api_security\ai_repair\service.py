"""
AI 修复建议服务
LLM 可用时调用生成，否则降级为静态建议 + 补丁模板
"""

from pathlib import Path
from typing import Optional

from loguru import logger

from ..remediation import get_remediation
from .config import is_llm_configured
from .llm_client import call_llm
from .patch_generator import get_patch_for_finding, format_patch_as_unified


def _read_file_context(location: Optional[str], project_root: Path) -> Optional[str]:
    """尝试读取漏洞位置对应的源码片段（用于 LLM 上下文）"""
    if not location:
        return None
    # location 格式: path 或 path:line 或 path:line:col
    path_part = location.split(":")[0].strip()
    if not path_part:
        return None
    full_path = (project_root / path_part).resolve()
    if not full_path.exists() or not full_path.is_file():
        return None
    try:
        lines = full_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        # 尝试提取漏洞行附近 ±5 行
        if ":" in location:
            parts = location.split(":")
            try:
                line_num = int(parts[1])
                start = max(0, line_num - 6)
                end = min(len(lines), line_num + 5)
                snippet = "\n".join(f"{i+1}: {lines[i]}" for i in range(start, end))
                return snippet
            except (IndexError, ValueError):
                pass
        return "\n".join(lines[:30]) if lines else None
    except Exception as e:
        logger.debug(f"读取源码失败 {full_path}: {e}")
        return None


def get_ai_repair_suggestion(
    finding: dict,
    project_root: Optional[Path] = None,
) -> dict:
    """
    获取 AI 修复建议（含补丁草稿）
    返回 {
        "remediation": str,      # 修复建议文本
        "patch": dict | None,   # {"before","after","language"} 或 None
        "patch_formatted": str,  # 格式化后的补丁，便于复制
        "source": "llm" | "static",  # 来源
    }
    """
    rule_id = finding.get("rule_id")
    title = finding.get("title", "")
    description = finding.get("description", "")
    location = finding.get("location")
    owasp = finding.get("owasp_category", "")

    # 1. 补丁草稿（静态模板，至少 3 种漏洞类型支持）
    patch = get_patch_for_finding(rule_id, title)
    patch_formatted = format_patch_as_unified(patch) if patch else ""

    # 2. 修复建议：LLM 优先，否则静态
    remediation = get_remediation(rule_id, title)  # 静态兜底
    source = "static"

    if is_llm_configured():
        root = project_root or Path(".").resolve()
        code_context = _read_file_context(location, root)

        user_prompt = f"""请针对以下 API 安全漏洞给出简洁的修复建议（2-4 句话，中文）：

漏洞类型：{title}
描述：{description}
OWASP 分类：{owasp or '未知'}
位置：{location or '未知'}
"""
        if code_context:
            user_prompt += f"\n相关代码片段：\n```\n{code_context}\n```"

        system_prompt = "你是 API 安全专家。请给出具体、可操作的修复建议，避免空洞描述。若涉及代码，给出修改示例。"

        llm_text = call_llm(user_prompt, system_prompt)
        if llm_text:
            remediation = llm_text
            source = "llm"

    return {
        "remediation": remediation,
        "patch": patch,
        "patch_formatted": patch_formatted,
        "source": source,
    }
