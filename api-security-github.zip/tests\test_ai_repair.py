"""
AI 辅助修复测试
"""

import pytest
from pathlib import Path

from api_security.ai_repair import get_ai_repair_suggestion
from api_security.ai_repair.patch_generator import get_patch_for_finding, format_patch_as_unified
from api_security.ai_repair.config import get_ai_repair_config, is_llm_configured


class TestPatchGenerator:
    """补丁草稿"""

    def test_sql_injection_patch(self):
        """SQL 注入 - 有补丁"""
        p = get_patch_for_finding("api-sql-injection", "SQL injection")
        assert p is not None
        assert "before" in p and "after" in p
        assert "?" in p["after"] or "?" in str(p["after"])

    def test_hardcoded_secret_patch(self):
        """硬编码密钥 - 有补丁"""
        p = get_patch_for_finding("api-hardcoded-secret", "Hardcoded secret")
        assert p is not None
        assert "os.environ" in p["after"] or "environ" in p["after"]

    def test_missing_auth_patch(self):
        """缺失认证 - 有补丁"""
        p = get_patch_for_finding("api-missing-auth", "Missing auth")
        assert p is not None
        assert "require_auth" in p["after"] or "auth" in p["after"].lower()

    def test_unknown_no_patch(self):
        """未知类型 - 无补丁"""
        p = get_patch_for_finding("unknown-rule", "Some finding")
        assert p is None

    def test_format_patch(self):
        """补丁格式化"""
        p = {"before": "x", "after": "y", "language": "python"}
        s = format_patch_as_unified(p)
        assert "修改前" in s and "修改后" in s
        assert "x" in s and "y" in s


class TestAiRepairService:
    """AI 修复服务"""

    def test_get_suggestion_static(self):
        """未配置 LLM 时返回静态建议"""
        f = {"rule_id": "api-sql-injection", "title": "SQL injection", "description": "Risk"}
        r = get_ai_repair_suggestion(f)
        assert r["remediation"]
        assert r["source"] == "static"
        assert r["patch"] is not None
        assert r["patch_formatted"]

    def test_get_suggestion_has_patch_for_supported_types(self):
        """支持类型有补丁"""
        for rule_id in ["api-sql-injection", "api-hardcoded-secret", "api-missing-auth"]:
            r = get_ai_repair_suggestion({"rule_id": rule_id, "title": "Test"})
            assert r["patch"] is not None

    def test_get_suggestion_unknown_type(self):
        """未知类型仍有静态建议"""
        r = get_ai_repair_suggestion({"rule_id": "x", "title": "Unknown"})
        assert r["remediation"]
        assert r["source"] == "static"
        assert r["patch"] is None
