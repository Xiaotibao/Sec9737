"""
数据清理 - 用户自定义清理周期（按天/月）
保证企业数据安全，定期清理过期数据
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "scan_results"
CONFIG_FILE = DATA_DIR / "cleanup_config.json"


def get_cleanup_config() -> dict:
    """
    获取清理配置
    Returns: { "enabled": bool, "unit": "day"|"month", "value": int }
    """
    if not CONFIG_FILE.exists():
        return {"enabled": False, "unit": "day", "value": 30}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"enabled": False, "unit": "day", "value": 30}


def set_cleanup_config(enabled: bool = False, unit: str = "day", value: int = 30) -> dict:
    """
    设置清理配置
    unit: "day" 按天 | "month" 按月
    value: 保留最近 N 天/月
    """
    DATA_DIR.mkdir(exist_ok=True)
    cfg = {"enabled": enabled, "unit": unit, "value": max(1, value)}
    if cfg["unit"] not in ("day", "month"):
        cfg["unit"] = "day"
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


def _parse_scan_timestamp(filename: str) -> datetime | None:
    """从 scan_YYYYMMDD_HHMMSS.json 解析时间"""
    try:
        s = filename.replace("scan_", "").replace(".json", "")
        if "_" in s:
            return datetime.strptime(s[:15], "%Y%m%d_%H%M%S")
        return datetime.strptime(s[:8], "%Y%m%d")
    except Exception:
        return None


def cleanup_old_data() -> dict:
    """
    按配置清理过期扫描结果
    Returns: { "deleted": int, "kept": int }
    """
    cfg = get_cleanup_config()
    if not cfg.get("enabled"):
        return {"deleted": 0, "kept": 0}

    unit = cfg.get("unit", "day")
    value = cfg.get("value", 30)

    if unit == "month":
        cutoff = datetime.now() - timedelta(days=value * 30)
    else:
        cutoff = datetime.now() - timedelta(days=value)

    deleted = 0
    kept = 0

    if not RESULTS_DIR.exists():
        return {"deleted": 0, "kept": 0}

    deleted_files = []
    for f in RESULTS_DIR.glob("scan_*.json"):
        dt = _parse_scan_timestamp(f.name)
        if dt and dt < cutoff:
            try:
                f.unlink()
                deleted += 1
                deleted_files.append(f.name)
            except Exception:
                kept += 1
        else:
            kept += 1

    if deleted_files:
        try:
            from ..tenant import list_tenants
            from ..tenant.data import _tenant_path, _save_json, _load_json
            for tenant in list_tenants(include_disabled=True):
                tid = tenant.id
                meta_path = _tenant_path(tid, "scan_metadata.json")
                if not meta_path.exists():
                    continue
                meta = _load_json(meta_path, {})
                changed = False
                for name in deleted_files:
                    if name in meta:
                        meta.pop(name)
                        changed = True
                if changed:
                    _save_json(meta_path, meta)
        except Exception:
            pass

    return {"deleted": deleted, "kept": kept}
