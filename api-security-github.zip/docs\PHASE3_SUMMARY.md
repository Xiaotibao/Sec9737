# Phase 3 汇总 — 差异化与规模化

> 第 7–12 个月改造阶段，聚焦 AI 修复、API 变更、自研规则、多租户与社区版开源。

---

## 一、模块总览

| 模块 | 总工时 | 优先级 | 状态 |
|------|--------|--------|------|
| AI 辅助修复 | 14d | P0 | ✅ 已完成 |
| API 变更影响分析 | 10d | P1 | ✅ 已完成 |
| 自研规则库 | 22d | P0 | ✅ 已完成 |
| 多租户与 SSO | 21d | P1 | ✅ 已完成 |
| 社区版开源 | 12d | P1 | ✅ 已完成 |

**Phase 3 总工时**：约 79 人天

---

## 二、各模块详情

### 2.1 AI 辅助修复（P0）

**目标**：结合 LLM，对漏洞给出「一键修复建议」或补丁草稿。

| 交付物 | 路径/说明 |
|--------|-----------|
| AI 修复服务 | `src/api_security/ai_repair/`（service、patch_generator、llm_client、config） |
| 补丁类型 | SQL 注入、硬编码密钥、缺失认证等 |
| 配置与降级 | `docs/AI_REPAIR_CONFIG.md`，未配置 LLM 时使用静态建议 |
| 前端展示 | 漏洞详情中「AI 修复建议」区块、复制补丁 |

**验收**：用户可在漏洞详情中看到 AI 生成的修复建议，并可选择应用补丁。

---

### 2.2 API 变更影响分析（P1）

**目标**：OpenAPI 变更时，自动分析受影响接口与风险变化。

| 交付物 | 路径/说明 |
|--------|-----------|
| OpenAPI Diff | `src/api_security/api_change/`（diff、impact、report） |
| 高风险标记 | 认证移除、401/403 删除、敏感字段新增等 |
| 管理后台 | 「API 变更」Tab，上传对比、历史报告 |
| Webhook | Critical 变更触发 `api_change_critical` 事件 |

**验收**：用户提交新 OpenAPI 后，能收到变更影响分析与风险提示。

详见 `docs/API_CHANGE.md`。

---

### 2.3 自研规则库（P0）

**目标**：在 Semgrep/afrog 之外，建立自有 API 安全规则库。

| 交付物 | 路径/说明 |
|--------|-----------|
| 规则引擎 | `src/api_security/native_rules/`（loader、engine、schema） |
| 规则库 | 24 条规则，覆盖 IDOR、越权、硬编码、注入、日志等 |
| 规则管理 | 管理后台「自研规则」Tab，启用/禁用、自定义规则 |
| 扫描集成 | 与 Semgrep 互补，结果合并展示 |

**验收**：自研规则可独立运行并产出有效发现，与现有工具互补。

详见 `docs/NATIVE_RULES.md`。

---

### 2.4 多租户与 SSO（P1）

**目标**：支持企业级多租户与单点登录。

| 交付物 | 路径/说明 |
|--------|-----------|
| 租户模型 | `src/api_security/tenant/`（model、data、context） |
| 数据隔离 | `data/tenants/{tenant_id}/members.json`、`scan_metadata.json` |
| SSO 集成 | OIDC 登录流程（`/sso/login`、`/sso/callback`） |
| 租户管理 | 超级管理员 API（`/api/super/tenants`），创建/禁用租户 |

**验收**：多企业可独立使用，支持通过 SSO 登录。

---

### 2.5 社区版开源（P1）

**目标**：提供功能精简的社区版，吸引贡献与生态。

| 交付物 | 路径/说明 |
|--------|-----------|
| 功能拆分 | `src/api_security/edition.py`，`API_SECURITY_EDITION` 环境变量 |
| 社区版打包 | 无计费、无团队限制，`requirements-community.txt` |
| 开源协议 | Apache 2.0（`LICENSE`） |
| 贡献指南 | `CONTRIBUTING.md` |
| 发布与示例 | `docs/RELEASE.md`、`examples/sample-api`、`.github/workflows/release.yml` |

**验收**：社区版可独立安装使用，文档与示例完整。

详见 `docs/COMMUNITY_EDITION.md`。

---

## 三、技术架构概览

```
API Security
├── 核心检测
│   ├── OpenSCA / Semgrep / afrog
│   ├── 自研规则引擎（native_rules）
│   └── OpenAPI 合规核查
├── 管理后台
│   ├── 统计、漏洞筛选、导出、趋势
│   ├── 成员管理、Critical 汇总
│   ├── API 变更、自研规则、Webhook
│   └── 租户管理、SSO（商业版）
├── 版本
│   ├── 社区版（默认）：无计费、无团队限制
│   └── 商业版：套餐计费、多租户、SSO
└── 生态
    ├── CLI、VS Code 插件
    ├── GitHub Actions、GitLab CI、Jenkins
    └── 增量扫描、Webhook 告警
```

---

## 四、快速参考

| 能力 | 社区版 | 商业版 |
|------|--------|--------|
| CLI 扫描 | ✅ | ✅ |
| 管理后台 | ✅ | ✅ |
| AI 修复建议 | ✅ | ✅ |
| API 变更分析 | ✅ | ✅ |
| 自研规则 | ✅ | ✅ |
| 套餐计费 | ❌ | ✅ |
| 多租户 / SSO | ❌ | ✅ |

**启用商业版**：`export API_SECURITY_EDITION=enterprise`

---

*文档版本：v1.0 | 更新日期：2025-03*
