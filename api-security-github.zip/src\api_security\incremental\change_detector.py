"""
变更检测 - 基于 git diff 识别变更文件/接口
支持 CI 环境变量：GITHUB_BASE_REF, CI_MERGE_REQUEST_TARGET_BRANCH, GIT_PREVIOUS_COMMIT 等
"""

import subprocess
from pathlib import Path
from typing import Optional

from loguru import logger

# 可扫描的代码扩展名（Semgrep 相关）
SCANNABLE_EXT = (".py", ".js", ".ts", ".java", ".go", ".rb", ".php", ".yaml", ".yml", ".json")


def _run_git(cwd: Path, *args: str) -> tuple[bool, str]:
    """执行 git 命令，返回 (成功, 输出)"""
    try:
        r = subprocess.run(
            ["git"] + list(args),
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=30,
        )
        if r.returncode != 0:
            return False, r.stderr or ""
        return True, (r.stdout or "").strip()
    except FileNotFoundError:
        return False, "git not found"
    except subprocess.TimeoutExpired:
        return False, "git timeout"


def _is_git_repo(path: Path) -> bool:
    """判断是否为 git 仓库"""
    ok, _ = _run_git(path, "rev-parse", "--git-dir")
    return ok


def _resolve_base_ref(cwd: Path, base_ref: Optional[str] = None) -> str:
    """
    解析基准引用
    优先级：参数 > CI 环境变量 > 默认 origin/main 或 HEAD~1
    """
    if base_ref:
        return base_ref
    # CI 环境变量
    import os
    if os.environ.get("GITHUB_BASE_REF"):  # GitHub PR
        return f"origin/{os.environ['GITHUB_BASE_REF']}"
    if os.environ.get("CI_MERGE_REQUEST_TARGET_BRANCH_NAME"):  # GitLab MR
        return f"origin/{os.environ['CI_MERGE_REQUEST_TARGET_BRANCH_NAME']}"
    if os.environ.get("GIT_PREVIOUS_COMMIT"):  # Jenkins
        return os.environ["GIT_PREVIOUS_COMMIT"]
    # 默认：与 main/master 比较，若无则用 HEAD~1
    ok, branches = _run_git(cwd, "branch", "-a")
    if ok and ("main" in branches or "origin/main" in branches):
        return "origin/main"
    if ok and ("master" in branches or "origin/master" in branches):
        return "origin/master"
    return "HEAD~1"


def get_changed_files(
    target: Path,
    base_ref: Optional[str] = None,
    include_untracked: bool = False,
) -> list[Path]:
    """
    获取变更文件列表（基于 git diff）
    仅返回可扫描的代码文件

    Args:
        target: 项目根路径
        base_ref: 基准引用，如 origin/main, HEAD~1
        include_untracked: 是否包含未跟踪的新文件

    Returns:
        变更文件的绝对路径列表，若非 git 仓库则返回 []
    """
    target = Path(target).resolve()
    if target.is_file():
        cwd = target.parent
    else:
        cwd = target

    if not _is_git_repo(cwd):
        logger.warning("非 git 仓库，增量扫描将退化为全量扫描")
        return []

    ref = _resolve_base_ref(cwd, base_ref)
    changed: list[Path] = []

    # git diff --name-only base_ref..HEAD
    ok, out = _run_git(cwd, "diff", "--name-only", f"{ref}...HEAD")
    if ok and out:
        for line in out.splitlines():
            p = (cwd / line.strip()).resolve()
            if p.exists() and p.suffix.lower() in SCANNABLE_EXT:
                changed.append(p)

    if include_untracked:
        ok, out = _run_git(cwd, "ls-files", "--others", "--exclude-standard")
        if ok and out:
            for line in out.splitlines():
                p = (cwd / line.strip()).resolve()
                if p.exists() and p.suffix.lower() in SCANNABLE_EXT:
                    changed.append(p)

    return list(dict.fromkeys(changed))  # 去重


def get_changed_openapi(
    target: Path,
    base_ref: Optional[str] = None,
) -> bool:
    """
    判断 OpenAPI 文档是否变更
    若变更则需重新做合规核查

    Returns:
        True 表示有 OpenAPI 相关文件变更
    """
    target = Path(target).resolve()
    cwd = target.parent if target.is_file() else target
    if not _is_git_repo(cwd):
        return True  # 非 git 时默认全量

    ref = _resolve_base_ref(cwd, base_ref)
    ok, out = _run_git(cwd, "diff", "--name-only", f"{ref}...HEAD")
    if not ok:
        return True
    openapi_patterns = ("openapi", "swagger", ".yaml", ".yml")
    for line in (out or "").splitlines():
        f = line.lower()
        if any(p in f for p in openapi_patterns) and (f.endswith(".yaml") or f.endswith(".yml") or f.endswith(".json")):
            return True
    return False
