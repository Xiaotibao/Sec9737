# Webhook 配置指南

支持飞书、Slack、钉钉、企业微信及自定义 Webhook，在扫描完成或 Critical 漏洞发现时推送通知。

## 事件类型

| 事件 | 说明 |
|------|------|
| 扫描完成 | 每次 API 安全扫描结束时触发 |
| Critical 发现 | 扫描发现 Critical 级别漏洞时触发 |

## 平台配置

### 飞书

1. 群设置 → 群机器人 → 添加机器人 → 自定义机器人
2. 复制 Webhook 地址，格式：`https://open.feishu.cn/open-apis/bot/v2/hook/xxx`
3. 在管理后台 Webhook 页添加，平台选择「飞书」

### Slack

1. 频道设置 → 集成 → 添加入站 Webhook
2. 复制 Webhook URL，格式：`https://hooks.slack.com/services/T.../B.../xxx`
3. 在管理后台 Webhook 页添加，平台选择「Slack」

### 钉钉

1. 群设置 → 智能群助手 → 添加机器人 → 自定义
2. 复制 Webhook 地址
3. 在管理后台 Webhook 页添加，平台选择「钉钉」

### 企业微信

1. 群设置 → 群机器人 → 添加 → 复制 Webhook
2. 在管理后台 Webhook 页添加，平台选择「企业微信」

### 通用

选择「通用」时，将发送标准 JSON 格式，适配任意 HTTP 接收端：

```json
{
  "event": "scan_complete",
  "timestamp": "2024-01-01T12:00:00",
  "message": "扫描目标: .\n发现数量: 3 条\n...",
  "target": ".",
  "findings_count": 3,
  "project": "my-project",
  "passed": false
}
```

## 示例配置

### 飞书示例

```json
{
  "name": "飞书安全群",
  "url": "https://open.feishu.cn/open-apis/bot/v2/hook/your-hook-id",
  "platform": "feishu",
  "events": ["scan_complete", "critical_found"]
}
```

### Slack 示例

```json
{
  "name": "Slack #security",
  "url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXX",
  "platform": "slack",
  "events": ["scan_complete", "critical_found"]
}
```

## 测试

添加 Webhook 后，点击「测试」按钮可发送一条测试消息，用于验证配置是否正确。
