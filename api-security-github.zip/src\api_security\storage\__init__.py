"""
企业版数据加密存储
支持加密存储、解密读取、自定义数据清理周期
"""

from .crypto import encrypt_data, decrypt_data, is_encrypted, encrypt_file, decrypt_file
from .cleanup import cleanup_old_data, get_cleanup_config, set_cleanup_config

__all__ = [
    "encrypt_data",
    "decrypt_data",
    "is_encrypted",
    "encrypt_file",
    "decrypt_file",
    "cleanup_old_data",
    "get_cleanup_config",
    "set_cleanup_config",
]
