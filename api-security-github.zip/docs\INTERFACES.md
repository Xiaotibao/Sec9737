# 远期迭代接口说明文档

本文档描述 4 项低优先级功能的预留对接接口，供 Cursor 后续开发与对接使用。

---

## 1. GitLab CI 集成对接接口

### 模块路径
`src/api_security/interfaces/gitlab_ci.py`

### 接口说明

| 接口 | 说明 |
|------|------|
| `GitLabCIAdapter.adapt_env()` | 将 GitLab CI 环境变量适配为通用格式 |
| `GitLabCIAdapter.is_gitlab_ci()` | 判断当前是否在 GitLab CI 环境 |
| `GitLabCIAdapter.get_scan_context()` | 获取扫描上下文（项目路径、分支等） |

### 环境变量映射

| GitLab CI | 通用格式 |
|-----------|----------|
| CI_PROJECT_PATH | GITHUB_REPOSITORY |
| CI_COMMIT_REF_NAME | GITHUB_REF |
| CI_PIPELINE_ID | GITHUB_RUN_ID |
| CI_SERVER_URL | GITHUB_SERVER_URL |
| CI_PROJECT_DIR | GITHUB_WORKSPACE |

### 对接要点
- 兼容 `.gitlab-ci.yml` 配置规范
- 复用现有 GitHub Actions 扫描逻辑，仅需注入适配后的上下文
- 预留 `trigger_pipeline_scan()`、`parse_gitlab_ci_yml()` 扩展点

### API 占位
`GET /api/interfaces/gitlab-ci/status`

---

## 2. API 接口批量扫描功能接口

### 模块路径
`src/api_security/interfaces/batch_scan.py`

### 接口说明

| 接口 | 说明 |
|------|------|
| `BatchScanAdapter.scan_urls(urls, **kwargs)` | 批量扫描 URL 列表，返回各 URL 的 findings |
| `BatchScanAdapter.scan_urls_async(urls, **kwargs)` | 异步批量扫描，流式返回 |
| `BatchScanAdapter.validate_urls(urls)` | 校验 URL 格式，返回 (valid, invalid) |

### 预期参数
- `urls`: `list[str]` 接口地址列表
- `timeout`: 单 URL 超时（秒）
- `concurrency`: 并发数
- `auth`: 认证信息（可选）

### 返回格式（预留）
```python
[
  {"url": "https://api.example.com/users", "findings": [...], "status": "success"},
  ...
]
```

### 对接要点
- 可复用 `APIVulnerabilityDetector` 与 afrog 调用
- 需支持并发控制与超时
- 与现有单次扫描 API 无冲突

### API 占位
`GET /api/interfaces/batch-scan/status`

---

## 3. 自定义 API 安全检测规则接口

### 模块路径
`src/api_security/interfaces/custom_rules.py`

### 接口说明

| 接口 | 说明 |
|------|------|
| `CustomRulesAdapter.load_rules(path)` | 加载自定义规则文件 |
| `CustomRulesAdapter.validate_rule(rule)` | 校验单条规则格式 |
| `CustomRulesAdapter.merge_with_default(custom_rules)` | 与默认规则合并 |
| `CustomRulesAdapter.get_rules_path()` | 获取用户规则目录 |

### 规则目录
`config/custom_rules/`

### 支持格式
`.yaml` / `.yml` / `.json`，与 Semgrep 规则格式兼容

### 对接要点
- 用户上传规则文件至 `config/custom_rules/`
- 在 Semgrep 调用时传入 `--config` 指向自定义规则
- 需校验规则格式，防止注入

### API 占位
`GET /api/interfaces/custom-rules/status`

---

## 4. 复杂团队权限管理接口

### 模块路径
`src/api_security/interfaces/team_permission.py`

### 接口说明

| 接口 | 说明 |
|------|------|
| `TeamPermissionAdapter.check_permission(user_id, resource, action)` | 校验权限 |
| `TeamPermissionAdapter.get_user_roles(user_id)` | 获取用户角色 |
| `TeamPermissionAdapter.assign_role(user_id, role, resource_id)` | 分配角色 |
| `TeamPermissionAdapter.create_approval_flow(flow_type, config)` | 创建审批流程 |
| `TeamPermissionAdapter.check_approval_required(action, context)` | 判断是否需要审批 |

### 默认行为
- `check_approval_required()` 默认返回 `False`，与现有无审批逻辑兼容
- 未实现接口均抛出 `NotImplementedError`

### 预留扩展
- 角色：admin / member / viewer
- 资源：scan / export / member / config
- 操作：create / read / update / delete
- 审批流程：scan_approval、export_approval

### 对接要点
- 在现有 admin 路由中，于业务逻辑前调用 `check_permission`
- 审批流程可异步，通过状态轮询或 Webhook 回调

### API 占位
`GET /api/interfaces/team-permission/status`

---

## 兼容性说明

- 所有预留接口与现有代码无冲突
- 占位实现不执行核心逻辑，仅定义契约
- 插件入口 `api_security.plugin` 可扩展导入上述 Adapter
- 后续实现时，保持接口签名不变，仅填充实现即可

## 使用示例（后续实现后）

```python
from api_security.interfaces import GitLabCIAdapter, BatchScanAdapter

# GitLab CI
adapter = GitLabCIAdapter()
if adapter.is_gitlab_ci():
    ctx = adapter.get_scan_context()
    # 注入 ctx 到扫描流程

# 批量扫描
batch = BatchScanAdapter()
results = batch.scan_urls(["https://api.example.com/v1/users"])
```
