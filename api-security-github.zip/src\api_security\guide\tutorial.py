"""
企业版使用教程入口
管理员/开发人员端操作教程
"""

from typing import Optional

# 教程链接（可配置为外部文档或内部页面）
TUTORIAL_BASE = "/admin/#tutorial"

TUTORIAL_LINKS = {
    "admin": {
        "title": "管理员操作教程",
        "description": "团队管理、权限配置、报告导出",
        "url": f"{TUTORIAL_BASE}?role=admin",
    },
    "developer": {
        "title": "开发人员操作教程",
        "description": "扫描配置、CI/CD 集成、规则自定义",
        "url": f"{TUTORIAL_BASE}?role=developer",
    },
    "quickstart": {
        "title": "快速入门",
        "description": "5 分钟上手 API 安全扫描",
        "url": f"{TUTORIAL_BASE}?role=quickstart",
    },
}


def get_tutorial_links(role: Optional[str] = None) -> list[dict]:
    """
    获取教程入口列表
    Args:
        role: admin | developer | quickstart，空则返回全部
    """
    if role and role in TUTORIAL_LINKS:
        return [TUTORIAL_LINKS[role]]
    return list(TUTORIAL_LINKS.values())
