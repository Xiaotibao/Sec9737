"""
OpenAPI/Swagger 解析脚本
兼容 OpenAPI 2.0 (Swagger) 与 OpenAPI 3.0/3.1 全版本
支持本地文件、URL、JSON/YAML 格式
"""

import json
from pathlib import Path
from typing import Any, Optional, Union
from dataclasses import dataclass, field

import yaml
import requests
from loguru import logger

# 延迟导入，解析失败时不影响其他模块
try:
    from openapi_spec_validator import validate_spec
    from openapi_spec_validator.readers import read_from_filename, read_from_uri
    OPENAPI_AVAILABLE = True
except ImportError:
    OPENAPI_AVAILABLE = False
    validate_spec = None
    read_from_filename = None
    read_from_uri = None


@dataclass
class ParseResult:
    """解析结果数据类"""
    success: bool
    spec: Optional[dict] = None
    version: Optional[str] = None  # "2.0" | "3.0" | "3.1"
    source: Optional[str] = None
    error: Optional[str] = None
    raw_content: Optional[str] = None


@dataclass
class ComplianceResult:
    """合规核查结果"""
    missing_security: list[str] = field(default_factory=list)
    sensitive_fields_in_response: list[dict] = field(default_factory=list)
    missing_auth_errors: list[str] = field(default_factory=list)
    passed: bool = True


class OpenAPIParser:
    """
    OpenAPI/Swagger 文档解析器
    支持 2.0、3.0、3.1 版本，自动识别文档格式
    """

    # 支持的文档扩展名
    SUPPORTED_EXTENSIONS = (".yaml", ".yml", ".json")
    # OpenAPI 版本标识字段
    VERSION_KEYS = {
        "swagger": "2.0",
        "openapi": None,  # 需从值读取 "3.0.0" -> "3.0"
    }

    def __init__(self, strict_validation: bool = False):
        """
        Args:
            strict_validation: 是否严格验证规范，False 时允许部分非标准文档
        """
        self.strict_validation = strict_validation

    def parse(self, source: Union[str, Path]) -> ParseResult:
        """
        解析 OpenAPI/Swagger 文档
        支持: 本地文件路径、HTTP(S) URL

        Args:
            source: 文件路径或 URL

        Returns:
            ParseResult: 解析结果，含 spec 字典与版本信息
        """
        source_str = str(source).strip()
        if not source_str:
            return ParseResult(success=False, error="源路径为空")

        # 判断来源类型
        if source_str.startswith(("http://", "https://")):
            return self._parse_from_url(source_str)
        return self._parse_from_file(source_str)

    def _parse_from_file(self, path: str) -> ParseResult:
        """从本地文件解析"""
        p = Path(path)
        if not p.exists():
            return ParseResult(success=False, error=f"文件不存在: {path}")

        if p.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            return ParseResult(
                success=False,
                error=f"不支持的文件格式，请使用 .yaml/.yml/.json: {p.suffix}",
            )

        try:
            raw = p.read_text(encoding="utf-8", errors="replace")
            spec = self._load_spec(raw, p.suffix)
            if spec is None:
                return ParseResult(
                    success=False,
                    error="文档格式解析失败，请检查是否为有效的 JSON/YAML",
                    raw_content=raw[:500],
                )
            return self._normalize_and_validate(spec, path)
        except Exception as e:
            logger.exception(f"解析文件失败: {path}")
            return ParseResult(
                success=False,
                error=str(e),
                source=path,
            )

    def _parse_from_url(self, url: str) -> ParseResult:
        """从 URL 解析"""
        try:
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            raw = resp.text
            suffix = ".json" if "json" in resp.headers.get("content-type", "") else ".yaml"
            spec = self._load_spec(raw, suffix)
            if spec is None:
                return ParseResult(
                    success=False,
                    error="远程文档格式解析失败",
                    source=url,
                )
            return self._normalize_and_validate(spec, url)
        except requests.RequestException as e:
            return ParseResult(success=False, error=str(e), source=url)
        except Exception as e:
            logger.exception(f"解析 URL 失败: {url}")
            return ParseResult(success=False, error=str(e), source=url)

    def _load_spec(self, raw: str, suffix: str) -> Optional[dict]:
        """根据格式加载为字典"""
        try:
            if suffix.lower() == ".json":
                return json.loads(raw)
            return yaml.safe_load(raw)
        except (json.JSONDecodeError, yaml.YAMLError):
            # 尝试另一种格式
            try:
                if suffix.lower() == ".json":
                    return yaml.safe_load(raw)
                return json.loads(raw)
            except Exception:
                return None

    def _detect_version(self, spec: dict) -> Optional[str]:
        """检测 OpenAPI 版本"""
        if "swagger" in spec:
            return "2.0"
        if "openapi" in spec:
            v = str(spec["openapi"])
            if v.startswith("3.0"):
                return "3.0"
            if v.startswith("3.1"):
                return "3.1"
            return v.split(".")[0] + "." + v.split(".")[1] if "." in v else v
        return None

    def _normalize_and_validate(self, spec: dict, source: str) -> ParseResult:
        """规范化并可选验证"""
        version = self._detect_version(spec)
        if not version:
            return ParseResult(
                success=False,
                spec=spec,
                error="无法识别 OpenAPI/Swagger 版本，需包含 swagger 或 openapi 字段",
                source=source,
            )

        if self.strict_validation and OPENAPI_AVAILABLE:
            try:
                validate_spec(spec)
            except Exception as e:
                return ParseResult(
                    success=False,
                    spec=spec,
                    version=version,
                    error=f"规范验证失败: {e}",
                    source=source,
                )

        return ParseResult(
            success=True,
            spec=spec,
            version=version,
            source=source,
        )

    def is_openapi_document(self, content: str) -> bool:
        """
        快速判断内容是否为 OpenAPI/Swagger 文档
        用于自动识别与导入
        """
        try:
            # 优先尝试 YAML（openapi: / swagger: 开头），否则 JSON
            stripped = (content or "").strip()[:100]
            if stripped.startswith("{") or (stripped.startswith("[") and "{" not in stripped[:20]):
                data = json.loads(content)
            else:
                data = yaml.safe_load(content)
            if isinstance(data, dict):
                return "swagger" in data or "openapi" in data
        except Exception:
            pass
        return False


def parse_openapi(source: Union[str, Path], strict: bool = False) -> ParseResult:
    """
    可直接调用的解析函数

    Args:
        source: 文件路径或 URL
        strict: 是否严格验证

    Returns:
        ParseResult
    """
    return OpenAPIParser(strict_validation=strict).parse(source)
