"""
Webhook 配置 API
"""

from flask import Blueprint, request, jsonify

from .webhook_config import (
    get_webhooks,
    add_webhook,
    update_webhook,
    delete_webhook,
    EVENT_SCAN_COMPLETE,
    EVENT_CRITICAL_FOUND,
    PLATFORM_GENERIC,
    PLATFORM_FEISHU,
    PLATFORM_SLACK,
    PLATFORM_DINGTALK,
    PLATFORM_WECOM,
)
from .webhook_sender import build_payload, send_webhook, trigger_webhooks

webhook_bp = Blueprint("webhook", __name__, url_prefix="/api/admin")


@webhook_bp.route("/webhooks", methods=["GET"])
def list_webhooks():
    """获取所有 Webhook 配置"""
    return jsonify({"webhooks": get_webhooks()})


@webhook_bp.route("/webhooks", methods=["POST"])
def create_webhook():
    """
    新增 Webhook
    Body: { "name": "", "url": "", "events": ["scan_complete"], "platform": "generic", "headers": {} }
    """
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    url = (data.get("url") or "").strip()
    events = data.get("events") or [EVENT_SCAN_COMPLETE]
    platform = data.get("platform") or PLATFORM_GENERIC
    headers = data.get("headers")
    if not name or not url:
        return jsonify({"success": False, "error": "name and url required"}), 400
    if not url.startswith(("http://", "https://")):
        return jsonify({"success": False, "error": "url must start with http:// or https://"}), 400
    w = add_webhook(name=name, url=url, events=events, platform=platform, headers=headers)
    return jsonify({"success": True, "webhook": w})


@webhook_bp.route("/webhooks/<wh_id>", methods=["PUT"])
def update_webhook_route(wh_id):
    """更新 Webhook"""
    data = request.get_json() or {}
    kwargs = {}
    if "name" in data:
        kwargs["name"] = (data.get("name") or "").strip()
    if "url" in data:
        kwargs["url"] = (data.get("url") or "").strip()
    if "events" in data:
        kwargs["events"] = data.get("events")
    if "platform" in data:
        kwargs["platform"] = data.get("platform")
    if "headers" in data:
        kwargs["headers"] = data.get("headers")
    if "enabled" in data:
        kwargs["enabled"] = bool(data.get("enabled"))
    w = update_webhook(wh_id, **kwargs)
    if not w:
        return jsonify({"success": False, "error": "not found"}), 404
    return jsonify({"success": True, "webhook": w})


@webhook_bp.route("/webhooks/<wh_id>", methods=["DELETE"])
def delete_webhook_route(wh_id):
    """删除 Webhook"""
    if not delete_webhook(wh_id):
        return jsonify({"success": False, "error": "not found"}), 404
    return jsonify({"success": True})


@webhook_bp.route("/webhooks/<wh_id>/test", methods=["POST"])
def test_webhook(wh_id):
    """测试发送 Webhook"""
    webhooks = get_webhooks()
    w = next((x for x in webhooks if x.get("id") == wh_id), None)
    if not w:
        return jsonify({"success": False, "error": "not found"}), 404
    url = w.get("url", "").strip()
    if not url:
        return jsonify({"success": False, "error": "url empty"}), 400
    platform = w.get("platform", PLATFORM_GENERIC)
    ctx = {
        "message": "这是一条测试消息，来自 API 安全管理后台。",
        "target": "test",
        "findings_count": 0,
        "project": "test",
        "scan_file": "test",
        "passed": True,
    }
    payload = build_payload(platform, EVENT_SCAN_COMPLETE, ctx)
    ok, err = send_webhook(url, payload, w.get("headers"))
    return jsonify({"success": ok, "error": err})


@webhook_bp.route("/webhooks/templates", methods=["GET"])
def get_templates():
    """获取飞书、Slack 等示例配置"""
    return jsonify({
        "platforms": [
            {"id": PLATFORM_GENERIC, "name": "通用", "desc": "标准 JSON 格式，适配任意 HTTP 接收端"},
            {"id": PLATFORM_FEISHU, "name": "飞书", "desc": "飞书群机器人 Webhook"},
            {"id": PLATFORM_SLACK, "name": "Slack", "desc": "Slack Incoming Webhook"},
            {"id": PLATFORM_DINGTALK, "name": "钉钉", "desc": "钉钉群机器人 Webhook"},
            {"id": PLATFORM_WECOM, "name": "企业微信", "desc": "企业微信群机器人 Webhook"},
        ],
        "events": [
            {"id": EVENT_SCAN_COMPLETE, "name": "扫描完成"},
            {"id": EVENT_CRITICAL_FOUND, "name": "Critical 漏洞发现"},
        ],
        "examples": {
            "feishu": {
                "url": "https://open.feishu.cn/open-apis/bot/v2/hook/xxx",
                "platform": "feishu",
                "events": [EVENT_SCAN_COMPLETE, EVENT_CRITICAL_FOUND],
            },
            "slack": {
                "url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXX",
                "platform": "slack",
                "events": [EVENT_SCAN_COMPLETE, EVENT_CRITICAL_FOUND],
            },
        },
    })
