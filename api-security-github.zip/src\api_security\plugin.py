"""
Cursor 插件入口 - 可直接集成的插件代码
提供统一调用接口，适配 Cursor 编程环境的调试与集成

检测能力：覆盖 OWASP API Top10 常见漏洞类型
合规核查：基于 OpenAPI/Swagger 的 API 设计合规轻量核查
"""

from pathlib import Path
from typing import Optional

from .core.scanner import run_api_scan
from .parser import OpenAPIParser, ComplianceChecker
from .fallback import FallbackHandler, FallbackAction, identify_and_import_openapi


def scan(
    target: str | Path,
    openapi: Optional[str | Path] = None,
    afrog_url: Optional[str] = None,
    skip_openapi_on_fail: bool = True,
    project: str = "",
) -> dict:
    """
    插件主入口 - 执行 API 安全扫描（可直接调用）
    返回含 alerts（高危漏洞提醒）的扫描结果

    Args:
        target: 扫描目标路径
        openapi: OpenAPI 文档路径
        afrog_url: afrog 扫描 URL
        skip_openapi_on_fail: 解析失败时是否跳过
        project: 项目名，用于弹窗频率限制

    Returns:
        扫描结果字典，含 detection、alerts（critical_popups, high_notifications）
    """
    return run_api_scan(
        target=target,
        openapi=openapi,
        afrog_url=afrog_url,
        skip_openapi_on_fail=skip_openapi_on_fail,
        auto_identify_openapi=True,
        project=project,
    )


def parse_openapi(source: str | Path) -> tuple[bool, Optional[dict], Optional[object]]:
    """
    解析 OpenAPI 文档（带降级）

    Returns:
        (success, spec_dict, compliance_result)
    """
    handler = FallbackHandler(on_failure=FallbackAction.SKIP)
    result, compliance = handler.parse_with_fallback(source)
    return result.success, result.spec, compliance


def identify_openapi(search_path: str | Path) -> Optional[dict]:
    """
    自动识别并导入 OpenAPI 文档

    Returns:
        解析成功返回 spec 字典，否则 None
    """
    parse_result = identify_and_import_openapi(search_path)
    return parse_result.spec if parse_result and parse_result.success else None


from .filter import filter_findings
from .report import get_trend_data, generate_trend_chart_svg
from .interfaces import GitLabCIAdapter, BatchScanAdapter, CustomRulesAdapter, TeamPermissionAdapter
from .billing import PermissionChecker, BillingAdapter, get_enterprise_plan
from .guide import get_upgrade_prompt, is_high_intent_user, get_tutorial_links
from .guide.upgrade_prompt import get_upgrade_url, get_critical_upgrade_cta
from .guide.high_intent import get_presale_prompt
from .risk_control import (
    PUBLIC_CAPABILITY_DESC,
    DETECTION_SCOPE,
    COMPLIANCE_SCOPE,
    TOOL_DISCLAIMER,
)

__all__ = [
    "scan",
    "parse_openapi",
    "identify_openapi",
    "filter_findings",
    "get_trend_data",
    "generate_trend_chart_svg",
    "GitLabCIAdapter",
    "BatchScanAdapter",
    "CustomRulesAdapter",
    "TeamPermissionAdapter",
    "PermissionChecker",
    "BillingAdapter",
    "get_enterprise_plan",
    "get_upgrade_prompt",
    "get_upgrade_url",
    "get_critical_upgrade_cta",
    "is_high_intent_user",
    "get_presale_prompt",
    "get_tutorial_links",
    "PUBLIC_CAPABILITY_DESC",
    "DETECTION_SCOPE",
    "COMPLIANCE_SCOPE",
    "TOOL_DISCLAIMER",
]
