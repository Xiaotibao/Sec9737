"""
AI 辅助修复 - 结合 LLM 生成修复建议与补丁草稿
未配置 LLM 时降级为静态建议
"""

from .service import get_ai_repair_suggestion

__all__ = ["get_ai_repair_suggestion"]
