"""
自定义 API 安全检测规则接口 - 预留
支持后续用户上传自定义规则文件并接入检测流程
"""

from pathlib import Path
from typing import Any

# 预留：支持的规则格式
SUPPORTED_RULE_FORMATS = ("yaml", "yml", "json")


class CustomRulesAdapter:
    """
    自定义规则适配器 - 预留接口
    支持用户上传规则文件，接入 Semgrep/自定义引擎
    """

    def load_rules(self, path: str | Path) -> list[dict]:
        """
        加载自定义规则文件（预留）
        Args:
            path: 规则文件路径，支持 .yaml/.yml/.json
        Returns:
            解析后的规则列表，格式与 Semgrep 规则兼容
        """
        raise NotImplementedError("自定义规则加载待迭代实现")

    def validate_rule(self, rule: dict) -> tuple[bool, str]:
        """
        校验规则格式（预留）
        Returns:
            (is_valid, error_message)
        """
        if not isinstance(rule, dict):
            return False, "规则须为 dict"
        if "id" not in rule and "rules" not in rule:
            return False, "规则须含 id 或 rules"
        return True, ""

    def merge_with_default(self, custom_rules: list[dict]) -> list[dict]:
        """
        将自定义规则与默认规则合并（预留）
        后续可控制优先级、去重等
        """
        raise NotImplementedError("规则合并待迭代实现")

    def get_rules_path(self) -> Path:
        """获取用户规则目录路径（预留）"""
        from pathlib import Path
        root = Path(__file__).resolve().parents[2]
        return root / "config" / "custom_rules"
