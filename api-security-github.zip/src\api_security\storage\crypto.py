"""
数据加密存储
使用 Fernet 对称加密，保证企业数据安全
"""

import base64
import json
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
KEY_FILE = DATA_DIR / ".encryption_key"

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    Fernet = None

# 加密数据前缀，用于识别
ENCRYPTED_PREFIX = "ENC:"


def _get_or_create_key() -> bytes:
    """获取或创建加密密钥"""
    DATA_DIR.mkdir(exist_ok=True)
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    return key


def encrypt_data(data: str | dict | list) -> str:
    """
    加密数据
    支持 str、dict、list，自动 JSON 序列化
    """
    if not CRYPTO_AVAILABLE:
        return json.dumps(data, ensure_ascii=False) if isinstance(data, (dict, list)) else str(data)

    raw = json.dumps(data, ensure_ascii=False) if isinstance(data, (dict, list)) else str(data)
    f = Fernet(_get_or_create_key())
    encrypted = f.encrypt(raw.encode("utf-8"))
    return ENCRYPTED_PREFIX + base64.urlsafe_b64encode(encrypted).decode("ascii")


def decrypt_data(encrypted: str) -> str | dict | list:
    """
    解密数据
    自动检测是否加密，未加密则原样返回
    """
    if not encrypted or not encrypted.startswith(ENCRYPTED_PREFIX):
        try:
            return json.loads(encrypted)
        except Exception:
            return encrypted

    if not CRYPTO_AVAILABLE:
        return encrypted

    try:
        payload = base64.urlsafe_b64decode(encrypted[len(ENCRYPTED_PREFIX) :].encode("ascii"))
        f = Fernet(_get_or_create_key())
        raw = f.decrypt(payload).decode("utf-8")
        try:
            return json.loads(raw)
        except Exception:
            return raw
    except Exception:
        return encrypted


def is_encrypted(content: str) -> bool:
    """判断内容是否已加密"""
    return bool(content and content.startswith(ENCRYPTED_PREFIX))


def encrypt_file(path: Path, data: dict | list) -> None:
    """加密并写入文件"""
    path.parent.mkdir(parents=True, exist_ok=True)
    encrypted = encrypt_data(data)
    path.write_text(encrypted, encoding="utf-8")


def decrypt_file(path: Path) -> str | dict | list:
    """读取并解密文件"""
    if not path.exists():
        return {} if "metadata" in str(path) or "members" in str(path) else []
    raw = path.read_text(encoding="utf-8")
    return decrypt_data(raw)
