"""
兼容 setuptools 安装
pip install -e .
"""

from setuptools import setup, find_packages

setup(
    name="api-security-enterprise",
    version="1.0.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.10",
    install_requires=[
        "openapi-spec-validator>=0.7.0",
        "PyYAML>=6.0",
        "requests>=2.28.0",
        "semgrep>=1.45.0",
        "python-dotenv>=1.0.0",
        "loguru>=0.7.0",
        "flask>=3.0.0",
        "flask-cors>=4.0.0",
    ],
    entry_points={
        "console_scripts": [
            "api-security=api_security.cli:main",
        ],
    },
)
