"""
OWASP API Security Top 10 2023 覆盖模块
将检测结果映射到 OWASP API Top 10 类别，支持文档与测试追溯
"""

from .mapping import (
    OWASP_API_TOP10,
    get_owasp_category_from_rule_id,
    get_owasp_category_from_compliance,
    compliance_to_findings,
)

__all__ = [
    "OWASP_API_TOP10",
    "get_owasp_category_from_rule_id",
    "get_owasp_category_from_compliance",
    "compliance_to_findings",
]
