"""
通用 Webhook 发送 - 支持自定义 Header、Body 模板
飞书、Slack、钉钉、企业微信、通用格式
"""

import json
from datetime import datetime
from typing import Any, Optional

try:
    import requests
except ImportError:
    requests = None

from .webhook_config import (
    get_webhooks_for_event,
    EVENT_SCAN_COMPLETE,
    EVENT_CRITICAL_FOUND,
    EVENT_API_CHANGE_CRITICAL,
    PLATFORM_GENERIC,
    PLATFORM_FEISHU,
    PLATFORM_SLACK,
    PLATFORM_DINGTALK,
    PLATFORM_WECOM,
)


def _build_payload_generic(event: str, context: dict) -> dict:
    """通用 JSON 格式"""
    return {
        "event": event,
        "timestamp": datetime.now().isoformat(),
        "message": context.get("message", ""),
        **{k: v for k, v in context.items() if k != "message"},
    }


def _build_payload_feishu(event: str, context: dict) -> dict:
    """飞书机器人 Webhook 格式 - 简单文本"""
    if event == EVENT_SCAN_COMPLETE:
        title = "API 安全扫描"
    elif event == EVENT_API_CHANGE_CRITICAL:
        title = "API 变更 Critical 风险"
    else:
        title = "Critical 漏洞发现"
    content = f"{title}\n\n{context.get('message', '')}"
    if event == EVENT_CRITICAL_FOUND:
        vulns = context.get("critical_findings", [])
        for v in vulns[:5]:
            content += f"\n- {v.get('title', v.get('vuln_name', ''))}"
    return {"msg_type": "text", "content": {"text": content}}


def _build_payload_slack(event: str, context: dict) -> dict:
    """Slack Incoming Webhook 格式"""
    title = "API Security Scan" if event == EVENT_SCAN_COMPLETE else "Critical Vulnerability Found"
    color = "#36a64f" if context.get("findings_count", 0) == 0 else "#dc3545"
    text = context.get("message", "")
    return {
        "attachments": [
            {
                "color": color,
                "title": title,
                "text": text,
                "footer": "API Security",
                "ts": int(datetime.now().timestamp()),
            }
        ]
    }


def _build_payload_dingtalk(event: str, context: dict) -> dict:
    """钉钉机器人格式"""
    title = "API 安全扫描" if event == EVENT_SCAN_COMPLETE else "Critical 漏洞发现"
    text = context.get("message", "")
    return {
        "msgtype": "markdown",
        "markdown": {"title": title, "text": f"## {title}\n\n{text}"},
    }


def _build_payload_wecom(event: str, context: dict) -> dict:
    """企业微信机器人格式"""
    content = context.get("message", "")
    return {"msgtype": "markdown", "markdown": {"content": content}}


def build_payload(platform: str, event: str, context: dict) -> dict:
    """按平台构建请求体"""
    builders = {
        PLATFORM_GENERIC: _build_payload_generic,
        PLATFORM_FEISHU: _build_payload_feishu,
        PLATFORM_SLACK: _build_payload_slack,
        PLATFORM_DINGTALK: _build_payload_dingtalk,
        PLATFORM_WECOM: _build_payload_wecom,
    }
    fn = builders.get(platform, _build_payload_generic)
    return fn(event, context)


def send_webhook(url: str, payload: dict, headers: Optional[dict] = None, timeout: int = 10) -> tuple[bool, str]:
    """
    发送 Webhook POST 请求
    Returns: (success, error_message)
    """
    if not requests:
        return False, "requests not installed"
    h = {"Content-Type": "application/json", **(headers or {})}
    try:
        resp = requests.post(url, json=payload, headers=h, timeout=timeout)
        if 200 <= resp.status_code < 300:
            return True, ""
        return False, f"HTTP {resp.status_code}: {resp.text[:200]}"
    except Exception as e:
        return False, str(e)


def trigger_webhooks(event: str, context: dict) -> list[dict]:
    """
    触发指定事件的所有 Webhook
    context 示例:
      scan_complete: { target, findings_count, project, scan_file, passed }
      critical_found: { message, critical_findings: [{ vuln_name, title, ... }], project }
    Returns: [{ webhook_id, success, error }]
    """
    results = []
    webhooks = get_webhooks_for_event(event)
    for w in webhooks:
        url = w.get("url", "").strip()
        if not url or not url.startswith(("http://", "https://")):
            results.append({"webhook_id": w.get("id"), "success": False, "error": "invalid url"})
            continue
        platform = w.get("platform", PLATFORM_GENERIC)
        payload = build_payload(platform, event, context)
        ok, err = send_webhook(url, payload, w.get("headers"))
        results.append({"webhook_id": w.get("id"), "success": ok, "error": err or None})
    return results
