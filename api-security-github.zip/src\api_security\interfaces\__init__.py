"""
低优先级远期迭代 - 标准化对接接口预留
不实现核心逻辑，仅提供可扩展的接口定义与占位实现
"""

from .gitlab_ci import GitLabCIAdapter, GITLAB_CI_VARS
from .batch_scan import BatchScanAdapter
from .custom_rules import CustomRulesAdapter
from .team_permission import TeamPermissionAdapter

__all__ = [
    "GitLabCIAdapter",
    "GITLAB_CI_VARS",
    "BatchScanAdapter",
    "CustomRulesAdapter",
    "TeamPermissionAdapter",
]
