"""
API 变更 - 存储上次 OpenAPI 与变更报告
"""

import json
from pathlib import Path
from typing import Optional

from ..admin.models import DATA_DIR

API_CHANGE_DIR = DATA_DIR / "api_change"
OPENAPI_BASELINE_FILE = API_CHANGE_DIR / "openapi_baseline.json"
REPORTS_DIR = API_CHANGE_DIR / "reports"


def _ensure_dir():
    API_CHANGE_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(exist_ok=True)


def save_baseline_openapi(spec: dict, project: str = "", source: str = "") -> None:
    """保存基准 OpenAPI（用于下次对比）"""
    _ensure_dir()
    data = {
        "spec": spec,
        "project": project,
        "source": source,
        "saved_at": __import__("datetime").datetime.now().isoformat(),
    }
    OPENAPI_BASELINE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_baseline_openapi() -> Optional[dict]:
    """加载基准 OpenAPI，返回 { spec, project, source } 或 None"""
    if not OPENAPI_BASELINE_FILE.exists():
        return None
    try:
        data = json.loads(OPENAPI_BASELINE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def save_change_report(report: dict) -> str:
    """保存变更报告，返回报告 ID"""
    _ensure_dir()
    ts = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
    report_id = f"api_change_{ts}"
    path = REPORTS_DIR / f"{report_id}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report_id


def load_change_report(report_id: str) -> Optional[dict]:
    """加载变更报告"""
    path = REPORTS_DIR / f"{report_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def list_change_reports(limit: int = 20) -> list[dict]:
    """列出最近的变更报告"""
    if not REPORTS_DIR.exists():
        return []
    files = sorted(REPORTS_DIR.glob("api_change_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    result = []
    for p in files[:limit]:
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            result.append({
                "id": p.stem,
                "timestamp": data.get("timestamp", ""),
                "project": data.get("project", ""),
                "has_critical": data.get("has_critical", False),
                "summary": data.get("summary", {}),
            })
        except Exception:
            pass
    return result
