#!/usr/bin/env python3
"""
扫描启动脚本 - 自动设置 PYTHONPATH，解决 ModuleNotFoundError
用法: python run_scan.py scan . --output scan-result.json
      python run_scan.py scan . --incremental --output scan-result.json
"""
import sys
import os
from pathlib import Path

# 切换到脚本所在目录
os.chdir(Path(__file__).resolve().parent)

# 将 src 加入路径
root = Path(__file__).resolve().parent
src = root / "src"
if str(src) not in sys.path:
    sys.path.insert(0, str(src))

if __name__ == "__main__":
    from api_security.cli import main
    sys.exit(main())
