"""
代码补丁草稿 - 针对常见漏洞类型的静态补丁模板
支持 SQL 注入、硬编码密钥、缺失认证 等
"""

from typing import Optional

# rule_id / title 关键词 -> (before_snippet, after_snippet, language)
PATCH_TEMPLATES = {
    # SQL 注入 - Python
    "api-sql-injection": (
        "cursor.execute(f\"SELECT * FROM users WHERE id = {user_id}\")",
        "cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        "python",
    ),
    "owasp-api8-sql-injection": (
        "cursor.execute(f\"SELECT * FROM users WHERE id = {user_id}\")",
        "cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        "python",
    ),
    # SQL 注入 - Node.js
    "sql-node": (
        "db.query(`SELECT * FROM users WHERE id = ${userId}`)",
        "db.query('SELECT * FROM users WHERE id = ?', [userId])",
        "javascript",
    ),
    # 硬编码密钥
    "api-hardcoded-secret": (
        'api_key = "sk-xxxxxxxxxxxxxxxx"',
        "import os\napi_key = os.environ.get('API_KEY', '')",
        "python",
    ),
    "owasp-api2-hardcoded-credentials": (
        'password = "mysecret123"',
        "import os\npassword = os.environ.get('DB_PASSWORD', '')",
        "python",
    ),
    # 缺失认证 - Python Flask
    "api-missing-auth": (
        "@app.route('/api/users')\ndef get_users():",
        "@app.route('/api/users')\n@require_auth\ndef get_users():",
        "python",
    ),
    "owasp-api5-missing-auth-decorator": (
        "@app.route('/api/admin')\ndef admin():",
        "@app.route('/api/admin')\n@require_auth\n@require_role('admin')\ndef admin():",
        "python",
    ),
    # 缺失认证 - Express
    "missing-auth-express": (
        "app.get('/api/users', (req, res) => {",
        "app.get('/api/users', authMiddleware, (req, res) => {",
        "javascript",
    ),
}

# 按 title 关键词匹配 (keyword, patch_tuple)
TITLE_PATCH_KEYWORDS = [
    ("sql injection", PATCH_TEMPLATES["api-sql-injection"]),
    ("injection", PATCH_TEMPLATES["api-sql-injection"]),
    ("硬编码", PATCH_TEMPLATES["api-hardcoded-secret"]),
    ("hardcoded", PATCH_TEMPLATES["api-hardcoded-secret"]),
    ("secret", PATCH_TEMPLATES["api-hardcoded-secret"]),
    ("password", PATCH_TEMPLATES["owasp-api2-hardcoded-credentials"]),
    ("认证", PATCH_TEMPLATES["api-missing-auth"]),
    ("missing auth", PATCH_TEMPLATES["api-missing-auth"]),
    ("auth", PATCH_TEMPLATES["api-missing-auth"]),
]


def get_patch_for_finding(
    rule_id: Optional[str],
    title: Optional[str],
) -> Optional[dict]:
    """
    根据漏洞类型获取补丁草稿
    返回 {"before": str, "after": str, "language": str} 或 None
    """
    if rule_id and rule_id in PATCH_TEMPLATES:
        before, after, lang = PATCH_TEMPLATES[rule_id]
        return {"before": before, "after": after, "language": lang}

    title_lower = (title or "").lower()
    for kw, patch in TITLE_PATCH_KEYWORDS:
        if kw in title_lower:
            before, after, lang = patch
            return {"before": before, "after": after, "language": lang}

    return None


def format_patch_as_unified(patch: dict) -> str:
    """将补丁格式化为 unified diff 风格，便于复制应用"""
    b = patch.get("before", "")
    a = patch.get("after", "")
    lang = patch.get("language", "text")
    return f"""# 补丁草稿 ({lang})
# 请根据实际代码调整后应用

# 修改前（存在风险）:
{b}

# 修改后（建议）:
{a}
"""
