"""
企业版升级入口与价值提示
检测到 API 漏洞时，针对性弹出团队版价值提示
"""

from typing import Optional

# Critical 漏洞：团队版可统一管理整改
CRITICAL_UPGRADE_CTA = "团队版可统一管理整改，了解详情→"
CRITICAL_VALUE_MSG = "【生产环境高危风险提醒】检测到{vuln_name}漏洞，可能导致数据泄露/服务崩溃，团队版可统一管理整改，了解详情→"

# High 漏洞价值提示
HIGH_VALUE_MSG = "团队版支持批量管理漏洞，统一跟踪整改进度"

# 企业版购买页路径（相对）
UPGRADE_PAGE_PATH = "/admin/#billing"


def get_upgrade_prompt(severity: str, vuln_name: str = "") -> str:
    """
    根据漏洞等级获取升级价值提示文案
    Args:
        severity: critical | high | medium | low
        vuln_name: 漏洞名称
    """
    if severity == "critical":
        return CRITICAL_VALUE_MSG.format(vuln_name=vuln_name or "高危")
    if severity == "high":
        return f"{vuln_name or 'High'} 漏洞：{HIGH_VALUE_MSG}"
    return "升级企业版，享受批量管理、CI/CD 集成等专属功能"


def get_critical_upgrade_cta() -> str:
    """Critical 漏洞弹窗中的升级 CTA 文案"""
    return CRITICAL_UPGRADE_CTA


def get_upgrade_url(base_url: str = "") -> str:
    """获取企业版购买页完整 URL"""
    return f"{base_url.rstrip('/')}{UPGRADE_PAGE_PATH}" if base_url else UPGRADE_PAGE_PATH
