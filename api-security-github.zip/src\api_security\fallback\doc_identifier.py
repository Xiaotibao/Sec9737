"""
规范文档的自动识别与导入
支持从目录、URL 列表中识别 OpenAPI/Swagger 文档并导入
"""

import json
from pathlib import Path
from typing import Optional

import yaml
from loguru import logger

from ..parser.openapi_parser import OpenAPIParser, ParseResult

# 常见 OpenAPI 文档文件名
COMMON_NAMES = (
    "openapi.yaml", "openapi.yml", "openapi.json",
    "swagger.yaml", "swagger.yml", "swagger.json",
    "api-spec.yaml", "api-spec.yml", "api-spec.json",
)


def identify_and_import_openapi(
    search_path: str | Path,
    recursive: bool = True,
) -> Optional[ParseResult]:
    """
    在指定路径下自动识别 OpenAPI/Swagger 文档并解析

    Args:
        search_path: 搜索目录或文件
        recursive: 是否递归子目录

    Returns:
        解析成功返回 ParseResult，否则 None
    """
    path = Path(search_path)
    parser = OpenAPIParser(strict_validation=False)

    if path.is_file():
        if _is_likely_openapi(path):
            return parser.parse(path)
        return None

    if not path.is_dir():
        return None

    # 优先检查常见文件名
    for name in COMMON_NAMES:
        candidate = path / name
        if candidate.exists():
            result = parser.parse(candidate)
            if result.success:
                logger.info(f"自动识别到 OpenAPI 文档: {candidate}")
                return result

    # 遍历目录
    pattern = "**/*" if recursive else "*"
    for f in path.glob(pattern):
        if not f.is_file():
            continue
        if f.suffix.lower() not in (".yaml", ".yml", ".json"):
            continue
        if not _is_likely_openapi(f):
            continue
        result = parser.parse(f)
        if result.success:
            logger.info(f"自动识别到 OpenAPI 文档: {f}")
            return result

    return None


def _is_likely_openapi(file_path: Path) -> bool:
    """快速判断文件是否为 OpenAPI 文档"""
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
        return OpenAPIParser().is_openapi_document(content)
    except Exception:
        return False


def import_from_content(content: str) -> Optional[ParseResult]:
    """
    从字符串内容导入并解析
    用于用户上传的文档内容

    Args:
        content: YAML 或 JSON 格式的文档内容

    Returns:
        解析成功返回 ParseResult
    """
    parser = OpenAPIParser(strict_validation=False)
    if not parser.is_openapi_document(content):
        return None

    try:
        data = yaml.safe_load(content) if "{" not in content[:100] else json.loads(content)
        if not isinstance(data, dict):
            return None
        version = "2.0" if "swagger" in data else "3.0"
        return ParseResult(success=True, spec=data, version=version)
    except Exception:
        return None
