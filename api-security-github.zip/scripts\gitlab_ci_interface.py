#!/usr/bin/env python3
"""
GitLab CI 对接接口 - 预留
暂不开发，仅预留代码对接入口
后续可在此接入 GitLab CI 变量与流水线逻辑
"""

# GitLab CI 环境变量映射（预留）
GITLAB_CI_VARS = {
    "CI_PROJECT_PATH": "GITHUB_REPOSITORY",
    "CI_COMMIT_REF_NAME": "GITHUB_REF",
    "CI_PIPELINE_ID": "GITHUB_RUN_ID",
    "CI_SERVER_URL": "GITHUB_SERVER_URL",
}


def adapt_for_gitlab() -> dict:
    """
    将 GitLab CI 变量适配为通用格式（预留）
    返回适配后的环境变量字典
    """
    import os
    result = {}
    for gl_var, gh_var in GITLAB_CI_VARS.items():
        val = os.environ.get(gl_var)
        if val:
            result[gh_var] = val
    return result


# 预留：GitLab CI 流水线触发入口
# def trigger_gitlab_scan(): ...
