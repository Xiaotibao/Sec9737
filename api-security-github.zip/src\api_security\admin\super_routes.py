"""
超级管理员 API - 租户管理
仅 SUPER_ADMIN_EMAILS 环境变量中的邮箱可访问
"""

import os
from flask import Blueprint, request, jsonify

from ..tenant import (
    list_tenants,
    create_tenant,
    update_tenant,
    get_tenant,
    get_tenant_id_from_request,
)

super_bp = Blueprint("super", __name__, url_prefix="/api/super")


def _super_admin_emails() -> set:
    """超级管理员邮箱列表"""
    raw = os.environ.get("SUPER_ADMIN_EMAILS", "")
    return {e.strip().lower() for e in raw.split(",") if e.strip()}


def _is_super_admin() -> bool:
    """当前请求是否来自超级管理员"""
    emails = _super_admin_emails()
    if not emails:
        return False
    # 可从 session 或 header 获取当前用户邮箱（GET 时避免 get_json 触发 415）
    try:
        body = request.get_json(silent=True)
    except Exception:
        body = None
    email = (
        request.headers.get("X-User-Email")
        or (body or {}).get("user_email")
        or request.args.get("user_email")
    )
    if not email:
        return False
    return email.strip().lower() in emails


@super_bp.before_request
def _require_super_admin():
    """所有超级管理员接口需鉴权"""
    if request.method == "OPTIONS":
        return None
    if not _is_super_admin():
        return jsonify({"error": "需要超级管理员权限"}), 403


@super_bp.route("/tenants", methods=["GET"])
def list_tenants_route():
    """列出租户（含已禁用）"""
    tenants = list_tenants(include_disabled=True)
    return jsonify({"tenants": [t.to_dict() for t in tenants]})


@super_bp.route("/tenants", methods=["POST"])
def create_tenant_route():
    """
    创建租户
    Body: { "tenant_id": "xxx", "name": "企业名", "enabled": true }
    """
    data = request.get_json(silent=True) or {}
    tenant_id = (data.get("tenant_id") or "").strip()
    name = (data.get("name") or tenant_id).strip()
    enabled = data.get("enabled", True)
    if not tenant_id:
        return jsonify({"success": False, "error": "tenant_id 必填"}), 400
    t = create_tenant(tenant_id, name, enabled)
    if not t:
        return jsonify({"success": False, "error": "租户已存在"}), 400
    return jsonify({"success": True, "tenant": t.to_dict()})


@super_bp.route("/tenants/<tenant_id>", methods=["PUT"])
def update_tenant_route(tenant_id):
    """
    更新租户
    Body: { "name": "xxx", "enabled": false, "sso_issuer": "...", ... }
    """
    data = request.get_json(silent=True) or {}
    name = data.get("name")
    enabled = data.get("enabled")
    sso_issuer = data.get("sso_issuer")
    sso_client_id = data.get("sso_client_id")
    sso_client_secret = data.get("sso_client_secret")
    sso_type = data.get("sso_type")
    t = update_tenant(
        tenant_id,
        name=name,
        enabled=enabled,
        sso_issuer=sso_issuer,
        sso_client_id=sso_client_id,
        sso_client_secret=sso_client_secret,
        sso_type=sso_type,
    )
    if not t:
        return jsonify({"success": False, "error": "租户不存在"}), 404
    return jsonify({"success": True, "tenant": t.to_dict()})


@super_bp.route("/tenants/<tenant_id>", methods=["GET"])
def get_tenant_route(tenant_id):
    """获取租户详情"""
    t = get_tenant(tenant_id)
    if not t:
        return jsonify({"error": "租户不存在"}), 404
    return jsonify(t.to_dict())
