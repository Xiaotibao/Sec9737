# 定价与权限管控说明

## 阶梯定价

| 套餐 | 年费 | API 调用/月 | 团队上限 | 扩容包 |
|------|------|-------------|----------|--------|
| 基础版 | 299元 | 10万次 | - | - |
| 进阶版 | 999元 | 50万次 | - | - |
| 旗舰版 | 1999元 | 100万次 | - | - |
| 无限版 | 3999元 | 不限 | 10人 | 200元/人/年 |

## 功能开放

| 功能 | 基础 | 进阶 | 旗舰 | 无限 |
|------|------|------|------|------|
| 团队管理 | ✓ | ✓ | ✓ | ✓ |
| 批量扫描 | - | ✓ | ✓ | ✓ |
| OpenAPI 合规核查 | - | - | ✓ | ✓ |
| GitHub Actions 集成 | - | - | - | ✓ |

## 规则

1. **同一企业仅可购买 1 个基础/进阶/旗舰套餐**
2. **无限套餐超员按 200元/人/年 计费**
3. **API 调用按月统计，超限返回 403**

## API

### GET /api/billing/plans
套餐列表

### GET /api/billing/license
当前许可证

### POST /api/billing/license
设置许可证（测试用）

### POST /api/billing/quote
获取报价

### POST /api/billing/purchase
购买/升级

### POST /api/billing/check
权限校验

## 插件调用

```python
from api_security.plugin import PermissionChecker, get_enterprise_plan

checker = PermissionChecker("enterprise_001")
plan_id = checker.get_plan_id()
ok, msg = checker.check_api_call(plan_id)
ok, msg = checker.check_feature(plan_id, "openapi_compliance")
ok, msg = checker.check_team_size(plan_id, current_count=5, expansion_count=2)
```
