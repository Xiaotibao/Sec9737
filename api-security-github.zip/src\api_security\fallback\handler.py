"""
解析失败降级机制
当文档解析失败时：
  1. 自动提示用户上传规范文档
  2. 或直接跳过该检测流程
  3. 不得影响整体扫描流程
"""

from enum import Enum
from pathlib import Path
from typing import Callable, Optional

from loguru import logger

from ..parser import OpenAPIParser, ParseResult, ComplianceChecker, ComplianceResult


class FallbackAction(str, Enum):
    """降级动作"""
    SKIP = "skip"           # 跳过 OpenAPI 相关检测
    PROMPT = "prompt"       # 提示用户上传规范文档
    RETRY = "retry"         # 重试（如使用备用解析策略）


class FallbackHandler:
    """
    解析失败降级处理器
    确保解析失败时不影响整体扫描流程
    """

    def __init__(
        self,
        on_failure: FallbackAction = FallbackAction.SKIP,
        prompt_message: Optional[str] = None,
        retry_path: Optional[str] = None,
    ):
        """
        Args:
            on_failure: 解析失败时的动作
            prompt_message: 自定义提示文案
            retry_path: 重试时使用的备用文档路径
        """
        self.on_failure = on_failure
        self.prompt_message = prompt_message or (
            "OpenAPI/Swagger 文档解析失败。请上传符合规范的 OpenAPI 2.0/3.0 文档，"
            "或选择跳过 API 设计合规检测。"
        )
        self.retry_path = retry_path

    def parse_with_fallback(
        self,
        source: str | Path,
        on_parse_success: Optional[Callable[[ParseResult, ComplianceResult], None]] = None,
        on_parse_failure: Optional[Callable[[ParseResult], FallbackAction]] = None,
    ) -> tuple[ParseResult, Optional[ComplianceResult]]:
        """
        带降级的解析流程

        Args:
            source: 文档路径或 URL
            on_parse_success: 解析成功时的回调
            on_parse_failure: 解析失败时的回调，可返回新的 FallbackAction

        Returns:
            (ParseResult, ComplianceResult | None)
            解析失败时 ComplianceResult 为 None
        """
        parser = OpenAPIParser(strict_validation=False)
        result = parser.parse(source)

        if result.success:
            checker = ComplianceChecker()
            compliance = checker.check(result)
            if on_parse_success:
                on_parse_success(result, compliance)
            return result, compliance

        # 解析失败 - 执行降级
        action = on_parse_failure(result) if on_parse_failure else self.on_failure
        if action == FallbackAction.RETRY and self.retry_path:
            retry_result = parser.parse(self.retry_path)
            if retry_result.success:
                checker = ComplianceChecker()
                compliance = checker.check(retry_result)
                return retry_result, compliance

        if action == FallbackAction.PROMPT:
            logger.warning(self.prompt_message)
            logger.info(f"解析错误详情: {result.error}")

        # SKIP 或 其他：静默跳过，返回空合规结果
        logger.info("已跳过 OpenAPI 设计合规检测，不影响整体扫描流程")
        return result, None

    def should_skip_compliance(self, parse_result: ParseResult) -> bool:
        """根据解析结果判断是否应跳过合规检测"""
        return not parse_result.success


def create_skip_handler() -> FallbackHandler:
    """创建默认跳过型处理器"""
    return FallbackHandler(on_failure=FallbackAction.SKIP)


def create_prompt_handler(message: Optional[str] = None) -> FallbackHandler:
    """创建提示型处理器"""
    return FallbackHandler(on_failure=FallbackAction.PROMPT, prompt_message=message)
