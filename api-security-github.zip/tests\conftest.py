"""pytest 配置 - 确保 src 在 PYTHONPATH"""
import sys
from pathlib import Path

root = Path(__file__).parent.parent
src = root / "src"
if str(src) not in sys.path:
    sys.path.insert(0, str(src))
