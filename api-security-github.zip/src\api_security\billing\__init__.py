"""
定价与权限管控核心模块
阶梯定价：基础299/进阶999/旗舰1999/无限3999+扩容包200/人/年
"""

from .plans import Plan, PLAN_BASIC, PLAN_ADVANCED, PLAN_FLAGSHIP, PLAN_UNLIMITED
from .checker import PermissionChecker
from .usage import UsageTracker
from .billing_api import BillingAdapter
from .license_store import get_enterprise_plan, set_license, get_expansion_count

__all__ = [
    "Plan",
    "PLAN_BASIC",
    "PLAN_ADVANCED",
    "PLAN_FLAGSHIP",
    "PLAN_UNLIMITED",
    "PermissionChecker",
    "UsageTracker",
    "BillingAdapter",
    "get_enterprise_plan",
    "set_license",
    "get_expansion_count",
]
