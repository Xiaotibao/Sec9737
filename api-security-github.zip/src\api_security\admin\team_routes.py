"""
企业管理员端 API - 成员管理、统计、Critical 汇总、导出
"""

import json
from pathlib import Path
from collections import defaultdict

from flask import Blueprint, request, jsonify, send_file
from io import BytesIO

from ..tenant import (
    get_tenant_id_from_request,
    get_tenant_members,
    get_tenant_member,
    add_tenant_member,
    update_tenant_member,
    delete_tenant_member,
    get_tenant_scan_metadata,
)
from .models import RESULTS_DIR
from .export_service import export_excel, export_pdf
from .audit_log import log_audit_from_request, OP_MEMBER_ADD, OP_MEMBER_UPDATE, OP_MEMBER_DELETE

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


# ---------------------------------------------------------------------------
# 成员管理
# ---------------------------------------------------------------------------

@admin_bp.route("/members", methods=["GET"])
def list_members():
    """获取团队所有成员"""
    tenant_id = get_tenant_id_from_request(request)
    members = get_tenant_members(tenant_id)
    return jsonify({"members": [m.to_dict() for m in members]})


@admin_bp.route("/members", methods=["POST"])
def create_member():
    """新增成员（受团队规模限制）"""
    from ..billing import PermissionChecker
    from ..billing.license_store import get_enterprise_plan, get_expansion_count
    tenant_id = get_tenant_id_from_request(request)
    checker = PermissionChecker(tenant_id)
    plan_id = get_enterprise_plan(tenant_id) or "basic"
    exp = get_expansion_count(tenant_id)
    members_before = get_tenant_members(tenant_id)
    ok, msg = checker.check_team_size(plan_id, len(members_before) + 1, exp)
    if not ok:
        return jsonify({"success": False, "error": msg}), 403

    data = request.get_json() or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip()
    if not name or not email:
        return jsonify({"success": False, "error": "name and email required"}), 400
    member = add_tenant_member(tenant_id, name, email)
    log_audit_from_request(OP_MEMBER_ADD, f"member:{member.id}", "success", name or email, None, request)
    return jsonify({"success": True, "member": member.to_dict()})


@admin_bp.route("/members/<int:member_id>", methods=["PUT"])
def update_member_route(member_id):
    """更新成员"""
    tenant_id = get_tenant_id_from_request(request)
    data = request.get_json() or {}
    name = data.get("name")
    email = data.get("email")
    member = update_tenant_member(tenant_id, member_id, name, email)
    if not member:
        return jsonify({"success": False, "error": "member not found"}), 404
    log_audit_from_request(OP_MEMBER_UPDATE, f"member:{member_id}", "success", member.name or member.email, None, request)
    return jsonify({"success": True, "member": member.to_dict()})


@admin_bp.route("/members/<int:member_id>", methods=["DELETE"])
def delete_member_route(member_id):
    """删除成员"""
    tenant_id = get_tenant_id_from_request(request)
    m = get_tenant_member(tenant_id, member_id)
    if not delete_tenant_member(tenant_id, member_id):
        return jsonify({"success": False, "error": "member not found"}), 404
    log_audit_from_request(OP_MEMBER_DELETE, f"member:{member_id}", "success", (m.name or m.email) if m else "system", None, request)
    return jsonify({"success": True})


# ---------------------------------------------------------------------------
# 统计：扫描次数、各等级漏洞数量
# ---------------------------------------------------------------------------

@admin_bp.route("/stats", methods=["GET"])
def team_stats():
    """
    获取团队统计
    返回：成员列表 + 每人扫描次数 + 各等级漏洞数量
    """
    tenant_id = get_tenant_id_from_request(request)
    members = get_tenant_members(tenant_id)
    meta = get_tenant_scan_metadata(tenant_id)
    member_map = {m.id: m.name for m in members}

    stats = []
    for m in members:
        scan_count = 0
        critical = high = medium = low = info = 0

        for scan_file, scan_info in meta.items():
            if scan_info.get("member_id") == m.id:
                scan_count += 1
                path = RESULTS_DIR / scan_file
                if path.exists():
                    try:
                        data = json.loads(path.read_text(encoding="utf-8"))
                        findings = data.get("detection", {}).get("findings", [])
                        for f in findings:
                            sev = (f.get("severity") or "").lower()
                            if sev == "critical":
                                critical += 1
                            elif sev == "high":
                                high += 1
                            elif sev == "medium":
                                medium += 1
                            elif sev == "low":
                                low += 1
                            else:
                                info += 1
                    except Exception:
                        pass

        stats.append({
            "member_id": m.id,
            "member_name": m.name,
            "email": m.email,
            "scan_count": scan_count,
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low,
            "info": info,
        })

    return jsonify({"stats": stats})


# ---------------------------------------------------------------------------
# Critical 级别漏洞汇总
# ---------------------------------------------------------------------------

@admin_bp.route("/critical", methods=["GET"])
def critical_vulns():
    """
    统一获取团队所有项目的 Critical 级别漏洞
    用于管理员端统一接收通知
    """
    tenant_id = get_tenant_id_from_request(request)
    meta = get_tenant_scan_metadata(tenant_id)
    members = {m.id: m.name for m in get_tenant_members(tenant_id)}

    items = []
    for scan_file, info in meta.items():
        path = RESULTS_DIR / scan_file
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            findings = data.get("detection", {}).get("findings", [])
            for idx, f in enumerate(findings):
                if (f.get("severity") or "").lower() == "critical":
                    items.append({
                        "id": f"{scan_file}::{idx}",
                        "scan_file": scan_file,
                        "timestamp": data.get("timestamp"),
                        "project": info.get("project", ""),
                        "member_name": info.get("member_name") or members.get(info.get("member_id"), ""),
                        "tool": f.get("tool"),
                        "severity": "critical",
                        "title": f.get("title"),
                        "description": f.get("description"),
                        "location": f.get("location"),
                        "cve_id": f.get("cve_id"),
                        "rule_id": f.get("rule_id"),
                    })
        except Exception:
            pass

    # 按时间倒序
    items.sort(key=lambda x: x.get("timestamp") or "", reverse=True)

    # 高危漏洞提醒：计算需弹窗/通知的漏洞（含 24h 频率限制）
    from ..alert import process_findings_for_alerts
    alerts = process_findings_for_alerts(items, "")

    return jsonify({
        "critical": items,
        "total": len(items),
        "alerts": alerts,
    })


# ---------------------------------------------------------------------------
# 批量导出
# ---------------------------------------------------------------------------

@admin_bp.route("/export", methods=["POST"])
def batch_export():
    """
    批量导出团队漏洞检测报告
    Body: { "format": "excel"|"pdf", "api_name": "", "severity": "", "tool": "", "include_trend": true }
    """
    tenant_id = get_tenant_id_from_request(request)
    data = request.get_json() or {}
    fmt = (data.get("format") or "excel").lower()
    if fmt not in ("excel", "pdf"):
        return jsonify({"success": False, "error": "format must be excel or pdf"}), 400

    api_name = data.get("api_name") or None
    severity = data.get("severity") or None
    tool = data.get("tool") or None
    include_trend = data.get("include_trend", True)

    try:
        if fmt == "excel":
            buf, filename = export_excel(tenant_id=tenant_id, api_name=api_name, severity=severity, tool=tool, include_trend=include_trend)
        else:
            buf, filename = export_pdf(tenant_id=tenant_id, api_name=api_name, severity=severity, tool=tool, include_trend=include_trend)
        from .audit_log import log_audit_from_request, OP_EXPORT
        log_audit_from_request(OP_EXPORT, f"export:{fmt}", "success", "system", None, request)
        return send_file(
            buf,
            mimetype="application/octet-stream",
            as_attachment=True,
            download_name=filename,
        )
    except Exception as e:
        from .audit_log import log_audit_from_request, OP_EXPORT
        log_audit_from_request(OP_EXPORT, f"export:{fmt}", "failed", "system", str(e), request)
        return jsonify({"success": False, "error": str(e)}), 500
