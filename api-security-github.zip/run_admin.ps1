# PowerShell startup script for admin
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
pip install flask flask-cors openpyxl reportlab PyYAML requests loguru openapi-spec-validator -q 2>$null
python run_admin.py --port 5000
